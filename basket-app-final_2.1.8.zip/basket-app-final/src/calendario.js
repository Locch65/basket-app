let ordineCalendario = "desc";
let refreshInterval = null; // Gestisce il loop di aggiornamento

/**
 * Recupera l'elenco dei campionati disponibili dall'array globale.
 * Ritorna un array comprensivo di "Tutti", es. ["Tutti", "U14", "U15"]
 */
function getCampionatiDisponibili() {
    const campionatiTeam = window.MY_TEAM_CAMPIONATO || [];
    // Filtriamo eventuali valori vuoti/nulli e rimuoviamo duplicati
    const unici = Array.from(new Set(campionatiTeam.filter(c => c && c.trim() !== "")));
    return ["Tutti", ...unici];
}

/**
 * Genera dinamicamente le opzioni radio nel menu hamburger
 */
function popolaRadioCampionati(campionatoSalvato) {
    const container = document.getElementById("containerCampionatiRadio");
    if (!container) return;

    const listaCampionati = getCampionatiDisponibili();
    container.innerHTML = ""; // Pulizia iniziale

    listaCampionati.forEach(camp => {
        const label = document.createElement("label");
        label.className = "radio-container";

        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "camp";
        radio.value = camp;
        radio.className = "camp-radio";
        if (camp === campionatoSalvato) radio.checked = true;

        label.appendChild(radio);
        label.appendChild(document.createTextNode(` ${camp}`));
        container.appendChild(label);
    });
}

function caricaListaPartite(filtroCampionato = null) {
    const container = document.getElementById("listaPartite");
    const cacheDati = window.getLocalStorage("cache_partite");

    // Mostra subito la cache se esiste (UX reattiva)
    if (cacheDati && cacheDati !== "undefined") {
        renderizzaPartite(JSON.parse(cacheDati), filtroCampionato, ordineCalendario);
    }

    // Forza comunque il fetch per aggiornare la vista
    fetchPartiteDalServer(filtroCampionato);
}

function fetchPartiteDalServer(filtroCampionato, forceFetchfromGoogle = false) {
    const container = document.getElementById("listaPartite");
    container.classList.add("loading");

    // 1. Facciamo partire il cronometro
    const startTime = performance.now();

    if (!window.USE_FIREBASE || forceFetchfromGoogle) {
        const params = new URLSearchParams({
            appVersion: window.APP_VERSION,
            teamId: window.getTeamId(),
            sheet: "Partite",
            userId: userId,
            action: "Get Calendario Partite",
            details: JSON.stringify(getDeviceData)
        });

        toggleLoading(true);
        
        fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            // 2. Calcoliamo la fine e stampiamo in console
            const endTime = performance.now();
            const duration = (endTime - startTime).toFixed(2); // Arrotonda a 2 decimali
            console.log("fetchPartiteDalServer() " + duration + " ms");

            const partite = Array.isArray(data) ? data : data.data;
            salvaDatiMappa(partite);

            // Aggiorna la cache con i nuovi dati freschi
            window.setLocalStorage("cache_partite", JSON.stringify(partite));
            container.innerHTML = "";
            container.classList.remove("loading");
            toggleLoading(false);

            // 1. Trasformiamo l'array in un oggetto con matchId come chiavi
            const partiteOggetto = {};
            partite.forEach(p => {
                if (p.matchId) {
                    partiteOggetto[p.matchId] = p;
                }
            });

            // 2. Sovrascriviamo l'intero nodo 'partite' con questo oggetto
            // Questo cancellerà tutto il vecchio contenuto di 'partite' e scriverà il nuovo
            console.log("Sincronizzazione completa del nodo partite...");
            window.saveToFirebaseHistory('partite', partiteOggetto);

            renderizzaPartite(partite, filtroCampionato, ordineCalendario);
        })
        .catch(err => {
            console.error("Errore fetch, provo a usare la cache:", err);

            // Tenta di recuperare i dati dalla cache se il server fallisce
            const cacheDati = window.getLocalStorage("cache_partite");
            if (cacheDati && cacheDati !== "undefined") {
                const datiLocali = JSON.parse(cacheDati);
                container.classList.remove("loading");
                renderizzaPartite(datiLocali, filtroCampionato, ordineCalendario);
                // Opzionale: mostra un piccolo avviso che i dati sono offline
                console.warn("Visualizzazione dati in modalità offline (cache)");
            } else {
                container.innerHTML = "Errore: server non raggiungibile e nessuna cache disponibile.";
                container.classList.remove("loading");
            }
            toggleLoading(false);
        });
    }
    else {
        // 2. Chiamata a Firebase tramite la funzione asincrona creata in precedenza
        readFromFirebaseHistory("partite/")
        .then(data => {
            // Calcoliamo la durata della richiesta
            const endTime = performance.now();
            const duration = (endTime - startTime).toFixed(2);
            console.log("readFromFirebaseHistory() " + duration + " ms");

            if (data) {
                // Se i dati esistono, aggiorniamo la mappa, la cache e renderizziamo
                const partite = Array.isArray(data) ? data : Object.values(data);
                salvaDatiMappa(partite);
                
                window.setLocalStorage("cache_partite", JSON.stringify(partite));
                container.classList.remove("loading");
                renderizzaPartite(partite, filtroCampionato, ordineCalendario);
            } else {
                // Se Firebase restituisce null (percorso vuoto o errore connessione), 
                // lanciamo un errore per finire nel blocco catch e usare la cache
                throw new Error("Nessun dato da Firebase o problema di connessione");
            }
        })
        .catch(err => {
            console.error("Errore Firebase, provo a usare la cache:", err);

            // Tenta di recuperare i dati dalla cache se Firebase fallisce
            const cacheDati = window.getLocalStorage("cache_partite");
            if (cacheDati && cacheDati !== "undefined") {
                const datiLocali = JSON.parse(cacheDati);
                container.classList.remove("loading");
                renderizzaPartite(datiLocali, filtroCampionato, ordineCalendario);
                console.warn("Visualizzazione dati in modalità offline (cache)");
                container.classList.remove("loading");
            } else {
                container.innerHTML = "Errore: Firebase non raggiungibile e nessuna cache disponibile.";
                container.classList.remove("loading");
            }
        });
    }
    container.classList.remove("loading");
}

function renderizzaPartite(partite, filtroCampionato, ordine = 'asc') {
    const container = document.getElementById("listaPartite");
    const oggi = new Date();
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    const campionatiValidi = window.MY_TEAM_CAMPIONATO || [];

    let partiteFiltrate = partite;

    // Se NON è admin, mostra solo le partite appartenenti ai campionati della squadra e non di test
    let numPartiteTest = 0;
    if (!isAdmin) {
        numPartiteTest = partiteFiltrate.length;
        partiteFiltrate = partiteFiltrate.filter(p => {
            const mId = String(p.matchId || "");
            const appartieneACampionato = campionatiValidi.some(camp => mId.includes(camp));
            return appartieneACampionato && !mId.toLowerCase().includes("test");
        });
        numPartiteTest = numPartiteTest - partiteFiltrate.length;
    }

    // Filtro per Campionato selezionato dall'utente
    if (filtroCampionato && filtroCampionato !== "Tutti") {
        partiteFiltrate = partiteFiltrate.filter(p =>
            String(p.matchId ?? "").includes(filtroCampionato)
        );
    }

    const filtroStato = window.getLocalStorage("filtroStatoPartite") || "tutte";

    partiteFiltrate = partiteFiltrate.filter(p => {
        const isTerminata = p.statoPartita === "Terminata" || p.punteggioA !== ""; 
        
        if (filtroStato === "terminate") return isTerminata;
        if (filtroStato === "future") return !isTerminata;
        return true; 
    });

    partiteFiltrate.sort((a, b) => {
        const dataA = parseItalianDate(String(a.data).replace("*", ""), a.orario);
        const dataB = parseItalianDate(String(b.data).replace("*", ""), b.orario);
        return ordine === 'desc' ? dataB - dataA : dataA - dataB;
    });

    const frag = document.createDocumentFragment();

    partiteFiltrate.forEach(p => {
        // ⚙️ [MODIFICA 1]: Estrazione dinamica della categoria e del relativo INDICE
        const indexCat = campionatiValidi.findIndex(c => String(p.matchId).includes(c));
        const cat = indexCat !== -1 ? campionatiValidi[indexCat] : "Altro";
        
        // Assegna 'camp-0', 'camp-1', ecc. basato sull'indice, altrimenti stringa vuota
        // Se nel tuo CSS hai usato l'indice a base 1 (es. camp-1 e camp-2), ti basta fare: `camp-${indexCat + 1}`
        const classeCamp = indexCat !== -1 ? `camp-${indexCat+1}` : ''; 
        
        // Pulizia matchId rimuovendo il prefisso della categoria trovata
        let mIdPulito = String(p.matchId);
        campionatiValidi.forEach(c => {
            mIdPulito = mIdPulito.replace(c, "");
        });
        mIdPulito = mIdPulito.trim();

        const card = document.createElement("div");
        card.classList.add("match-card");
        card.setAttribute("data-matchid", p.matchId);

        if (String(p.matchId).toLowerCase().includes("test")) {
            card.classList.add("is-test");
        }

        if (p.isLive === "true" || p.isLive === true) card.classList.add("live-border");

        const dataPartita = parseItalianDate(String(p.data).replace("*",""), p.orario);
        if (dataPartita < oggi) card.classList.add("past");

        const giorni = ["Dom.", "Lun.", "Mar.", "Mer.", "Gio.", "Ven.", "Sab."];
        const giornoSett = giorni[dataPartita.getDay()];

        const note = JSON.parse(p.note || '{}');
        const hasVideo = p.videoURL && p.videoURL.trim() !== "";
        const hasStats = note.stats || false;
        const hasHighlights = note.highlights || false; 

        const isFuture = p.statoPartita !== "Terminata" && (p.punteggioA === "" || p.punteggioA == null);
        const hasConvocazioni = p.convocazioni && p.convocazioni.trim() !== "";

        const daConfermare = p.data.includes("*");
        const dataOraHtml = daConfermare 
            ? `<span class="data-ora-blink">
                    <span class="text-main">${giornoSett} ${String(p.data).replace("*","")} ${p.orario}</span>
                    <span class="text-alt">Data da confermare</span>
            </span>`
            : `<span class="data">${giornoSett} ${String(p.data).replace("*","")}</span>
            <span class="orario">${p.orario}</span>`;

        // ⚙️ [MODIFICA 2]: Aggiunta della classe dinamica `${classeCamp}` al badge del campionato
        card.innerHTML = `
            <div class="match-top">
                <span class="campionato ${classeCamp}">${cat}</span>
                <span class="match-id">${mIdPulito}</span>
                ${dataOraHtml}
                
                <div class="match-icons">
                    <i class="fas fa-video icon-video ${hasVideo ? '' : 'hidden'}" title="Video Integrale"></i>
                    <i class="fas fa-chart-bar icon-stats ${hasStats ? '' : 'hidden'}" title="Statistiche"></i>
                    <i class="fas fa-star icon-highlights ${hasHighlights ? '' : 'hidden'}" title="Highlights"></i>
                    <i class="fas fa-users icon-convocazioni-blink ${isFuture && hasConvocazioni ? '' : 'hidden'}" title="Convocazioni presenti"></i>
                </div>
            </div>
            <div class="match-middle"><span class="luogo">${p.luogo}</span></div>
            <div class="match-bottom">
                <span class="teamA"><span class="team-name">${p.squadraA}</span> <strong>${p.punteggioA ?? "-"}</strong></span>
                <span class="vs">vs</span>
                <span class="teamB"><strong>${p.punteggioB ?? "-"}</strong> <span class="team-name">${p.squadraB}</span></span>
            </div>`;

        if (p.casaTrasferta === "Casa") card.querySelector(".teamA .team-name").classList.add("highlight");
        else if (p.casaTrasferta === "Trasferta") card.querySelector(".teamB .team-name").classList.add("highlight");

        card.onclick = () => {
            const inTheFuture = isInTheFuture(String(p.data).replace("*", ""));
            const isAdmin = window.getLocalStorage("isAdmin") === "true";

            if (!isAdmin && (inTheFuture && !hasConvocazioni)) {
                window.alertCustom("Video e Statistiche partita non ancora disponibili!");
                return;
            }
            window.setLocalStorage("matchId", p.matchId);
            window.setLocalStorage("teamA", p.squadraA);
            window.setLocalStorage("teamB", p.squadraB);
            window.setLocalStorage("puntiSquadraA", p.punteggioA || 0);
            window.setLocalStorage("puntiSquadraB", p.punteggioB || 0);
            window.setLocalStorage("convocazioni", p.convocazioni || "");
            window.setLocalStorage("videoURL", p.videoURL || "");
            window.setLocalStorage("videoId", window.extractVideoId(p.videoURL));
            window.setLocalStorage("matchStartTime", window.extractYoutubeTime(p.videoURL));
            window.setLocalStorage("oraInizioDiretta", p.oraInizioDiretta || "");
            window.setLocalStorage("isLive", p.isLive || false);
            window.setLocalStorage("statoPartita", p.statoPartita || "");

            window.setLocalStorage("USE_MATCH_HTML", false);
            window.location.href = "direttavideo.html?matchId=" + encodeURIComponent(p.matchId);
        };

        frag.appendChild(card);
    });

    const counterLabel = document.getElementById("matchCounter");
    const cacheDati = window.getLocalStorage("cache_partite");
    let totalePartite = cacheDati ? JSON.parse(cacheDati).length : partiteFiltrate.length;
    totalePartite = totalePartite - numPartiteTest;

    if (counterLabel) {
        counterLabel.textContent = `${partiteFiltrate.length}/${totalePartite}`;
    }

    container.replaceChildren(frag);
    toggleLoading(false);

    window.setLocalStorage('partiteFiltrate', JSON.stringify(partiteFiltrate));
}

function OLD2renderizzaPartite(partite, filtroCampionato, ordine = 'asc') {
    const container = document.getElementById("listaPartite");
    const oggi = new Date();
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    const campionatiValidi = window.MY_TEAM_CAMPIONATO || [];

    let partiteFiltrate = partite;

    // Se NON è admin, mostra solo le partite appartenenti ai campionati della squadra e non di test
    let numPartiteTest = 0;
    if (!isAdmin) {
        numPartiteTest = partiteFiltrate.length;
        partiteFiltrate = partiteFiltrate.filter(p => {
            const mId = String(p.matchId || "");
            const appartieneACampionato = campionatiValidi.some(camp => mId.includes(camp));
            return appartieneACampionato && !mId.toLowerCase().includes("test");
        });
        numPartiteTest = numPartiteTest - partiteFiltrate.length;
    }

    // Filtro per Campionato selezionato dall'utente
    if (filtroCampionato && filtroCampionato !== "Tutti") {
        partiteFiltrate = partiteFiltrate.filter(p =>
            String(p.matchId ?? "").includes(filtroCampionato)
        );
    }

    const filtroStato = window.getLocalStorage("filtroStatoPartite") || "tutte";

    partiteFiltrate = partiteFiltrate.filter(p => {
        const isTerminata = p.statoPartita === "Terminata" || p.punteggioA !== ""; 
        
        if (filtroStato === "terminate") return isTerminata;
        if (filtroStato === "future") return !isTerminata;
        return true; 
    });

    partiteFiltrate.sort((a, b) => {
        const dataA = parseItalianDate(String(a.data).replace("*", ""), a.orario);
        const dataB = parseItalianDate(String(b.data).replace("*", ""), b.orario);
        return ordine === 'desc' ? dataB - dataA : dataA - dataB;
    });

    const frag = document.createDocumentFragment();

    partiteFiltrate.forEach(p => {
        // Estrazione dinamica della categoria del campionato
        let cat = campionatiValidi.find(c => String(p.matchId).includes(c)) || "Altro";
        
        // Pulizia matchId rimuovendo il prefisso della categoria trovata
        let mIdPulito = String(p.matchId);
        campionatiValidi.forEach(c => {
            mIdPulito = mIdPulito.replace(c, "");
        });
        mIdPulito = mIdPulito.trim();

        const card = document.createElement("div");
        card.classList.add("match-card");
        card.setAttribute("data-matchid", p.matchId);

        if (String(p.matchId).toLowerCase().includes("test")) {
            card.classList.add("is-test");
        }

        if (p.isLive === "true" || p.isLive === true) card.classList.add("live-border");

        const dataPartita = parseItalianDate(String(p.data).replace("*",""), p.orario);
        if (dataPartita < oggi) card.classList.add("past");

        const giorni = ["Dom.", "Lun.", "Mar.", "Mer.", "Gio.", "Ven.", "Sab."];
        const giornoSett = giorni[dataPartita.getDay()];

        const note = JSON.parse(p.note || '{}');
        const hasVideo = p.videoURL && p.videoURL.trim() !== "";
        const hasStats = note.stats || false;
        const hasHighlights = note.highlights || false; 

        const isFuture = p.statoPartita !== "Terminata" && (p.punteggioA === "" || p.punteggioA == null);
        const hasConvocazioni = p.convocazioni && p.convocazioni.trim() !== "";

        const daConfermare = p.data.includes("*");
        const dataOraHtml = daConfermare 
            ? `<span class="data-ora-blink">
                    <span class="text-main">${giornoSett} ${String(p.data).replace("*","")} ${p.orario}</span>
                    <span class="text-alt">Data da confermare</span>
            </span>`
            : `<span class="data">${giornoSett} ${String(p.data).replace("*","")}</span>
            <span class="orario">${p.orario}</span>`;

        card.innerHTML = `
            <div class="match-top">
                <span class="campionato ${cat}">${cat}</span>
                <span class="match-id">${mIdPulito}</span>
                ${dataOraHtml}
                
                <div class="match-icons">
                    <i class="fas fa-video icon-video ${hasVideo ? '' : 'hidden'}" title="Video Integrale"></i>
                    <i class="fas fa-chart-bar icon-stats ${hasStats ? '' : 'hidden'}" title="Statistiche"></i>
                    <i class="fas fa-star icon-highlights ${hasHighlights ? '' : 'hidden'}" title="Highlights"></i>
                    <i class="fas fa-users icon-convocazioni-blink ${isFuture && hasConvocazioni ? '' : 'hidden'}" title="Convocazioni presenti"></i>
                </div>
            </div>
            <div class="match-middle"><span class="luogo">${p.luogo}</span></div>
            <div class="match-bottom">
                <span class="teamA"><span class="team-name">${p.squadraA}</span> <strong>${p.punteggioA ?? "-"}</strong></span>
                <span class="vs">vs</span>
                <span class="teamB"><strong>${p.punteggioB ?? "-"}</strong> <span class="team-name">${p.squadraB}</span></span>
            </div>`;

        if (p.casaTrasferta === "Casa") card.querySelector(".teamA .team-name").classList.add("highlight");
        else if (p.casaTrasferta === "Trasferta") card.querySelector(".teamB .team-name").classList.add("highlight");

        card.onclick = () => {
            const inTheFuture = isInTheFuture(String(p.data).replace("*", ""));
            const isAdmin = window.getLocalStorage("isAdmin") === "true";

            if (!isAdmin && (inTheFuture && !hasConvocazioni)) {
                window.alertCustom("Video e Statistiche partita non ancora disponibili!");
                return;
            }
            window.setLocalStorage("matchId", p.matchId);
            window.setLocalStorage("teamA", p.squadraA);
            window.setLocalStorage("teamB", p.squadraB);
            window.setLocalStorage("puntiSquadraA", p.punteggioA || 0);
            window.setLocalStorage("puntiSquadraB", p.punteggioB || 0);
            window.setLocalStorage("convocazioni", p.convocazioni || "");
            window.setLocalStorage("videoURL", p.videoURL || "");
            window.setLocalStorage("videoId", window.extractVideoId(p.videoURL));
            window.setLocalStorage("matchStartTime", window.extractYoutubeTime(p.videoURL));
            window.setLocalStorage("oraInizioDiretta", p.oraInizioDiretta || "");
            window.setLocalStorage("isLive", p.isLive || false);
            window.setLocalStorage("statoPartita", p.statoPartita || "");

            window.setLocalStorage("USE_MATCH_HTML", false);
            window.location.href = "direttavideo.html?matchId=" + encodeURIComponent(p.matchId);
        };

        frag.appendChild(card);
    });

    const counterLabel = document.getElementById("matchCounter");
    const cacheDati = window.getLocalStorage("cache_partite");
    let totalePartite = cacheDati ? JSON.parse(cacheDati).length : partiteFiltrate.length;
    totalePartite = totalePartite - numPartiteTest;

    if (counterLabel) {
        counterLabel.textContent = `${partiteFiltrate.length}/${totalePartite}`;
    }

    container.replaceChildren(frag);
    toggleLoading(false);

    window.setLocalStorage('partiteFiltrate', JSON.stringify(partiteFiltrate));
}

function OLDrenderizzaPartite(partite, filtroCampionato, ordine = 'asc') {
    const container = document.getElementById("listaPartite");
    const oggi = new Date();
    const isAdmin = window.getLocalStorage("isAdmin") === "true";

    let partiteFiltrate = partite;

    // Se NON è admin, mostra SOLO U14 e U15 e non quelle di "test"
    let numPartiteTest = 0;
    if (!isAdmin) {
        numPartiteTest = partiteFiltrate.length;
        partiteFiltrate = partiteFiltrate.filter(p => {
            const mId = String(p.matchId || "");
            return (mId.includes("U14") || mId.includes("U15")) && ! mId.toLowerCase().includes("test");
        });
        numPartiteTest = numPartiteTest - partiteFiltrate.length;
    }

    // Filtro per Campionato
    if (filtroCampionato && filtroCampionato !== "Tutti") {
        partiteFiltrate = partiteFiltrate.filter(p =>
            String(p.matchId ?? "").includes(filtroCampionato)
        );
    }

    const filtroStato = window.getLocalStorage("filtroStatoPartite") || "tutte";

    partiteFiltrate = partiteFiltrate.filter(p => {
        const isTerminata = p.statoPartita === "Terminata" || p.punteggioA !== ""; 
        
        if (filtroStato === "terminate") return isTerminata;
        if (filtroStato === "future") return !isTerminata;
        return true; 
    });

    partiteFiltrate.sort((a, b) => {
        const dataA = parseItalianDate(String(a.data).replace("*", ""), a.orario);
        const dataB = parseItalianDate(String(b.data).replace("*", ""), b.orario);
        return ordine === 'desc' ? dataB - dataA : dataA - dataB;
    });

    const frag = document.createDocumentFragment();

    partiteFiltrate.forEach(p => {
        let cat = String(p.matchId).includes("U14") ? "U14" : String(p.matchId).includes("U15") ? "U15" : "Altro";
        let mIdPulito = String(p.matchId).replace("U14 ", "").replace("U15 ", "").trim();

        const card = document.createElement("div");
        card.classList.add("match-card");
        card.setAttribute("data-matchid", p.matchId);

        if (String(p.matchId).toLowerCase().includes("test")) {
            card.classList.add("is-test");
        }

        if (p.isLive === "true" || p.isLive === true) card.classList.add("live-border");

        const dataPartita = parseItalianDate(String(p.data).replace("*",""), p.orario);
        if (dataPartita < oggi) card.classList.add("past");

        const giorni = ["Dom.", "Lun.", "Mar.", "Mer.", "Gio.", "Ven.", "Sab."];
        const giornoSett = giorni[dataPartita.getDay()];

        const note = JSON.parse(p.note || '{}');
        const hasVideo = p.videoURL && p.videoURL.trim() !== "";
        const hasStats = note.stats || false;
        const hasHighlights = note.highlights || false; 

        // --- LOGICA ICONA CONVOCAZIONI ---
        const isFuture = p.statoPartita !== "Terminata" && (p.punteggioA === "" || p.punteggioA == null);
        const hasConvocazioni = p.convocazioni && p.convocazioni.trim() !== "";
        // ---------------------------------

        const daConfermare = p.data.includes("*");
        const dataOraHtml = daConfermare 
            ? `<span class="data-ora-blink">
                    <span class="text-main">${giornoSett} ${String(p.data).replace("*","")} ${p.orario}</span>
                    <span class="text-alt">Data da confermare</span>
            </span>`
            : `<span class="data">${giornoSett} ${String(p.data).replace("*","")}</span>
            <span class="orario">${p.orario}</span>`;

        card.innerHTML = `
            <div class="match-top">
                <span class="campionato ${cat}">${cat}</span>
                <span class="match-id">${mIdPulito}</span>
                ${dataOraHtml}
                
                <div class="match-icons">
                    <i class="fas fa-video icon-video ${hasVideo ? '' : 'hidden'}" title="Video Integrale"></i>
                    <i class="fas fa-chart-bar icon-stats ${hasStats ? '' : 'hidden'}" title="Statistiche"></i>
                    <i class="fas fa-star icon-highlights ${hasHighlights ? '' : 'hidden'}" title="Highlights"></i>
                    <i class="fas fa-users icon-convocazioni-blink ${isFuture && hasConvocazioni ? '' : 'hidden'}" title="Convocazioni presenti"></i>
                </div>
            </div>
            <div class="match-middle"><span class="luogo">${p.luogo}</span></div>
            <div class="match-bottom">
                <span class="teamA"><span class="team-name">${p.squadraA}</span> <strong>${p.punteggioA ?? "-"}</strong></span>
                <span class="vs">vs</span>
                <span class="teamB"><strong>${p.punteggioB ?? "-"}</strong> <span class="team-name">${p.squadraB}</span></span>
            </div>`;

        if (p.casaTrasferta === "Casa") card.querySelector(".teamA .team-name").classList.add("highlight");
        else if (p.casaTrasferta === "Trasferta") card.querySelector(".teamB .team-name").classList.add("highlight");

        card.onclick = () => {
            const inTheFuture = isInTheFuture(String(p.data).replace("*", ""));
            const isAdmin = window.getLocalStorage("isAdmin") === "true";

            if (!isAdmin && (inTheFuture && !hasConvocazioni)) {
                window.alertCustom("Video e Statistiche partita non ancora disponibili!");
                return;
            }
            window.setLocalStorage("matchId", p.matchId);
            window.setLocalStorage("teamA", p.squadraA);
            window.setLocalStorage("teamB", p.squadraB);
            window.setLocalStorage("puntiSquadraA", p.punteggioA || 0);
            window.setLocalStorage("puntiSquadraB", p.punteggioB || 0);
            window.setLocalStorage("convocazioni", p.convocazioni || "");
            window.setLocalStorage("videoURL", p.videoURL || "");
            window.setLocalStorage("videoId", window.extractVideoId(p.videoURL));
            window.setLocalStorage("matchStartTime", window.extractYoutubeTime(p.videoURL));
            window.setLocalStorage("oraInizioDiretta", p.oraInizioDiretta || "");
            window.setLocalStorage("isLive", p.isLive || false);
            window.setLocalStorage("statoPartita", p.statoPartita || "");

            window.setLocalStorage("USE_MATCH_HTML", false);
            window.location.href = "direttavideo.html?matchId=" + encodeURIComponent(p.matchId);
        };

        frag.appendChild(card);
    });

    const counterLabel = document.getElementById("matchCounter");
    const cacheDati = window.getLocalStorage("cache_partite");
    let totalePartite = cacheDati ? JSON.parse(cacheDati).length : partiteFiltrate.length;
    totalePartite = totalePartite - numPartiteTest;

    if (counterLabel) {
        counterLabel.textContent = `${partiteFiltrate.length}/${totalePartite}`;
    }

    container.replaceChildren(frag);
    toggleLoading(false);

    window.setLocalStorage('partiteFiltrate', JSON.stringify(partiteFiltrate));
}

function aggiornaDatiSenzaBlink(partite) {
    /**
     * Aggiorna i dati nelle card esistenti senza ricreare il DOM.
     * Impedisce il fastidioso flickering della pagina.
     */
    partite.forEach(p => {
        const card = document.querySelector(`.match-card[data-matchid="${p.matchId}"]`);
        if (card) {
            const scoreA = card.querySelector(".teamA strong");
            const scoreB = card.querySelector(".teamB strong");

            // Aggiorna solo se il valore è cambiato
            if (scoreA && scoreA.textContent !== String(p.punteggioA ?? "-")) scoreA.textContent = p.punteggioA ?? "-";
            if (scoreB && scoreB.textContent !== String(p.punteggioB ?? "-")) scoreB.textContent = p.punteggioB ?? "-";

            // Gestione dinamica del bordo live
            if (p.isLive === "true" || p.isLive === true) {
                card.classList.add("live-border");
            } else {
                card.classList.remove("live-border");
            }
        }
    });
}

function aggiornaPunteggiLive() {
    /**
     * Richiamata dal timer di refresh automatico.
     */
    const params = new URLSearchParams({
        appVersion: window.APP_VERSION,
        teamId: window.getTeamId(),
        sheet: "Partite",
        userId: userId,
        action: "Get Punteggio Live",
        details: JSON.stringify(getDeviceData)
    });

//??    fetch(window.getBackendUrl() + "?sheet=Partite")
    fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            const partite = Array.isArray(data) ? data : data.data;
            if (Array.isArray(partite)) {
                window.setLocalStorage("cache_partite", JSON.stringify(partite));
                aggiornaDatiSenzaBlink(partite);
            }
        });
}

function filtraPartite(campionato) {
    console.log("Filtro attivato per:", campionato);

    // 👉 Memorizza il campionato selezionato
    window.setLocalStorage("campionatoSelezionato", campionato ?? "Tutti");

    // --- AGGIUNTA: Rimuove il parametro ?live dall'URL senza ricaricare la pagina ---
    const url = new URL(window.location);
    url.searchParams.delete('live');
    window.history.replaceState({}, '', url);
    // ---------------------------------------------------------------------------

    caricaListaPartite(campionato);
}

function startRefreshAutomatico(attiva, filtro) {
    // Se c'è almeno una partita live e non c'è già un timer attivo
    if (attiva && !refreshInterval) {
        console.log("Partita Live rilevata: avvio loop aggiornamento (5s)");
        refreshInterval = setInterval(() => {
            aggiornaPunteggiLive();
        }, 5000); // 5000 ms = 30 secondi
    }
    // Se non ci sono più partite live, ferma il timer
    else if (!attiva && refreshInterval) {
        console.log("Nessuna partita Live: stop loop aggiornamento");
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

/**
 * Mostra o nasconde il popup di caricamento
 * @param {boolean} show - true per mostrare, false per nascondere
 */
function toggleLoading(show) {
    const popup = document.getElementById("loadingPopup");
    if (!popup) return;
    
    if (show) {
        popup.classList.remove("hidden");
    } else {
        popup.classList.add("hidden");
    }
}

async function init() {

    // --- PROTEZIONE PER BUNDLING/OFFUSCAMENTO ---
    const pageElement = document.getElementById('listaPartite'); // o l'ID principale della tua pagina
    if (!pageElement) return; 
    
    // 1. REGISTRAZIONE UTENTE E DATI INIZIALI
    try {
        await window.registerUserId();
    } catch (e) { console.error("Errore registrazione:", e); }

    // Recupero stati dal localStorage
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    
    // window.updateThemeBasedOnAdmin(); // non esiste piu'

    const savedTheme = window.getLocalStorage("theme");
    const campionatoSalvato = window.getLocalStorage("campionatoSelezionato") || "Tutti";
    ordineCalendario = window.getLocalStorage("ordineCalendario") || "asc";

    // Riferimenti DOM
    const menu = document.getElementById("menu");
    const hamburgerBtn = document.getElementById("hamburgerBtn");
    const toggleTheme1 = document.getElementById("toggleTheme1");
    const selectOrdine = document.getElementById("selectOrdine");
    const syncToFirebase = document.getElementById("syncToFirebase");
    const syncAdminLi = document.getElementById("liSyncAdmin");

    if (isAdmin && syncAdminLi) {
        // Se è admin, mostra l'elemento della lista
        syncAdminLi.classList.remove("hidden");
    } else if (syncAdminLi) {
        // Altrimenti assicurati che sia nascosto
        syncAdminLi.classList.add("hidden");
    }

    // 2. IMPOSTAZIONE STATO INIZIALE UI
    // Tema
    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
        toggleTheme1.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
    }

    // Filtri e Ordine
    if (selectOrdine) selectOrdine.value = ordineCalendario;
    
    // ⚙️ [MODIFICA 1] Popolamento dinamico radio campionati nel menu
    const containerRadio = document.getElementById("containerCampionatiRadio");
    const campionatiDisponibili = ["Tutti", ...(window.MY_TEAM_CAMPIONATO || [])];
    if (containerRadio) {
        containerRadio.innerHTML = "";
        campionatiDisponibili.forEach(camp => {
            const label = document.createElement("label");
            label.className = "radio-container";
            label.innerHTML = `<input type="radio" name="camp" value="${camp}" class="camp-radio" ${camp === campionatoSalvato ? "checked" : ""}> ${camp}`;
            containerRadio.appendChild(label);
        });
    }

    const campRadios = document.querySelectorAll('.camp-radio');

    // 3. GESTIONE EVENTI (LISTENERS)

    // Hamburger Menu
    hamburgerBtn?.addEventListener("click", () => {
        menu.classList.toggle("hidden");
    });

    document.addEventListener("click", (e) => {
        if (!menu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
            menu.classList.add("hidden");
        }
    });

    // Radio Campionato
    campRadios.forEach(radio => {
        radio.addEventListener("change", (e) => {
            const selezione = e.target.value;
            // 👉 AGGIORNA IL BOTTONE IN ALTO
            if (labelCamp) labelCamp.textContent = selezione;
            filtraPartite(selezione);
            setTimeout(() => menu.classList.add("hidden"), 200);
        });
    });

    // Select Ordine
    selectOrdine?.addEventListener("change", (e) => {
        ordineCalendario = e.target.value;
        window.setLocalStorage("ordineCalendario", ordineCalendario);
     
        // 👉 AGGIORNA IL BOTTONE IN ALTO (colore dell'icona)
        if (btnToggleOrdine) {
            btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";
        }
            
        const filtroAttuale = document.querySelector('input[name="camp"]:checked')?.value || "Tutti";
        caricaListaPartite(filtroAttuale);
        menu.classList.add("hidden");
    });

    const selectStatoPartite = document.getElementById("selectStatoPartite");

    // Recupera il valore salvato o imposta "tutte" come default
    const filtroSalvato = window.getLocalStorage("filtroStatoPartite") || "tutte";
    if (selectStatoPartite) selectStatoPartite.value = filtroSalvato;

    // Event Listener per il cambio filtro
    selectStatoPartite?.addEventListener("change", () => {
        const valore = selectStatoPartite.value;
        window.setLocalStorage("filtroStatoPartite", valore);
        
        // 👉 AGGIORNA IL BOTTONE IN ALTO (formattando il testo)
        if (labelStato) {
            labelStato.textContent = valore.charAt(0).toUpperCase() + valore.slice(1);
        }

        const attuale = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(attuale !== "Tutti" ? attuale : null);
        
        // Chiude il menu dopo la selezione
        const menu = document.getElementById("menu");
        menu.classList.add("hidden");
    });


    // Tema (Dark/Light)
    toggleTheme1?.addEventListener("click", () => {
        const isDark = document.body.classList.toggle("dark-mode");
        window.setLocalStorage("theme", isDark ? "dark" : "light");
        toggleTheme1.innerHTML = isDark ? 
            '<i class="fas fa-sun"></i> Light Mode' : 
            '<i class="fas fa-moon"></i> Dark Mode';
        menu.classList.add("hidden");
    });

    syncToFirebase?.addEventListener("click", () => {
        menu.classList.add("hidden");

        const container = document.getElementById("listaPartite");
        window.removeLocalStorage("cache_partite");
        toggleLoading(true);
        if (container) {
            container.innerHTML = "";
            container.classList.add("loading");
        }
        const filtroAttuale = document.querySelector('input[name="camp"]:checked')?.value || "Tutti";
        fetchPartiteDalServer(filtroAttuale, true);

    });

    const btnCicloCamp = document.getElementById("btnCicloCamp");
    const btnCicloStato = document.getElementById("btnCicloStato");
    const btnToggleOrdine = document.getElementById("btnToggleOrdine");
    const labelCamp = document.getElementById("labelCamp");
    const labelStato = document.getElementById("labelStato");


    // 2. IMPOSTAZIONE STATO INIZIALE UI

    // --- Sincronizzazione Campionato ---
    if (labelCamp) {
        // Se non c'è nulla, il default è "Tutti"
        labelCamp.textContent = campionatoSalvato; 
    }

    // --- Sincronizzazione Stato Partite ---
    if (labelStato) {
        const filtroSalvato = window.getLocalStorage("filtroStatoPartite") || "tutte";
        // Trasforma "terminate" in "Terminate" per la label
        labelStato.textContent = filtroSalvato.charAt(0).toUpperCase() + filtroSalvato.slice(1);
        
        // Allinea anche la select del menu se esiste
        if (selectStatoPartite) selectStatoPartite.value = filtroSalvato;
    }

    // --- Sincronizzazione Ordine ---
    if (btnToggleOrdine) {
        // Imposta il colore iniziale in base all'ordine salvato
        btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";
        
        // Allinea anche la select del menu se esiste
        if (selectOrdine) selectOrdine.value = ordineCalendario;
    }

    // ⚙️ [MODIFICA 2] Ciclo Campionato Dinamico basato su MY_TEAM_CAMPIONATO
    btnCicloCamp?.addEventListener("click", () => {
        const campionati = window.MY_TEAM_CAMPIONATO || [];
        const stati = ["Tutti", ...campionati];
        let attuale = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        let prossimo = stati[(stati.indexOf(attuale) + 1) % stati.length];
        
        labelCamp.textContent = prossimo;
        // Sincronizza i radio del menu se aperti
        document.querySelectorAll('.camp-radio').forEach(r => r.checked = (r.value === prossimo));
        
        // Rimuove tutte le classi css dinamiche dei campionati (camp-0, camp-1, ecc.)
        btnCicloCamp.className = "btn-tool"; // resetta mantenendo la classe base

        // Se selezionato un campionato specifico, applica la classe corrispondente all'indice
        const indexCampionato = campionati.indexOf(prossimo);
        if (indexCampionato !== -1) {
            btnCicloCamp.classList.add(`camp-${indexCampionato+1}`);
        }

        filtraPartite(prossimo);
    });

    // 2. Ciclo Stato (Tutte -> Terminate -> Future)
    btnCicloStato?.addEventListener("click", () => {
        const stati = ["tutte", "terminate", "future"];
        let attuale = window.getLocalStorage("filtroStatoPartite") || "tutte";
        let prossimo = stati[(stati.indexOf(attuale) + 1) % stati.length];
        
        labelStato.textContent = prossimo.charAt(0).toUpperCase() + prossimo.slice(1);
        window.setLocalStorage("filtroStatoPartite", prossimo);
        
        // 👉 SINCRONIZZAZIONE MENU: Allinea la select dell'hamburger menu
        const selectMenuStato = document.getElementById("selectStatoPartite");
        if (selectMenuStato) selectMenuStato.value = prossimo;
        
        btnCicloStato.classList.remove('future', 'terminate');

        btnCicloStato.classList.add(prossimo);
        const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(camp !== "Tutti" ? camp : null);
    });

    // 3. Toggle Ordine (Asc <-> Desc)
    btnToggleOrdine?.addEventListener("click", () => {
        ordineCalendario = (ordineCalendario === "asc") ? "desc" : "asc";
        window.setLocalStorage("ordineCalendario", ordineCalendario);
        
        // Cambia icona o stile se vuoi
        btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";

        // 👉 SINCRONIZZAZIONE MENU: Allinea la select dell'ordine
        const selectMenuOrdine = document.getElementById("selectOrdine");
        if (selectMenuOrdine) selectMenuOrdine.value = ordineCalendario;
        
        const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(camp !== "Tutti" ? camp : null);
    });

    // 5. Search
    const btnSearchToggle = document.getElementById("btnSearchToggle");
    const searchContainer = document.getElementById("searchContainer");
    const inputSearch = document.getElementById("inputSearch");

    btnSearchToggle?.addEventListener("click", () => {
        const isHidden = searchContainer.classList.toggle("hidden");
        document.body.classList.toggle("search-open", !isHidden);
        
        if (!isHidden) {
            inputSearch.focus();
        } else {
            // Reset quando si chiude
            inputSearch.value = "";
            const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
            caricaListaPartite(camp !== "Tutti" ? camp : null);
        }
    });

    const btnClear = document.getElementById("btnClearSearch");
    const btnSubmit = document.getElementById("btnSubmitSearch");

    // --- FUNZIONE PER ESEGUIRE IL FILTRO (Logica condivisa) ---
    const eseguiFiltro = () => {
        const query = inputSearch.value.toLowerCase();
        const cacheDati = window.getLocalStorage("cache_partite");
        
        if (cacheDati) {
            let partite = JSON.parse(cacheDati);
            
            const partiteFiltrate = partite.filter(p => {
                const inSquadraA = String(p.squadraA || "").toLowerCase().includes(query);
                const inSquadraB = String(p.squadraB || "").toLowerCase().includes(query);
                const inMatchId = String(p.matchId || "").toLowerCase().includes(query);
                const inLuogo = String(p.luogo || "").toLowerCase().includes(query);
                return inSquadraA || inSquadraB || inMatchId || inLuogo;
            });
            
            const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
            // Assicurati che 'ordineCalendario' sia accessibile globalmente o definita
            renderizzaPartite(partiteFiltrate, camp !== "Tutti" ? camp : null, typeof ordineCalendario !== 'undefined' ? ordineCalendario : 'desc');
        }
    };

    // --- LOGICA TASTO "X" (Cancella) ---
    btnClear?.addEventListener("click", () => {
        if (inputSearch.value.length > 0) {
            // FASE 1: Se c'è testo, cancella il contenuto e resetta il filtro
            inputSearch.value = "";
            inputSearch.focus();
            eseguiFiltro(); 
        } else {
            // FASE 2: Se è già vuoto, nasconde tutto il contenitore della ricerca
            const isHidden = searchContainer.classList.toggle("hidden");
            document.body.classList.toggle("search-open", !isHidden);
        }
    });

    // --- LOGICA TASTO "Invia" (Click sul bottone) ---
    btnSubmit?.addEventListener("click", () => {
        eseguiFiltro();
        // Opzionale: chiude la tastiera su mobile dopo l'invio
        inputSearch.blur(); 
    });

    inputSearch?.addEventListener("input", () => {
        eseguiFiltro();
    });

    // --- LOGICA TASTO "INVIO" (Tastiera fisica/mobile) ---
    inputSearch?.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            eseguiFiltro();
            inputSearch.blur(); 
        }
    });

    // Opzionale: Nascondi la "X" se l'input è vuoto
    inputSearch?.addEventListener("input", () => {
        btnClear.style.visibility = inputSearch.value ? "visible" : "hidden";
    });

    // 4. ESECUZIONE CARICAMENTO INIZIALE
    filtraPartite(campionatoSalvato);
}

async function OLDinit() {

    // --- PROTEZIONE PER BUNDLING/OFFUSCAMENTO ---
    const pageElement = document.getElementById('listaPartite'); // o l'ID principale della tua pagina
    if (!pageElement) return; 
    
    // 1. REGISTRAZIONE UTENTE E DATI INIZIALI
    try {
        await window.registerUserId();
    } catch (e) { console.error("Errore registrazione:", e); }

    // Recupero stati dal localStorage
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    
    // window.updateThemeBasedOnAdmin(); // non esiste piu'

    const savedTheme = window.getLocalStorage("theme");
    const campionatoSalvato = window.getLocalStorage("campionatoSelezionato") || "Tutti";
    ordineCalendario = window.getLocalStorage("ordineCalendario") || "asc";

    // Riferimenti DOM
    const menu = document.getElementById("menu");
    const hamburgerBtn = document.getElementById("hamburgerBtn");
    const toggleTheme1 = document.getElementById("toggleTheme1");
    const selectOrdine = document.getElementById("selectOrdine");
    const campRadios = document.querySelectorAll('.camp-radio');
    const syncToFirebase = document.getElementById("syncToFirebase");
    const syncAdminLi = document.getElementById("liSyncAdmin");

    if (isAdmin && syncAdminLi) {
        // Se è admin, mostra l'elemento della lista
        syncAdminLi.classList.remove("hidden");
    } else if (syncAdminLi) {
        // Altrimenti assicurati che sia nascosto
        syncAdminLi.classList.add("hidden");
    }

    // 2. IMPOSTAZIONE STATO INIZIALE UI
    // Tema
    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
        toggleTheme1.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
    }

    // Filtri e Ordine
    if (selectOrdine) selectOrdine.value = ordineCalendario;
    
    campRadios.forEach(radio => {
        if (radio.value === campionatoSalvato) radio.checked = true;
    });

    // 3. GESTIONE EVENTI (LISTENERS)

    // Hamburger Menu
    hamburgerBtn?.addEventListener("click", () => {
        menu.classList.toggle("hidden");
    });

    document.addEventListener("click", (e) => {
        if (!menu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
            menu.classList.add("hidden");
        }
    });

    // Radio Campionato
    campRadios.forEach(radio => {
        radio.addEventListener("change", (e) => {
            const selezione = e.target.value;
            // 👉 AGGIORNA IL BOTTONE IN ALTO
            if (labelCamp) labelCamp.textContent = selezione;
            filtraPartite(selezione);
            setTimeout(() => menu.classList.add("hidden"), 200);
        });
    });

    // Select Ordine
    selectOrdine?.addEventListener("change", (e) => {
        ordineCalendario = e.target.value;
        window.setLocalStorage("ordineCalendario", ordineCalendario);
     
        // 👉 AGGIORNA IL BOTTONE IN ALTO (colore dell'icona)
        if (btnToggleOrdine) {
            btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";
        }
            
        const filtroAttuale = document.querySelector('input[name="camp"]:checked')?.value || "Tutti";
        caricaListaPartite(filtroAttuale);
        menu.classList.add("hidden");
    });

    const selectStatoPartite = document.getElementById("selectStatoPartite");

    // Recupera il valore salvato o imposta "tutte" come default
    const filtroSalvato = window.getLocalStorage("filtroStatoPartite") || "tutte";
    if (selectStatoPartite) selectStatoPartite.value = filtroSalvato;

    // Event Listener per il cambio filtro
    selectStatoPartite?.addEventListener("change", () => {
        const valore = selectStatoPartite.value;
        window.setLocalStorage("filtroStatoPartite", valore);
        
        // 👉 AGGIORNA IL BOTTONE IN ALTO (formattando il testo)
        if (labelStato) {
            labelStato.textContent = valore.charAt(0).toUpperCase() + valore.slice(1);
        }

        const attuale = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(attuale !== "Tutti" ? attuale : null);
        
        // Chiude il menu dopo la selezione
        const menu = document.getElementById("menu");
        menu.classList.add("hidden");
    });


    // Tema (Dark/Light)
    toggleTheme1?.addEventListener("click", () => {
        const isDark = document.body.classList.toggle("dark-mode");
        window.setLocalStorage("theme", isDark ? "dark" : "light");
        toggleTheme1.innerHTML = isDark ? 
            '<i class="fas fa-sun"></i> Light Mode' : 
            '<i class="fas fa-moon"></i> Dark Mode';
        menu.classList.add("hidden");
    });

    syncToFirebase?.addEventListener("click", () => {
        menu.classList.add("hidden");

        const container = document.getElementById("listaPartite");
        window.removeLocalStorage("cache_partite");
        toggleLoading(true);
        if (container) {
            container.innerHTML = "";
            container.classList.add("loading");
        }
        const filtroAttuale = document.querySelector('input[name="camp"]:checked')?.value || "Tutti";
        fetchPartiteDalServer(filtroAttuale, true);

    });

    const btnCicloCamp = document.getElementById("btnCicloCamp");
    const btnCicloStato = document.getElementById("btnCicloStato");
    const btnToggleOrdine = document.getElementById("btnToggleOrdine");
    const labelCamp = document.getElementById("labelCamp");
    const labelStato = document.getElementById("labelStato");


    // 2. IMPOSTAZIONE STATO INIZIALE UI

    // --- Sincronizzazione Campionato ---
    if (labelCamp) {
        // Se non c'è nulla, il default è "Tutti"
        labelCamp.textContent = campionatoSalvato; 
    }

    // --- Sincronizzazione Stato Partite ---
    if (labelStato) {
        const filtroSalvato = window.getLocalStorage("filtroStatoPartite") || "tutte";
        // Trasforma "terminate" in "Terminate" per la label
        labelStato.textContent = filtroSalvato.charAt(0).toUpperCase() + filtroSalvato.slice(1);
        
        // Allinea anche la select del menu se esiste
        if (selectStatoPartite) selectStatoPartite.value = filtroSalvato;
    }

    // --- Sincronizzazione Ordine ---
    if (btnToggleOrdine) {
        // Imposta il colore iniziale in base all'ordine salvato
        btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";
        
        // Allinea anche la select del menu se esiste
        if (selectOrdine) selectOrdine.value = ordineCalendario;
    }

    // 1. Ciclo Campionato (U14 -> U15 -> Tutti)
    btnCicloCamp?.addEventListener("click", () => {
        const stati = ["Tutti", "U14", "U15"];
        let attuale = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        let prossimo = stati[(stati.indexOf(attuale) + 1) % stati.length];
        
        labelCamp.textContent = prossimo;
        // Sincronizza i radio del menu se aperti
        document.querySelectorAll('.camp-radio').forEach(r => r.checked = (r.value === prossimo));
        

        btnCicloCamp.classList.remove('U14', 'U15');

        // Aggiungiamo la classe in base al testo della label
        if (prossimo.includes('U14')) {
            btnCicloCamp.classList.add('U14');
        } else if (prossimo.includes('U15')) {
            btnCicloCamp.classList.add('U15');
        }

        filtraPartite(prossimo);
    });

    // 2. Ciclo Stato (Tutte -> Terminate -> Future)
    btnCicloStato?.addEventListener("click", () => {
        const stati = ["tutte", "terminate", "future"];
        let attuale = window.getLocalStorage("filtroStatoPartite") || "tutte";
        let prossimo = stati[(stati.indexOf(attuale) + 1) % stati.length];
        
        labelStato.textContent = prossimo.charAt(0).toUpperCase() + prossimo.slice(1);
        window.setLocalStorage("filtroStatoPartite", prossimo);
        
        // 👉 SINCRONIZZAZIONE MENU: Allinea la select dell'hamburger menu
        const selectMenuStato = document.getElementById("selectStatoPartite");
        if (selectMenuStato) selectMenuStato.value = prossimo;
        
        btnCicloStato.classList.remove('future', 'terminate');

        btnCicloStato.classList.add(prossimo);
        const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(camp !== "Tutti" ? camp : null);
    });

    // 3. Toggle Ordine (Asc <-> Desc)
    btnToggleOrdine?.addEventListener("click", () => {
        ordineCalendario = (ordineCalendario === "asc") ? "desc" : "asc";
        window.setLocalStorage("ordineCalendario", ordineCalendario);
        
        // Cambia icona o stile se vuoi
        btnToggleOrdine.style.color = (ordineCalendario === "asc") ? "#27ae60" : "#e67e22";

        // 👉 SINCRONIZZAZIONE MENU: Allinea la select dell'ordine
        const selectMenuOrdine = document.getElementById("selectOrdine");
        if (selectMenuOrdine) selectMenuOrdine.value = ordineCalendario;
        
        const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
        caricaListaPartite(camp !== "Tutti" ? camp : null);
    });

    // 5. Search
    const btnSearchToggle = document.getElementById("btnSearchToggle");
    const searchContainer = document.getElementById("searchContainer");
    const inputSearch = document.getElementById("inputSearch");

    btnSearchToggle?.addEventListener("click", () => {
        const isHidden = searchContainer.classList.toggle("hidden");
        document.body.classList.toggle("search-open", !isHidden);
        
        if (!isHidden) {
            inputSearch.focus();
        } else {
            // Reset quando si chiude
            inputSearch.value = "";
            const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
            caricaListaPartite(camp !== "Tutti" ? camp : null);
        }
    });

    const btnClear = document.getElementById("btnClearSearch");
    const btnSubmit = document.getElementById("btnSubmitSearch");

    // --- FUNZIONE PER ESEGUIRE IL FILTRO (Logica condivisa) ---
    const eseguiFiltro = () => {
        const query = inputSearch.value.toLowerCase();
        const cacheDati = window.getLocalStorage("cache_partite");
        
        if (cacheDati) {
            let partite = JSON.parse(cacheDati);
            
            const partiteFiltrate = partite.filter(p => {
                const inSquadraA = String(p.squadraA || "").toLowerCase().includes(query);
                const inSquadraB = String(p.squadraB || "").toLowerCase().includes(query);
                const inMatchId = String(p.matchId || "").toLowerCase().includes(query);
                const inLuogo = String(p.luogo || "").toLowerCase().includes(query);
                return inSquadraA || inSquadraB || inMatchId || inLuogo;
            });
            
            const camp = window.getLocalStorage("campionatoSelezionato") || "Tutti";
            // Assicurati che 'ordineCalendario' sia accessibile globalmente o definita
            renderizzaPartite(partiteFiltrate, camp !== "Tutti" ? camp : null, typeof ordineCalendario !== 'undefined' ? ordineCalendario : 'desc');
        }
    };

    // --- LOGICA TASTO "X" (Cancella) ---
    btnClear?.addEventListener("click", () => {
        if (inputSearch.value.length > 0) {
            // FASE 1: Se c'è testo, cancella il contenuto e resetta il filtro
            inputSearch.value = "";
            inputSearch.focus();
            eseguiFiltro(); 
        } else {
            // FASE 2: Se è già vuoto, nasconde tutto il contenitore della ricerca
            const isHidden = searchContainer.classList.toggle("hidden");
            document.body.classList.toggle("search-open", !isHidden);
        }
    });

    // --- LOGICA TASTO "Invia" (Click sul bottone) ---
    btnSubmit?.addEventListener("click", () => {
        eseguiFiltro();
        // Opzionale: chiude la tastiera su mobile dopo l'invio
        inputSearch.blur(); 
    });

    inputSearch?.addEventListener("input", () => {
        eseguiFiltro();
    });

    // --- LOGICA TASTO "INVIO" (Tastiera fisica/mobile) ---
    inputSearch?.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            eseguiFiltro();
            inputSearch.blur(); 
        }
    });

    // Opzionale: Nascondi la "X" se l'input è vuoto
    inputSearch?.addEventListener("input", () => {
        btnClear.style.visibility = inputSearch.value ? "visible" : "hidden";
    });

    // 4. ESECUZIONE CARICAMENTO INIZIALE
    filtraPartite(campionatoSalvato);
}

init();

window.addEventListener('DOMContentLoaded', injectUniversalPopup);