const SHEET_ID = '1Pa_oN5DpWO0t-e2iPKgFhAwqn728X0g3r330xJg8jsU'; 
const TAB_NAME = 'TABELLONE';
const SQUADRE_TAB_NAME = 'SQUADRE';
const DATE_TAB_NAME = 'DATE';

const URL_TABELLONE = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&sheet=${TAB_NAME}`;
const URL_SQUADRE = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&sheet=${SQUADRE_TAB_NAME}`;
const URL_DATE = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&sheet=${DATE_TAB_NAME}`;

let scale = window.innerWidth < 768 ? 0.35 : 0.65;
let pointX = 15;
let pointY = 15;
let start = { x: 0, y: 0 };
let isDragging = false;
let touchStartDist = 0;
let touchStartScale = 0;

let globalMatches = [];
let globalSquadreDatabase = [];
let globalDateDatabase = {};
let activeHighlightedPath = new Set();

// Riferimenti agli elementi DOM (verranno associati nell'init)
let container;
let wrapper;
let bracket;
let selectMode;
let posterOverlay;
let searchTeam1;
let searchTeam2;

function hidePoster() {
    if (posterOverlay && !posterOverlay.classList.contains('hidden')) {
        posterOverlay.classList.add('hidden');
    }
}

function updateTransform() {
    if (scale < 0.05) scale = 0.05;
    if (scale > 3) scale = 3;
    wrapper.style.transform = `translate(${pointX}px, ${pointY}px) scale(${scale})`;
}

function resetZoomAndHighlights() {
    location.reload(); 
}

async function fetchBracketData() {
    try {
        const [responseTabellone, responseSquadre, responseDate] = await Promise.all([
            fetch(URL_TABELLONE),
            fetch(URL_SQUADRE),
            fetch(URL_DATE)
        ]);

        const textTabellone = await responseTabellone.text();
        const textSquadre = await responseSquadre.text();
        const textDate = await responseDate.text();

        const jsonData = JSON.parse(textTabellone.substr(47).slice(0, -2));
        const jsonSquadre = JSON.parse(textSquadre.substr(47).slice(0, -2));
        const jsonDate = JSON.parse(textDate.substr(47).slice(0, -2));

        const rows = jsonData.table.rows;
        const dataRows = (rows[0]?.c[0]?.v === 'ID' || rows[0]?.c[0]?.v === 'id') ? rows.slice(1) : rows;

        const rowsSquadre = jsonSquadre.table.rows;
        globalSquadreDatabase = [];
        if (rowsSquadre && rowsSquadre.length > 0) {
            const startIdx = (rowsSquadre[0]?.c[0]?.v === 'REGIONE' || rowsSquadre[0]?.c[0]?.v === 'regione') ? 1 : 0;
            rowsSquadre.slice(startIdx).forEach(row => {
                globalSquadreDatabase.push({
                    regione: row.c[0]?.v ? row.c[0].v.toString().trim() : '',
                    citta: row.c[1]?.v ? row.c[1].v.toString().trim() : '',
                    squadra: row.c[2]?.v ? row.c[2].v.toString().trim() : '',
                    nickname: row.c[3]?.v ? row.c[3].v.toString().trim() : ''
                });
            });
        }

        populateSearchDropdowns();

        const rowsDate = jsonDate.table.rows;
        globalDateDatabase = {};
        if (rowsDate && rowsDate.length > 0) {
            const startIdxDate = (rowsDate[0]?.c[0]?.v?.toString().toUpperCase() === 'FASE') ? 1 : 0;
            rowsDate.slice(startIdxDate).forEach(row => {
                if (row.c[0] && row.c[0].v !== null) {
                    const faseNome = row.c[0].v.toString().trim().toUpperCase();
                    const faseDataStringa = row.c[1] && row.c[1].v !== null ? row.c[1].v.toString().trim() : '';
                    globalDateDatabase[faseNome] = faseDataStringa;
                }
            });
        }

        globalMatches = dataRows.map(row => {
            const getCellValue = (cell) => {
                if (!cell || cell.v === undefined || cell.v === null) return '';
                return cell.v.toString().trim();
            };

            const puntiA_raw = row.c[5] ? getCellValue(row.c[5]) : '';
            const puntiB_raw = row.c[6] ? getCellValue(row.c[6]) : '';

            return {
                id: row.c[0] ? getCellValue(row.c[0]) : '',
                fase: row.c[1] ? getCellValue(row.c[1]) : '',
                turno: row.c[2] ? getCellValue(row.c[2]) : '',
                squadraA: row.c[3] && row.c[3].v !== null ? getCellValue(row.c[3]) : 'Da definire',
                squadraB: row.c[4] && row.c[4].v !== null ? getCellValue(row.c[4]) : 'Da definire',
                puntiA: puntiA_raw,
                puntiB: puntiB_raw,
                prossimaPartitaId: row.c[7] ? getCellValue(row.c[7]) : '',
                posizioneProssima: row.c[8] ? getCellValue(row.c[8]).toUpperCase() : '',
                prossimaPartitaIdPerdente: row.c[9] ? getCellValue(row.c[9]) : '',
                posizioneProssimaPerdente: row.c[10] ? getCellValue(row.c[10]).toUpperCase() : '',
                orario: row.c[11] ? getCellValue(row.c[11]) : ''
            };
        });

        globalMatches.forEach(match => {
            const haPunti = match.puntiA !== '' && match.puntiB !== '';
            if (!haPunti) return;

            const isA_Winner = Number(match.puntiA) > Number(match.puntiB);
            const vincente = isA_Winner ? match.squadraA : match.squadraB;
            const perdente = isA_Winner ? match.squadraB : match.squadraA;
            
            if (match.prossimaPartitaId) {
                const targetMatchWin = globalMatches.find(m => m.id === match.prossimaPartitaId);
                if (targetMatchWin) {
                    const posWin = match.posizioneProssima;
                    if (posWin === 'A' || posWin === 'SQUADRA_A') targetMatchWin.squadraA = vincente;
                    else if (posWin === 'B' || posWin === 'SQUADRA_B') targetMatchWin.squadraB = vincente;
                }
            }

            if (match.prossimaPartitaIdPerdente) {
                const targetMatchLoss = globalMatches.find(m => m.id === match.prossimaPartitaIdPerdente);
                if (targetMatchLoss) {
                    const posLoss = match.posizioneProssimaPerdente;
                    if (posLoss === 'A' || posLoss === 'SQUADRA_A') targetMatchLoss.squadraA = perdente;
                    else if (posLoss === 'B' || posLoss === 'SQUADRA_B') targetMatchLoss.squadraB = perdente;
                }
            }
        });

        renderBracket(globalMatches);

        // Genera ed inserisce la classifica fissa sulla pagina principale all'avvio
        renderClassificaModal();

    } catch (error) {
        console.error("Errore dati:", error);
        bracket.innerHTML = "<p style='padding:20px;'>Errore nel caricamento dei dati dal foglio Google.</p>";
    }
}

function populateSearchDropdowns() {
    const nicknamesUnici = [...new Set(globalSquadreDatabase.map(s => s.nickname))].filter(Boolean).sort();
    
    nicknamesUnici.forEach(nick => {
        const opt1 = document.createElement('option');
        opt1.value = nick; 
        opt1.textContent = nick;
        searchTeam1.appendChild(opt1);

        const opt2 = document.createElement('option');
        opt2.value = nick;
        opt2.textContent = nick;
        searchTeam2.appendChild(opt2);
    });
}

function findAndHighlightIntersection() {
    document.querySelectorAll('.match-box').forEach(b => b.classList.remove('highlight-match'));
    document.querySelectorAll('.team-name').forEach(name => name.classList.remove('clicked-blink'));

    const t1 = searchTeam1.value.toUpperCase();
    const t2 = searchTeam2.value.toUpperCase();

    if (!t1 || !t2 || t1 === t2) {
        activeHighlightedPath.clear();
        drawConnectorLines();
        return;
    }

    function calcolaAlberoDipendenzeID(teamNickname) {
        let matchToccati = new Set();

        const squadraDoc = globalSquadreDatabase.find(s => 
            s.nickname.toUpperCase() === teamNickname || 
            s.regione.toUpperCase() === teamNickname || 
            s.squadra.toUpperCase() === teamNickname
        );
        const regioneCodice = squadraDoc && squadraDoc.regione ? squadraDoc.regione.toUpperCase() : "";
        const nomeSquadraEsteso = squadraDoc && squadraDoc.squadra ? squadraDoc.squadra.toUpperCase() : "";

        let idPartitaIniziale = null;
        let latoIniziale = ""; 

        for (let i = 0; i < globalMatches.length; i++) {
            const m = globalMatches[i];
            const matchA = m.squadraA ? m.squadraA.toUpperCase() : "";
            const matchB = m.squadraB ? m.squadraB.toUpperCase() : "";

            if (matchA === teamNickname || matchA === regioneCodice || matchA === nomeSquadraEsteso) {
                idPartitaIniziale = m.id; latoIniziale = "A"; break;
            }
            if (matchB === teamNickname || matchB === regioneCodice || matchB === nomeSquadraEsteso) {
                idPartitaIniziale = m.id; latoIniziale = "B"; break;
            }
        }

        if (!idPartitaIniziale) return matchToccati;

        function navigaAlbero(currentId, provenienzaEsito) {
            if (!currentId || matchToccati.has(currentId)) return;

            const matchObj = globalMatches.find(m => m.id === currentId);
            if (!matchObj) return;

            matchToccati.add(currentId);
            const haPunteggio = matchObj.puntiA !== '' && matchObj.puntiB !== '';
            
            if (haPunteggio) {
                const isA_Winner = Number(matchObj.puntiA) > Number(matchObj.puntiB);
                let esitoSquadraInQuestoMatch = "";
                
                if (provenienzaEsito === "A") {
                    esitoSquadraInQuestoMatch = isA_Winner ? "VINCENTE" : "PERDENTE";
                } else if (provenienzaEsito === "B") {
                    esitoSquadraInQuestoMatch = !isA_Winner ? "VINCENTE" : "PERDENTE";
                } else {
                    const matchA_Concluso = matchObj.squadraA ? matchObj.squadraA.toUpperCase() : "";
                    const matchB_Concluso = matchObj.squadraB ? matchObj.squadraB.toUpperCase() : "";
                    
                    const isQuiComeA = (matchA_Concluso === teamNickname || matchA_Concluso === regioneCodice || matchA_Concluso === nomeSquadraEsteso);
                    const isQuiComeB = (matchB_Concluso === teamNickname || matchB_Concluso === regioneCodice || matchB_Concluso === nomeSquadraEsteso);
                    
                    if (isQuiComeA) {
                        esitoSquadraInQuestoMatch = isA_Winner ? "VINCENTE" : "PERDENTE";
                    } else if (isQuiComeB) {
                        esitoSquadraInQuestoMatch = !isA_Winner ? "VINCENTE" : "PERDENTE";
                    } else {
                        if (matchObj.prossimaPartitaId) navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                        if (matchObj.prossimaPartitaIdPerdente) navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
                        return;
                    }
                }

                if (esitoSquadraInQuestoMatch === "VINCENTE" && matchObj.id) {
                    navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                } else if (esitoSquadraInQuestoMatch === "PERDENTE" && matchObj.prossimaPartitaIdPerdente) {
                    navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
                }
            } else {
                if (matchObj.prossimaPartitaId) navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                if (matchObj.prossimaPartitaIdPerdente) navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
            }
        }

        navigaAlbero(idPartitaIniziale, latoIniziale);
        return matchToccati;
    }

    const alberoTeam1 = calcolaAlberoDipendenzeID(t1);
    const alberoTeam2 = calcolaAlberoDipendenzeID(t2);

    let candidateMatches = [];
    globalMatches.forEach(match => {
        if (alberoTeam1.has(match.id) && alberoTeam2.has(match.id)) {
            candidateMatches.push(match);
        }
    });

    if (candidateMatches.length > 0) {
        activeHighlightedPath = new Set([...alberoTeam1, ...alberoTeam2]);

        candidateMatches.forEach(match => {
            const box = document.querySelector(`.match-box[data-id="${match.id}"]`);
            if (box) box.classList.add('highlight-match');
        });

        const orderOfFases = ['SEMIFINALI GOLD-SILVER', 'FINALI GOLD-SILVER', 'SEDICESIMI', 'OTTAVI', 'QUARTI', 'SEMIFINALI', 'FINALI'];
        candidateMatches.sort((mA, mB) => {
            return orderOfFases.indexOf(mA.fase.toUpperCase()) - orderOfFases.indexOf(mB.fase.toUpperCase());
        });

        const targetBox = document.querySelector(`.match-box[data-id="${candidateMatches[0].id}"]`);
        if (targetBox) {
            const bracketRect = bracket.getBoundingClientRect();
            const boxRect = targetBox.getBoundingClientRect();
            pointX = (window.innerWidth / 2) - ((boxRect.left - bracketRect.left + boxRect.width / 2) * scale);
            pointY = (window.innerHeight / 2) - ((boxRect.top - bracketRect.top + boxRect.height / 2) * scale);
            updateTransform();
        }
    } else {
        activeHighlightedPath.clear();
    }
    drawConnectorLines();
}

window.highlightTeamPath = highlightTeamPath;
function highlightTeamPath(element) {
    event.stopPropagation();

    const teamRawName = element.getAttribute('data-team');
    if (!teamRawName || teamRawName === 'Da definire') return;

    document.querySelectorAll('.match-box').forEach(b => b.classList.remove('highlight-match'));
    document.querySelectorAll('.team-name').forEach(name => name.classList.remove('clicked-blink'));
    
    searchTeam1.value = "";
    searchTeam2.value = "";

    const trovato = globalSquadreDatabase.find(s => 
        s.regione.toUpperCase() === teamRawName.toUpperCase() || 
        s.nickname.toUpperCase() === teamRawName.toUpperCase() || 
        s.squadra.toUpperCase() === teamRawName.toUpperCase()
    );
    
    const teamKey = trovato ? trovato.nickname.toUpperCase() : teamRawName.toUpperCase();

    document.querySelectorAll(`.team-name[data-team="${teamRawName}"]`).forEach(el => {
        el.classList.add('clicked-blink');
    });

    function calcolaAlbero(teamNickname) {
        let matchToccati = new Set();
        let idPartitaIniziale = null;
        let latoIniziale = "";

        for (let i = 0; i < globalMatches.length; i++) {
            const m = globalMatches[i];
            const matchA = m.squadraA ? m.squadraA.toUpperCase() : "";
            const matchB = m.squadraB ? m.squadraB.toUpperCase() : "";

            if (matchA === teamNickname || matchA === (trovato?.regione?.toUpperCase()) || matchA === (trovato?.squadra?.toUpperCase())) {
                idPartitaIniziale = m.id; latoIniziale = "A"; break;
            }
            if (matchB === teamNickname || matchB === (trovato?.regione?.toUpperCase()) || matchB === (trovato?.squadra?.toUpperCase())) {
                idPartitaIniziale = m.id; latoIniziale = "B"; break;
            }
        }

        if (!idPartitaIniziale) return matchToccati;

        function navigaAlbero(currentId, provenienzaEsito) {
            if (!currentId || matchToccati.has(currentId)) return;
            const matchObj = globalMatches.find(m => m.id === currentId);
            if (!matchObj) return;

            matchToccati.add(currentId);
            const haPunteggio = matchObj.puntiA !== '' && matchObj.puntiB !== '';
            
            if (haPunteggio) {
                const isA_Winner = Number(matchObj.puntiA) > Number(matchObj.puntiB);
                let esitoSquadraInQuestoMatch = "";
                
                if (provenienzaEsito === "A") {
                    esitoSquadraInQuestoMatch = isA_Winner ? "VINCENTE" : "PERDENTE";
                } else if (provenienzaEsito === "B") {
                    esitoSquadraInQuestoMatch = !isA_Winner ? "VINCENTE" : "PERDENTE";
                } else {
                    const matchA_Concluso = matchObj.squadraA ? matchObj.squadraA.toUpperCase() : "";
                    const matchB_Concluso = matchObj.squadraB ? matchObj.squadraB.toUpperCase() : "";
                    if (matchA_Concluso === teamNickname || matchA_Concluso === (trovato?.regione?.toUpperCase()) || matchA_Concluso === (trovato?.squadra?.toUpperCase())) {
                        esitoSquadraInQuestoMatch = isA_Winner ? "VINCENTE" : "PERDENTE";
                    } else if (matchB_Concluso === teamNickname || matchB_Concluso === (trovato?.regione?.toUpperCase()) || matchB_Concluso === (trovato?.squadra?.toUpperCase())) {
                        esitoSquadraInQuestoMatch = !isA_Winner ? "VINCENTE" : "PERDENTE";
                    } else {
                        if (matchObj.prossimaPartitaId) navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                        if (matchObj.prossimaPartitaIdPerdente) navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
                        return;
                    }
                }

                if (esitoSquadraInQuestoMatch === "VINCENTE" && matchObj.prossimaPartitaId) {
                    navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                } else if (esitoSquadraInQuestoMatch === "PERDENTE" && matchObj.prossimaPartitaIdPerdente) {
                    navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
                }
            } else {
                if (matchObj.prossimaPartitaId) navigaAlbero(matchObj.prossimaPartitaId, "VINCENTE");
                if (matchObj.prossimaPartitaIdPerdente) navigaAlbero(matchObj.prossimaPartitaIdPerdente, "PERDENTE");
            }
        }

        navigaAlbero(idPartitaIniziale, latoIniziale);
        return matchToccati;
    }

    const camminoSquadra = calcolaAlbero(teamKey);
    activeHighlightedPath = camminoSquadra;

    camminoSquadra.forEach(matchId => {
        const box = document.querySelector(`.match-box[data-id="${matchId}"]`);
        if (box) box.classList.add('highlight-match');
    });

    drawConnectorLines();
}

function getTeamDisplayName(squadraNomeOriginale, colonnaTarget) {
    if (squadraNomeOriginale === 'Da definire' || !squadraNomeOriginale) return squadraNomeOriginale;

    const trovato = globalSquadreDatabase.find(s => s.regione.toUpperCase() === squadraNomeOriginale.toUpperCase());
    
    if (trovato) {
        let valoreSelezionato = '';
        if (colonnaTarget === 'REGIONE') valoreSelezionato = trovato.regione;
        else if (colonnaTarget === 'CITTA') valoreSelezionato = trovato.citta;
        else if (colonnaTarget === 'SQUADRA') valoreSelezionato = trovato.squadra;
        else if (colonnaTarget === 'NICKNAME') valoreSelezionato = trovato.nickname;

        return valoreSelezionato ? valoreSelezionato : squadraNomeOriginale;
    }

    return squadraNomeOriginale;
}

function renderBracket(matches) {
    bracket.innerHTML = '<svg id="bracket-lines"></svg>';

    const orderOfFases = ['SEMIFINALI GOLD-SILVER', 'FINALI GOLD-SILVER', 'SEDICESIMI', 'OTTAVI', 'QUARTI', 'SEMIFINALI', 'FINALI'];
    const dataStructure = {};

    matches.forEach(match => {
        if (!match.fase || !match.turno) return; 
        const faseKey = match.fase.toString().trim().toUpperCase();
        if (!dataStructure[faseKey]) {
            dataStructure[faseKey] = { orderOfTurns: [], turns: {} };
        }
        if (!dataStructure[faseKey].turns[match.turno]) {
            dataStructure[faseKey].turns[match.turno] = [];
            dataStructure[faseKey].orderOfTurns.push(match.turno);
        }
        dataStructure[faseKey].turns[match.turno].push(match);
    });

    const currentTargetColumn = selectMode.value;

    orderOfFases.forEach(faseKey => {
        if (!dataStructure[faseKey]) return;

        const faseContainer = document.createElement('div');
        faseContainer.className = 'fase-container';

        const faseTitle = document.createElement('div');
        faseTitle.className = 'fase-title';
        
        const dataFaseTrovata = globalDateDatabase[faseKey] || '';
        
        faseTitle.innerHTML = `
            <span>${faseKey.replace('_', ' ')}</span>
            ${dataFaseTrovata ? `<span class="fase-date">${dataFaseTrovata}</span>` : ''}
        `;
        faseContainer.appendChild(faseTitle);

        dataStructure[faseKey].orderOfTurns.forEach(turno => {
            const column = document.createElement('div');
            column.className = 'bracket-column';

            const title = document.createElement('div');
            title.className = 'column-title';
            title.innerText = turno;
            column.appendChild(title);

            dataStructure[faseKey].turns[turno].forEach(match => {
                const matchBox = document.createElement('div');
                matchBox.className = 'match-box';
                matchBox.setAttribute('data-id', match.id); 
                
                if (match.prossimaPartitaId) matchBox.setAttribute('data-next-win', match.prossimaPartitaId);
                if (match.prossimaPartitaIdPerdente) matchBox.setAttribute('data-next-loss', match.prossimaPartitaIdPerdente);

                if (match.puntiA !== '' || match.puntiB !== '') matchBox.classList.add('active');

                const isAFinale = match.puntiA !== '' && match.puntiB !== '';
                const winA = isAFinale && Number(match.puntiA) > Number(match.puntiB);
                const winB = isAFinale && Number(match.puntiB) > Number(match.puntiA);

                const displayNameA = getTeamDisplayName(match.squadraA, currentTargetColumn);
                const displayNameB = getTeamDisplayName(match.squadraB, currentTargetColumn);

                const isAReale = globalSquadreDatabase.some(s => 
                    s.regione.toUpperCase() === match.squadraA.toUpperCase() || 
                    s.nickname.toUpperCase() === match.squadraA.toUpperCase() || 
                    s.squadra.toUpperCase() === match.squadraA.toUpperCase()
                );
                const isBReale = globalSquadreDatabase.some(s => 
                    s.regione.toUpperCase() === match.squadraB.toUpperCase() || 
                    s.nickname.toUpperCase() === match.squadraB.toUpperCase() || 
                    s.squadra.toUpperCase() === match.squadraB.toUpperCase()
                );

                let baseTurnClass = '';
                if (String(turno).toUpperCase().includes("GOLD")) baseTurnClass = 'gold-match';
                else if (String(turno).toUpperCase().includes("SILVER")) baseTurnClass = 'silver-match';

                let classesA = ['team-row', baseTurnClass];
                let classesB = ['team-row', baseTurnClass];

                if (match.squadraA === 'Da definire' || !isAReale) {
                    classesA.push('team-generic');
                } else {
                    classesA.push('team-qualified');
                }

                if (match.squadraB === 'Da definire' || !isBReale) {
                    classesB.push('team-generic');
                } else {
                    classesB.push('team-qualified');
                }

                let scoreClassA = '';
                let scoreClassB = '';

                if (isAFinale) {
                    if (winA) {
                        classesA.push('score-won');
                        classesB.push('score-lost');
                        scoreClassA = 'score-won';
                        scoreClassB = 'score-lost';
                    } else {
                        classesA.push('score-lost');
                        classesB.push('score-won');
                        scoreClassA = 'score-lost';
                        scoreClassB = 'score-won';
                    }
                }

                matchBox.innerHTML = `
                    <div class="match-id">${match.id}</div>
                    <div class="${classesA.join(' ')}">
                        <span class="team-name ${match.squadraA === 'Da definire' ? 'empty' : ''}" data-team="${match.squadraA}" onclick="window.highlightTeamPath(this)">${displayNameA}</span>
                        <span class="team-score ${scoreClassA}">${match.puntiA}</span>
                    </div>
                    <div class="${classesB.join(' ')}">
                        <span class="team-name ${match.squadraB === 'Da definire' ? 'empty' : ''}" data-team="${match.squadraB}" onclick="window.highlightTeamPath(this)">${displayNameB}</span>
                        <span class="team-score ${scoreClassB}">${match.puntiB}</span>
                    </div>
                    ${match.orario ? `<div class="match-time" style="position: absolute; bottom: 2px; right: 6px; font-size: 0.65rem; font-weight: bold; color: #64748b; pointer-events: none; z-index: 10;">🕒 ${match.orario}</div>` : ''}
                `;
                column.appendChild(matchBox);
            });
            
            faseContainer.appendChild(column);
        });
        bracket.appendChild(faseContainer);
    });

    updateTransform();
    setTimeout(drawConnectorLines, 200);
}

function drawConnectorLines() {
    const svg = document.getElementById('bracket-lines');
    if (!svg) return;
    svg.innerHTML = ''; 

    const matchBoxes = document.querySelectorAll('.match-box');
    const bracketRect = bracket.getBoundingClientRect();

    matchBoxes.forEach(box => {
        const boxId = box.getAttribute('data-id');
        const nextWinId = box.getAttribute('data-next-win');
        const nextLossId = box.getAttribute('data-next-loss');

        const boxRect = box.getBoundingClientRect();
        const startX = (boxRect.right - bracketRect.left) / scale;
        const startY = (boxRect.top + boxRect.height / 2 - bracketRect.top) / scale;

        const isConcluded = box.classList.contains('active');

        if (nextWinId) {
            const targetBox = document.querySelector(`.match-box[data-id="${nextWinId}"]`);
            if (targetBox) {
                const targetRect = targetBox.getBoundingClientRect();
                const endX = (targetRect.left - bracketRect.left) / scale;
                const endY = (targetRect.top + targetRect.height / 2 - bracketRect.top) / scale;
                const lineColor = isConcluded ? '#2e7d32' : '#a7f3d0'; 
                
                const isHighlighted = activeHighlightedPath.has(boxId) && activeHighlightedPath.has(nextWinId);
                
                createSvgPath(svg, startX, startY, endX, endY, lineColor, '0', "Vincente", isHighlighted);
            }
        }

        if (nextLossId) {
            const targetBox = document.querySelector(`.match-box[data-id="${nextLossId}"]`);
            if (targetBox) {
                const targetRect = targetBox.getBoundingClientRect();
                const endX = (targetRect.left - bracketRect.left) / scale;
                const endY = (targetRect.top + targetRect.height / 2 - bracketRect.top) / scale;
                const lineColor = isConcluded ? '#c62828' : '#fecaca'; 
                
                const isHighlighted = activeHighlightedPath.has(boxId) && activeHighlightedPath.has(nextLossId);
                
                createSvgPath(svg, startX, startY, endX, endY, lineColor, '0', "Perdente", isHighlighted);
            }
        }
    });
}

function createSvgPath(svg, sx, sy, ex, ey, color, dashArray, tipo, isHighlighted = false) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    const dStr = `M ${sx} ${sy} L ${ex} ${ey}`;
    path.setAttribute("d", dStr);
    path.setAttribute("stroke", color);
    path.setAttribute("stroke-width", "2.5");
    path.setAttribute("fill", "none");
    if (dashArray !== '0') {
        path.setAttribute("stroke-dasharray", dashArray);
    }
    
    if (isHighlighted) {
        path.classList.add('highlight-link');
    }
    
    svg.appendChild(path);
}

function generaClassificaPerdentiSedicesimi() {
    // 1. Filtra tutti i match che appartengono alla fase dei SEDICESIMI
    const matchSedicesimi = globalMatches.filter(m => m.fase.toUpperCase() === 'SEDICESIMI');
    
    if (matchSedicesimi.length === 0) {
        console.warn("Nessun match trovato per la fase 'SEDICESIMI'.");
        return;
    }

    const recordSquadre = {};

    // 2. Identifica il perdente di ogni match dei sedicesimi
    matchSedicesimi.forEach(match => {
        const puntiA = Number(match.puntiA);
        const puntiB = Number(match.puntiB);
        
        // Verifica che il match sia stato effettivamente giocato e concluso
        if (match.puntiA === '' || match.puntiB === '') return;

        let perdente = '';
        if (puntiA < puntiB) {
            perdente = match.squadraA;
        } else if (puntiB < puntiA) {
            perdente = match.squadraB;
        }

        if (perdente && perdente !== 'Da definire') {
            // Inizializziamo il cumulo delle statistiche per la squadra perdente
            recordSquadre[perdente] = {
                nome: perdente,
                vittorie: 0,
                puntiFatti: 0,
                puntiSubiti: 0
            };
        }
    });

    const squadreDaMappare = Object.keys(recordSquadre);
    if (squadreDaMappare.length === 0) {
        console.warn("Nessun perdente trovato nei Sedicesimi (i match potrebbero non essere conclusi).");
        return;
    }

    // 3. Naviga a ritroso nel tabellone globale per raccogliere i dati storici delle 16 squadre
    globalMatches.forEach(match => {
        const puntiA = Number(match.puntiA);
        const puntiB = Number(match.puntiB);
        if (match.puntiA === '' || match.puntiB === '') return; // Salta i match non giocati

        const sqA = match.squadraA;
        const sqB = match.squadraB;

        // Se la squadra A è tra i nostri perdenti dei sedicesimi, accumula i dati
        if (squadreDaMappare.includes(sqA)) {
            recordSquadre[sqA].puntiFatti += puntiA;
            recordSquadre[sqA].puntiSubiti += puntiB;
            if (puntiA > puntiB) recordSquadre[sqA].vittorie += 1;
        }

        // Se la squadra B è tra i nostri perdenti dei sedicesimi, accumula i dati
        if (squadreDaMappare.includes(sqB)) {
            recordSquadre[sqB].puntiFatti += puntiB;
            recordSquadre[sqB].puntiSubiti += puntiA;
            if (puntiB > puntiA) recordSquadre[sqB].vittorie += 1;
        }
    });

    // 4. Trasforma l'oggetto in un array e ordina la classifica
    // Criteri richiesti:
    //  - Maggior numero di partite vinte (decrescente)
    //  - Maggior numero di punti fatti (decrescente)
    //  - Minor numero di punti subiti (crescente)
    const classificaOrdinata = Object.values(recordSquadre).sort((a, b) => {
        if (b.vittorie !== a.vittorie) {
            return b.vittorie - a.vittorie; 
        }
        if (b.puntiFatti !== a.puntiFatti) {
            return b.puntiFatti - a.puntiFatti; 
        }
        return a.puntiSubiti - b.puntiSubiti; 
    });

    // 5. Stampa del risultato formattato in console
    console.log("=== CLASSIFICA DAL 17° AL 32° POSTO (PERDENTI SEDICESIMI) ===");
    classificaOrdinata.forEach((squadra, index) => {
        const posizione = 17 + index;
        // Recupera il nickname reale dal database se presente per una migliore leggibilità
        const nickDoc = globalSquadreDatabase.find(s => s.regione.toUpperCase() === squadra.nome.toUpperCase() || s.nickname.toUpperCase() === squadra.nome.toUpperCase());
        const nomeVisualizzato = nickDoc ? nickDoc.nickname : squadra.nome;

        console.log(
            `${posizione}° Posto: ${nomeVisualizzato.padEnd(20)} | ` +
            `Vittorie totali: ${squadra.vittorie} | ` +
            `Punti Fatti: ${squadra.puntiFatti} | ` +
            `Punti Subiti: ${squadra.puntiSubiti}`
        );
    });
    console.log("=============================================================");
}

// Se vuoi esporla globalmente per testarla direttamente dalla console del browser:
window.generaClassificaPerdentiSedicesimi = generaClassificaPerdentiSedicesimi;

function renderClassificaModal() {
    const tbodyModal = document.getElementById('classifica-tbody');
    const tbodyFissa = document.getElementById('classifica-fissa-tbody');
    
    if (tbodyModal) tbodyModal.innerHTML = '';
    if (tbodyFissa) tbodyFissa.innerHTML = '';

    // Funzione di ordinamento comune basata sui criteri richiesti
    const sortClassifica = (a, b) => {
        if (b.vittorie !== a.vittorie) return b.vittorie - a.vittorie;
        if (b.puntiFatti !== a.puntiFatti) return b.puntiFatti - a.puntiFatti;
        return a.puntiSubiti - b.puntiSubiti;
    };

    // Helper interno per mappare le statistiche storiche a ritroso
    const calcolaStatisticheStoriche = (squadreKeys, skipSort = false) => {
        const record = {};
        squadreKeys.forEach(k => {
            if (k && k !== 'Da definire') {
                record[k] = { nomeChiave: k, vittorie: 0, sconfitte: 0, puntiFatti: 0, puntiSubiti: 0 };
            }
        });

        const keysPresenti = Object.keys(record);

        globalMatches.forEach(match => {
            if (match.puntiA === '' || match.puntiB === '') return;
            const puntiA = Number(match.puntiA);
            const puntiB = Number(match.puntiB);
            const sqA = match.squadraA;
            const sqB = match.squadraB;

            if (keysPresenti.includes(sqA)) {
                record[sqA].puntiFatti += puntiA; record[sqA].puntiSubiti += puntiB;
                if (puntiA > puntiB) record[sqA].vittorie += 1; else record[sqA].sconfitte += 1;
            }
            if (keysPresenti.includes(sqB)) {
                record[sqB].puntiFatti += puntiB; record[sqB].puntiSubiti += puntiA;
                if (puntiB > puntiA) record[sqB].vittorie += 1; else record[sqB].sconfitte += 1;
            }
        });

        const risvegliati = Object.values(record);
        if (skipSort) {
            return squadreKeys.map(key => risvegliati.find(r => r.nomeChiave === key)).filter(Boolean);
        }
        return risvegliati.sort(sortClassifica);
    };

    // Helper per appendere la riga a ENTRAMBI i target della tabella
    const aggiungiRigaInTabella = (posizione, squadraDati, isEmpty = false) => {
        const creaTr = () => {
            const tr = document.createElement('tr');
            if (isEmpty || !squadraDati) {
                tr.className = 'row-empty';
                tr.innerHTML = `<td>${posizione}</td><td>In attesa piazzamento...</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td>`;
            } else {
                tr.className = 'row-filled';
                const scheda = globalSquadreDatabase.find(s => 
                    s.regione.toUpperCase() === squadraDati.nomeChiave.toUpperCase() || 
                    s.nickname.toUpperCase() === squadraDati.nomeChiave.toUpperCase() ||
                    s.squadra.toUpperCase() === squadraDati.nomeChiave.toUpperCase()
                );
                const nomeEsteso = scheda && scheda.squadra ? scheda.squadra : squadraDati.nomeChiave;
                const puntiClassifica = squadraDati.vittorie * 2;

                // Configurazione del nome dinamico in base alla select "display-mode"
                const currentTargetColumn = selectMode.value;
                const nomeVisualizzato = getTeamDisplayName(squadraDati.nomeChiave, currentTargetColumn);

                // Controllo generico sul nome per tracciare il tuo team
                if (nomeEsteso.toUpperCase().includes(window.MY_TEAM_SHORTNAME.toUpperCase()) || squadraDati.nomeChiave.toUpperCase().includes(window.MY_TEAM_SHORTNAME.toUpperCase())) {
                    tr.classList.add('row-myteam');
                }

                tr.innerHTML = `
                    <td>${posizione}</td>
                    <td>${nomeVisualizzato}</td>
                    <td><strong>${puntiClassifica}</strong></td>
                    <td>${squadraDati.vittorie}</td>
                    <td>${squadraDati.sconfitte}</td>
                    <td>${squadraDati.puntiFatti}</td>
                    <td>${squadraDati.puntiSubiti}</td>
                `;
            }
            return tr;
        };

        if (tbodyModal) tbodyModal.appendChild(creaTr());
        if (tbodyFissa) tbodyFissa.appendChild(creaTr());
    };

    // ==========================================
    // MAPPATURA CABLATA DIRETTAMENTE SUI CORRISPETTIVI ID MATCH
    // ==========================================
    const matchG68 = globalMatches.find(m => m.id === 'G68'); // Finale 1°-2° Posto
    const matchG67 = globalMatches.find(m => m.id === 'G67'); // Finale 3°-4° Posto
    const matchG65 = globalMatches.find(m => m.id === 'G65'); // Finale 5°-6° Posto
    const matchG66 = globalMatches.find(m => m.id === 'G66'); // Finale 7°-8° Posto

    // Funzione helper locale per verificare ed estrarre i dati reali in modo sicuro e rigido
    const estraiEsitoPartitaCablata = (match) => {
        if (!match) return null;
        
        const puntiAStr = match.puntiA !== undefined && match.puntiA !== null ? String(match.puntiA).trim() : '';
        const puntiBStr = match.puntiB !== undefined && match.puntiB !== null ? String(match.puntiB).trim() : '';

        // Se le celle del punteggio sono vuote nel foglio, non consideriamo la partita conclusa
        if (puntiAStr === '' || puntiBStr === '') return null;

        const puntiA = Number(puntiAStr);
        const puntiB = Number(puntiBStr);

        if (isNaN(puntiA) || isNaN(puntiB)) return null;

        const vincente = (puntiA > puntiB) ? match.squadraA : match.squadraB;
        const perdente = (puntiA > puntiB) ? match.squadraB : match.squadraA;

        if (vincente === 'Da definire' || vincente === '' || perdente === 'Da definire' || perdente === '') return null;

        return [vincente, perdente];
    };

    const esito1_2 = estraiEsitoPartitaCablata(matchG68);
    const esito3_4 = estraiEsitoPartitaCablata(matchG67);
    const esito5_6 = estraiEsitoPartitaCablata(matchG65);
    const esito7_8 = estraiEsitoPartitaCablata(matchG66);


    // --- RENDERING POSIZIONI DA 1 A 8 ---

    // Posizioni 1 e 2 (In base alla partita cablata G56)
    if (esito1_2) {
        const dati = calcolaStatisticheStoriche(esito1_2, true);
        aggiungiRigaInTabella(1, dati[0]);
        aggiungiRigaInTabella(2, dati[1]);
    } else {
        aggiungiRigaInTabella(1, null, true);
        aggiungiRigaInTabella(2, null, true);
    }

    // Posizioni 3 e 4 (In base alla partita cablata G67)
    if (esito3_4) {
        const dati = calcolaStatisticheStoriche(esito3_4, true);
        aggiungiRigaInTabella(3, dati[0]);
        aggiungiRigaInTabella(4, dati[1]);
    } else {
        aggiungiRigaInTabella(3, null, true);
        aggiungiRigaInTabella(4, null, true);
    }

    // Posizioni 5 e 6 (In base alla partita cablata G65)
    if (esito5_6) {
        const dati = calcolaStatisticheStoriche(esito5_6, true);
        aggiungiRigaInTabella(5, dati[0]);
        aggiungiRigaInTabella(6, dati[1]);
    } else {
        aggiungiRigaInTabella(5, null, true);
        aggiungiRigaInTabella(6, null, true);
    }

    // Posizioni 7 e 8 (In base alla partita cablata G66)
    if (esito7_8) {
        const dati = calcolaStatisticheStoriche(esito7_8, true);
        aggiungiRigaInTabella(7, dati[0]);
        aggiungiRigaInTabella(8, dati[1]);
    } else {
        aggiungiRigaInTabella(7, null, true);
        aggiungiRigaInTabella(8, null, true);
    }


    // ==========================================
    // 2. ANALISI POSIZIONI 9 - 16 (OTTAVI)
    // ==========================================
    const matchOttavi = globalMatches.filter(m => m.fase && m.fase.toUpperCase() === 'OTTAVI');
    const recordOttavi = [];
    matchOttavi.forEach(match => {
        if (match.puntiA === '' || match.puntiB === '') return;
        const puntiA = Number(match.puntiA); const puntiB = Number(match.puntiB);
        let perdente = (puntiA < puntiB) ? match.squadraA : match.squadraB;
        if (perdente && perdente !== 'Da definire' && !recordOttavi.includes(perdente)) recordOttavi.push(perdente);
    });
    const ottaviOrdinati = calcolaStatisticheStoriche(recordOttavi);

    for (let i = 0; i < 8; i++) {
        const posizione = 9 + i;
        if (ottaviOrdinati[i]) aggiungiRigaInTabella(posizione, ottaviOrdinati[i], false);
        else aggiungiRigaInTabella(posizione, null, true);
    }

    // ==========================================
    // 3. ANALISI POSIZIONI 17 - 32 (SEDICESIMI)
    // ==========================================
    const matchSedicesimi = globalMatches.filter(m => m.fase && m.fase.toUpperCase() === 'SEDICESIMI');
    const recordSedicesimi = [];
    matchSedicesimi.forEach(match => {
        if (match.puntiA === '' || match.puntiB === '') return;
        const puntiA = Number(match.puntiA); const puntiB = Number(match.puntiB);
        let perdente = (puntiA < puntiB) ? match.squadraA : match.squadraB;
        if (perdente && perdente !== 'Da definire' && !recordSedicesimi.includes(perdente)) recordSedicesimi.push(perdente);
    });
    const sedicesimiOrdinati = calcolaStatisticheStoriche(recordSedicesimi);

    for (let i = 0; i < 16; i++) {
        const posizione = 17 + i;
        if (sedicesimiOrdinati[i]) aggiungiRigaInTabella(posizione, sedicesimiOrdinati[i], false);
        else aggiungiRigaInTabella(posizione, null, true);
    }
}

/**
 * Funzione di inizializzazione dello startup
 */
function init() {
    // 1. Inizializzazione dei riferimenti DOM
    container = document.getElementById('panzoom-container');
    if (!container) return;
    
    wrapper = document.getElementById('panzoom-wrapper');
    bracket = document.getElementById('tournament-bracket');
    selectMode = document.getElementById('display-mode');
    posterOverlay = document.getElementById('poster-overlay');
    searchTeam1 = document.getElementById('search-team-1');
    searchTeam2 = document.getElementById('search-team-2');

    // 2. Configurazione del timer per nascondere il poster automaticamente
    const posterTimeout = setTimeout(hidePoster, 3000);

    if (posterOverlay) {
        posterOverlay.addEventListener('click', () => {
            clearTimeout(posterTimeout);
            hidePoster();
        });
    }

    // 3. Configurazione degli Event Listener del Mouse per il Panzoom
    container.addEventListener('mousedown', (e) => {
        if(e.target.closest('button') || e.target.closest('select') || e.target.closest('.search-panel')) return;
        isDragging = true;
        start = { x: e.clientX - pointX, y: e.clientY - pointY };
    });

    window.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        pointX = e.clientX - start.x;
        pointY = e.clientY - start.y;
        updateTransform();
    });

    window.addEventListener('mouseup', () => { isDragging = false; });

    container.addEventListener('wheel', (e) => {
        e.preventDefault();
        const xs = (e.clientX - pointX) / scale;
        const ys = (e.clientY - pointY) / scale;
        if (e.deltaY < 0) scale += 0.05;
        else scale -= 0.05;
        pointX = e.clientX - xs * scale;
        pointY = e.clientY - ys * scale;
        updateTransform();
    }, { passive: false });

    // 4. Configurazione degli Event Listener Touch per Mobile
    container.addEventListener('touchstart', (e) => {
        if(e.target.closest('button') || e.target.closest('select') || e.target.closest('.search-panel')) return;
        if (e.touches.length === 1) {
            isDragging = true;
            start = { x: e.touches[0].clientX - pointX, y: e.touches[0].clientY - pointY };
        } else if (e.touches.length === 2) {
            isDragging = false;
            touchStartDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
            touchStartScale = scale;
        }
    });

    container.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1 && isDragging) {
            pointX = e.touches[0].clientX - start.x;
            pointY = e.touches[0].clientY - start.y;
            updateTransform();
        } else if (e.touches.length === 2) {
            const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
            const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
            const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
            const xs = (midX - pointX) / scale;
            const ys = (midY - pointY) / scale;
            scale = touchStartScale * (dist / touchStartDist);
            pointX = midX - xs * scale;
            pointY = midY - ys * scale;
            updateTransform();
        }
    });

    container.addEventListener('touchend', (e) => {
        if (e.touches.length === 0) isDragging = false;
        else if (e.touches.length === 1) {
            isDragging = true;
            start = { x: e.touches[0].clientX - pointX, y: e.touches[0].clientY - pointY };
        }
    });

    // 5. Configurazione Pulsanti Controllo e Filtri
    document.getElementById('zoom-in').addEventListener('click', () => { scale += 0.1; updateTransform(); });
    document.getElementById('zoom-out').addEventListener('click', () => { scale -= 0.1; updateTransform(); });
    document.getElementById('zoom-reset').addEventListener('click', resetZoomAndHighlights);

    selectMode.addEventListener('change', () => {
        if (globalMatches.length > 0) {
            renderBracket(globalMatches);
            findAndHighlightIntersection();
            renderClassificaModal();
        }
    });

    searchTeam1.addEventListener('change', findAndHighlightIntersection);
    searchTeam2.addEventListener('change', findAndHighlightIntersection);

    window.addEventListener('resize', () => {
        if(document.querySelector('.match-box')) drawConnectorLines();
    });

    const modal = document.getElementById('classifica-modal');
    const btnShow = document.getElementById('show-classifica');
    const btnClose = document.getElementById('close-classifica');

    if (btnShow && modal) {
        btnShow.addEventListener('click', () => {
            renderClassificaModal(); // Calcola e renderizza i dati freschi
            modal.classList.add('open');
        });
    }

    if (btnClose && modal) {
        btnClose.addEventListener('click', () => {
            modal.classList.remove('open');
        });
    }

    // Chiude il modale anche se si clicca fuori dalla finestra bianca
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('open');
        }
    });

    // 6. Caricamento iniziale dei dati
    fetchBracketData();
}

// Avvia l'inizializzazione non appena il DOM è pronto
document.addEventListener('DOMContentLoaded', init);
