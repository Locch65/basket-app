window.userNavigatedToEnd = false;
let bloccoSincronizzazioneManuale = false;
let currentHighlightIndex = -1; // -1 significa che nessun highlight è ancora selezionato

let lsListWasOpen = false;
let lsFilterWasOpen = false;
let lsListSide = 'left'; // Stato iniziale: 'left', 'right', o 'hidden'
let previewRefreshInterval = null; // Gestore per l'aggiornamento automatico
let selectedPlayerIds = []; // Array degli ID giocatori selezionati
let selectedPuntiFilters = ["0", "1", "2", "3"]; // Array dei tiri selezionati di default ---

//#region GESTIONE HIGHLIGHTS LANDSCAPE

function injectLandscapeHTML() {
    const hudOverlay = document.getElementById('hud-overlay');
    if (!hudOverlay) return;

    // Logica per lo stato iniziale del checkbox Auto
    // Default: disabilitato se admin, abilitato altrimenti
    const autoChecked = (typeof window.isAdmin !== 'undefined' && window.isAdmin) ? '' : 'checked';

    // Definiamo il bottone Fix Time solo se isAdmin è true
    const fixTimeBtn = (typeof window.isAdmin !== 'undefined' && window.isAdmin) 
        ? `<button id="ls-nav-fixtime" class="btn-fixtime" disabled><i class="fas fa-clock"></i> Fix Time</button>` 
        : '';

    const landscapeHTML = `
        <div id="landscape-controls" class="landscape-only hidden">
            <button id="ls-star-btn" class="ls-icon-btn">
                <i class="fas fa-star"></i>
            </button>
            <div id="ls-control-bar" class="ls-bar-hidden">
                <button id="ls-list-trigger-btn" class="ls-list-trigger">
                    <i id="ls-list-arrow" class="fas fa-chevron-right"></i>
                </button>
                <div class="ls-nav-container"> 
                    <div id="ls-preview-label">Seleziona un evento...</div>
                    
                    <div class="ls-nav-group">
                        <div class="ls-auto-wrapper">
                            <input type="checkbox" id="ls-auto-next" ${autoChecked}>
                            <label for="ls-auto-next">AutoSkip</label>
                        </div>

                        <button id="ls-nav-start"><i class="fas fa-fast-backward"></i></button>
                        <button id="ls-nav-prev"><i class="fas fa-step-backward"></i></button>
                        <button id="ls-nav-next"><i class="fas fa-step-forward"></i></button>
                        <button id="ls-nav-end""><i class="fas fa-fast-forward"></i></button>

                        ${fixTimeBtn}
                        <button id="ls-nav-filter" class="btn-filter"><i class="fas fa-filter"></i></button>
                    </div>
                </div>
            </div>
            <div id="ls-event-list" class="ls-list-hidden">
                <div id="ls-list-content"></div>
            </div>
            <div id="ls-filter-panel" class="ls-filter-panel-hidden">
                <div class="ls-filter-header">
                    <div class="ls-filter-item">
                        <input type="checkbox" id="ls-filter-all" checked>
                        <label for="ls-filter-all">TUTTI / NESSUNO</label>
                    </div>
                </div>
                <div id="ls-filter-list" class="ls-filter-body"></div>
            </div>

        </div>
    `;

    // Inseriamo l'HTML come ultimo figlio
    hudOverlay.insertAdjacentHTML('beforeend', landscapeHTML);
    
    // Colleghiamo i listener ai nuovi elementi creati
    setupLandscapeListeners();
}

function setupLandscapeListeners() {
    // Funzione helper per fermare la propagazione
    const stopProp = (e) => e.stopPropagation();


    const autoNextCheckbox = document.getElementById('ls-auto-next');
    if (autoNextCheckbox) {
        autoNextCheckbox.onchange = (e) => {
            updateFixTimeVisibility();
        }
    }

    const starBtn = document.getElementById('ls-star-btn');
    starBtn?.addEventListener('click', (e) => {
        stopProp(e);
        toggleLsHighlightBar(e);

        renderFilterList();
        aggiornaUIHighlight(true);

        updateFixTimeVisibility();
    });
    
    document.getElementById('ls-list-trigger-btn')?.addEventListener('click', (e) => {
        stopProp(e);
        toggleLsEventList(e);
        updateFixTimeVisibility();
    });

    document.getElementById('ls-nav-filter')?.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFilterPanel();
    });
    
    // Selettore per tutti i bottoni nella barra di controllo
    const navButtons = document.querySelectorAll('.ls-nav-group button');
    navButtons.forEach(btn => {
        if (btn.id === 'ls-nav-fixtime') return;
        btn.addEventListener('click', (e) => {
            stopProp(e); // CRITICO: Ferma il click prima che arrivi a YouTube
            const action = btn.id.replace('ls-nav-', '');
            window.gestisciHighlight(action);
        });
        
        // Aggiungi anche questo per sicurezza sui dispositivi touch
        btn.addEventListener('touchstart', stopProp, {passive: true});
    });

    // Aggiungiamo il listener per il nuovo bottone Fix Time
    const fixTimeBtn = document.getElementById('ls-nav-fixtime');
    if (fixTimeBtn) {
        fixTimeBtn.addEventListener('click', (e) => {
            stopProp(e);
            handleFixTime();
        });
    }

    applicaProtezioneClickLS();
}

function getConvocatiFiltrati() {
    try {
        // 1. Converte la stringa "[4,5,11,31]" in un array di numeri
        const numeriConvocati = JSON.parse(window.convocazioni); 

        // 2. Filtra giocatoriObj per i nostri giocatori
        const mieiGiocatori = window.giocatoriObj.filter(g => numeriConvocati.includes(parseInt(g.numero)));

        // 3. Aggiunge l'elemento AVVERSARI in fondo
        mieiGiocatori.push({
            id: "AVVERSARI", // ID speciale usato in fullMatchHistory per i non-idGiocatore
            numero: "-",
            cognome: "AVVERSARI",
            isAvversario: true
        });

        return mieiGiocatori;
    } catch (e) {
        console.error("Errore nel recupero convocati:", e);
        return [];
    }
}

function renderFilterList() {
    const container = document.getElementById('ls-filter-list');
    const checkAll = document.getElementById('ls-filter-all');
    if (!container) return;

    const convocati = getConvocatiFiltrati();
    container.innerHTML = '';
    
    // Inizializzazione: se l'array dei filtri è vuoto, selezioniamo tutto (inclusi avversari)
    if (selectedPlayerIds.length === 0 && (checkAll && checkAll.checked)) {
        selectedPlayerIds = convocati.map(g => g.numero);
    }

    convocati.forEach(g => {
        const item = document.createElement('div');
        item.className = 'ls-filter-item';
        const isChecked = selectedPlayerIds.includes(g.numero);
        
        // 1. Manteniamo il numero originale così com'è (senza zeri aggiunti)
        const numeroFormattato = (g.numero !== undefined && g.numero !== null && !g.isAvversario)
            ? g.numero
            : '';

        // 2. Lo span ha text-align: right, quindi i numeri a una cifra lasceranno lo spazio a sinistra
        const labelText = g.isAvversario 
            ? `<span style="display: inline-block; width: 20px; text-align: right; margin-right: 10px;"></span>${g.cognome}`
            : `<span style="display: inline-block; width: 20px; text-align: right; margin-right: 10px; font-variant-numeric: tabular-nums;">${numeroFormattato}</span>${g.cognome}`;
        
        item.innerHTML = `
            <input type="checkbox" id="filter-${g.numero}" ${isChecked ? 'checked' : ''}>
            <label for="filter-${g.numero}" style="display: inline-flex; align-items: center; cursor: pointer; width: 100%;">
                ${labelText}
            </label>
        `;

        // Impediamo che il click sul checkbox chiuda la barra o causi azioni sul video
        item.addEventListener('click', (e) => e.stopPropagation());

        item.querySelector('input').addEventListener('change', (e) => {
            if (e.target.checked) {
                if (!selectedPlayerIds.includes(g.numero)) selectedPlayerIds.push(g.numero);
            } else {
                selectedPlayerIds = selectedPlayerIds.filter(id => id !== g.numero);
                if (checkAll) checkAll.checked = false;
            }
            applyFilters();
        });

        container.appendChild(item);
    });
    
    // Logica Tutti / Nessuno
    if (checkAll) {
        checkAll.onchange = (e) => {
            const checked = e.target.checked;
            selectedPlayerIds = checked ? convocati.map(g => g.numero) : [];
            renderFilterList(); 
            applyFilters();
        };
    }

    // FILTRO PUNTI CON CHECKBOX IN FONDO AL PANNELLO ---
    let puntiContainer = document.getElementById('ls-filter-punti-container');
    if (!puntiContainer) {
        puntiContainer = document.createElement('div');
        puntiContainer.id = 'ls-filter-punti-container';
        puntiContainer.style.cssText = "padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.1); font-family: sans-serif;";
        
        puntiContainer.innerHTML = `
            <div style="font-weight: bold; margin-bottom: 8px; font-size: 0.9rem; color: white;">Filtra per Punti:</div>
            <div style="display: flex; gap: 10px; font-size: 1rem; color: white;">
                <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                    <input type="checkbox" class="ls-punti-check" value="0" ${selectedPuntiFilters.includes("0") ? 'checked' : ''}> T0
                </label>
                <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                    <input type="checkbox" class="ls-punti-check" value="1" ${selectedPuntiFilters.includes("1") ? 'checked' : ''}> T1
                </label>
                <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                    <input type="checkbox" class="ls-punti-check" value="2" ${selectedPuntiFilters.includes("2") ? 'checked' : ''}> T2
                </label>
                <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                    <input type="checkbox" class="ls-punti-check" value="3" ${selectedPuntiFilters.includes("3") ? 'checked' : ''}> T3
                </label>
            </div>
        `;

        puntiContainer.addEventListener('click', (e) => e.stopPropagation());

        puntiContainer.querySelectorAll('.ls-punti-check').forEach(cb => {
            cb.addEventListener('change', (e) => {
                const val = e.target.value;
                if (e.target.checked) {
                    if (!selectedPuntiFilters.includes(val)) selectedPuntiFilters.push(val);
                } else {
                    selectedPuntiFilters = selectedPuntiFilters.filter(p => p !== val);
                }
                applyFilters();
            });
        });

        container.parentElement.appendChild(puntiContainer);
    }
}

function applyFilters() {
    const btn = document.getElementById('ls-nav-filter');
    const convocati = getConvocatiFiltrati();
    
    // Il bottone diventa giallo se non tutti i convocati sono selezionati OPPURE se non tutti i tiri sono selezionati
    if (selectedPlayerIds.length < convocati.length || selectedPuntiFilters.length < 4) {
        btn.classList.add('ls-btn-filter-active');
    } else {
        btn.classList.remove('ls-btn-filter-active');
    }

    // Rerender della lista eventi
    aggiornaUIHighlight(false); 
}

function applicaProtezioneClickLS() {
    const lsControlBar = document.getElementById('ls-control-bar');
    const lsEventList = document.getElementById('ls-event-list');
    const lsStarBtn = document.getElementById('ls-star-btn');
    const lsFilterPanel = document.getElementById('ls-filter-panel');
    const autoWrapper = document.querySelector('.ls-auto-wrapper');

    // Funzione generica per bloccare la propagazione se non si clicca su un elemento interattivo
    const stopPropagationIfEmpty = (e) => {
        // Permettiamo il click se il target è un bottone, un input (checkbox) o una label
        if (!e.target.closest('button') && !e.target.closest('input') && !e.target.closest('label')) {
            e.stopPropagation();
        }
    };

    // 1. Control Bar
    if (lsControlBar) {
        ['click', 'mousedown', 'dblclick'].forEach(evt => {
            lsControlBar.addEventListener(evt, stopPropagationIfEmpty);
        });
    }

    // 2. Lista Eventi
    if (lsEventList) {
        ['click', 'mousedown', 'dblclick', 'wheel', 'touchstart'].forEach(evt => {
            lsEventList.addEventListener(evt, (e) => {
                // Blocca tutto tranne il click sugli item effettivi della lista
                if (!e.target.closest('.ls-event-item')) {
                    e.stopPropagation();
                }
            });
        });
    }

    // 3. Pannello Filtri (Nuovo)
    if (lsFilterPanel) {
        // Nel pannello filtri vogliamo uno "scudo" totale per evitare che 
        // lo scroll della lista giocatori metta in pausa o skippi il video.
        ['click', 'mousedown', 'dblclick', 'wheel', 'touchstart'].forEach(evt => {
            lsFilterPanel.addEventListener(evt, (e) => {
                // Non usiamo stopPropagationIfEmpty perché qui vogliamo che 
                // TUTTO l'evento rimanga dentro il pannello, 
                // ma i checkbox funzioneranno comunque perché l'evento "bolle" (bubbles) 
                // dal checkbox fino a questo listener e non oltre.
                e.stopPropagation();
            });
        });
    }

    // 4. Bottone Stella
    if (lsStarBtn) {
        lsStarBtn.addEventListener('click', (e) => e.stopPropagation());
    }

    // 5. Wrapper Auto (Checkbox)
    if (autoWrapper) {
        autoWrapper.addEventListener('click', (e) => e.stopPropagation());
    }
}

/**
 * Inizializza l'interfaccia: inietta l'HTML e imposta i listener
 */
window.initHighlightsInterface = initHighlightsInterface;
function initHighlightsInterface() {
    // 1. Inietta l'HTML nell'HUD
    injectLandscapeHTML();

    // 2. Listener per rotazione e caricamento
    window.addEventListener('resize', gestisciCambioOrientamento);
    window.addEventListener('load', gestisciCambioOrientamento);

    // 3. Listener per il tocco sul video (Mostra/Nasconde UI in landscape)
    const videoContainer = document.querySelector('.video-container');
    if (videoContainer) {
        videoContainer.addEventListener('click', (e) => {
            if (window.innerWidth > window.innerHeight) { 
                const controls = document.getElementById('landscape-controls');
                if (controls) controls.classList.toggle('hidden');
            }
        });
    }
}

function toggleLsHighlightBar(event) {
    if (event) event.stopPropagation();
    const bar = document.getElementById('ls-control-bar');
    const list = document.getElementById('ls-event-list');
    const arrow = document.getElementById('ls-list-arrow');
    const filterPanel = document.getElementById('ls-filter-panel');
    const timeline = document.getElementById('time-line-slider');
    if (!bar) return;

    const isBarOpening = bar.classList.toggle('ls-bar-hidden'); // Se toggle restituisce true, la barra è nascosta
    
    // NOTA: classList.toggle restituisce true se la classe è stata AGGIUNTA (quindi barra nascosta)
    // Se isBarOpening è false, significa che abbiamo rimosso 'ls-bar-hidden', quindi stiamo aprendo.
    if (!isBarOpening) {
        renderLsEventList();
        window.isReviewMode = true; 
        
        // Se la memoria dice che la lista era aperta, la riapriamo facendola scivolare da sinistra
        if (lsListWasOpen && list) {
            list.classList.add('ls-visible');
            if (arrow) arrow.style.transform = 'rotate(180deg)';

        }

        if (lsFilterWasOpen && filterPanel) {
            filterPanel.classList.add('ls-visible');
            filterPanel.classList.remove('ls-filter-panel-hidden');
        }
        //if (timeline) timeline.style.marginBottom = "32px";

    } else {
        // Stiamo chiudendo la barra di controllo
        if (list) {
            // Ricorda se la lista era aperta prima di chiudere tutto
            lsListWasOpen = list.classList.contains('ls-visible');
            
            // Chiudi la lista (animazione verso sinistra)
            list.classList.remove('ls-visible');
            if (arrow) arrow.style.transform = 'rotate(0deg)';

        }
        if (filterPanel) {
            lsFilterWasOpen = filterPanel.classList.contains('ls-visible');
            filterPanel.classList.remove('ls-visible');
            filterPanel.classList.add('ls-filter-panel-hidden');
        }

        window.isReviewMode = false;

        if (timeline) timeline.style.marginBottom = "8px";
    }
}

// --- GESTIONE UI LANDSCAPE ---
function toggleFilterPanel() {
    const panel = document.getElementById('ls-filter-panel');
    if (!panel) return;

    const isOpening = !panel.classList.contains('ls-visible');

    // gestione pannello filtri
    if (isOpening) {
        panel.classList.add('ls-visible');
        panel.classList.remove('ls-filter-panel-hidden');

    } else {
        panel.classList.remove('ls-visible');
        panel.classList.add('ls-filter-panel-hidden');
    }

    lsFilterWasOpen = panel.classList.contains('ls-visible');

    if (lsFilterWasOpen) renderFilterList();
}

function toggleLsEventList() {
    const list = document.getElementById('ls-event-list');
    const arrow = document.getElementById('ls-list-arrow');
    if (!list || !arrow) return;

    // Toggle della classe visibile
    const isOpening = !list.classList.contains('ls-visible');
    
    if (isOpening) {
        list.classList.add('ls-visible');
        arrow.style.transform = 'rotate(180deg)'; // La freccia punta verso l'interno (chiusura)
    } else {
        list.classList.remove('ls-visible');
        arrow.style.transform = 'rotate(0deg)'; // La freccia torna a puntare verso destra (apertura)
    }
    
    // Aggiorna lo stato del bottone Fix Time in base alla visibilità
    updateFixTimeVisibility();
}

function renderLsEventList() {
    aggiornaUIHighlight(false); return;
}


// --- GESTIONE ORIENTAMENTO ---

function gestisciCambioOrientamento() {
    const isLandscape = window.innerWidth > window.innerHeight;
    const lsControls = document.getElementById('landscape-controls');

    if (isLandscape) {
        const starBtn = document.getElementById('ls-star-btn');
        if (window.highlightsAvailable) {
            starBtn.style.display = 'block';
            if (lsControls) lsControls.classList.remove('hidden');
            if (typeof window.isReviewMode !== "undefined" && window.isReviewMode) {
                mostraBarraControlloLS();
            }
        }
    } else {
        if (lsControls) lsControls.classList.add('hidden');
        chiudiTuttoLS();
        if (window.NEW_PLAYER_INTERFACE) window.showStopVideoBtn();
    }
}

function mostraBarraControlloLS() {
    renderLsEventList();
    updatePreviewLabel();
    updateFixTimeVisibility();
}

function chiudiTuttoLS() {
    // Salviamo lo stato prima di forzare la chiusura per il cambio orientamento
    const list = document.getElementById('ls-event-list');
    if (list) {
        list.classList.remove('ls-visible');
    }

    document.getElementById('ls-control-bar')?.classList.add('ls-bar-hidden');
    document.getElementById('ls-event-list')?.classList.add('ls-list-hidden');

    document.getElementById('ls-filter-panel')?.classList.add('ls-filter-panel-hidden');
}

function updateFixTimeVisibility() {
    // 1. Controllo Autorità: Se non è admin, usciamo immediatamente
    if (typeof window.isAdmin === 'undefined' || !window.isAdmin) return;

    const fixTimeBtn = document.getElementById('ls-nav-fixtime');
    if (!fixTimeBtn) return;

    // 2. Controllo Selezione: 
    // currentHighlightIndex deve essere >= 0 (un evento reale) 
    // o comunque diverso dagli stati di "Inizio Diretta/Partita" se preferisci.
    // Usiamo >= -1 per includere "Inizio Partita" o > -1 per soli eventi reali.
    const hasSelection = currentHighlightIndex > -1; 

    const autoNextCheckbox = document.getElementById('ls-auto-next');
    const isAutoEnabled = autoNextCheckbox ? autoNextCheckbox.checked : false;
    const isEnabled = hasSelection && !isAutoEnabled;

    // 3. Abilitazione: Ora dipende solo dalla selezione dell'evento
    if (isEnabled) {
        fixTimeBtn.disabled = false;
        fixTimeBtn.style.opacity = "1"; // Assicuriamoci che sia ben visibile
    } else {
        fixTimeBtn.disabled = true;
        fixTimeBtn.style.opacity = "0.4"; // Feedback visivo per lo stato disabilitato
    }
}

function updatePreviewLabel() {
    const label = document.getElementById('ls-preview-label');
    if (!label) return;

    const ev = window.fullMatchHistory[currentHighlightIndex];
    if (!ev) {
        label.innerText = "";
        if (previewRefreshInterval) clearInterval(previewRefreshInterval);
        return;
    }

    const refreshText = () => {
        const isMyTeam = ev.idGiocatore && ev.idGiocatore !== "";
        const cognome = isMyTeam ? window.GetCognome(ev.idGiocatore) : "AVVERSARI";
        const punti = ev.puntiRealizzati || 0;

        // Usiamo la tua funzione di common.js
        const secEvento = hmsToSeconds(ev.timestampReale);
        const secAttuali = hmsToSeconds(window.orarioVisualizzatoFormattato);
        const diff = secAttuali - secEvento;
        
        const sign = diff >= 0 ? "+" : "";

        label.style.color = isMyTeam ? "#ffcc00" : "#ff4d4d";
        
        // Formato: COGNOME +PUNTI [HH:MM:SS] (+0s)
        label.innerText = `${cognome.toUpperCase()} +${punti} [${ev.timestampReale}] (${sign}${diff}s)`;
    };

    refreshText();

    if (previewRefreshInterval) clearInterval(previewRefreshInterval);
    previewRefreshInterval = setInterval(refreshText, 1000);
}

function handleFixTime() {
    // 1. Recuperiamo l'evento selezionato usando l'indice corrente
    const event = window.fullMatchHistory[currentHighlightIndex];

    // Controllo di sicurezza: se non c'è una selezione, esciamo
    if (!event) {
        console.error("Nessun evento selezionato!");
        return;
    }

    window.modifyToServerTimeStampEventoLive("fixtime", event.timestampReale, event.idGiocatore, event.puntiRealizzati, window.orarioVisualizzatoFormattato);

    window.fullMatchHistory[currentHighlightIndex].timestampReale = window.orarioVisualizzatoFormattato;
    renderLsEventList();
    window.gestisciHighlight('next');
    console.log("Evento idx:", currentHighlightIndex);
    console.log("Dati evento:", window.fullMatchHistory[currentHighlightIndex]);
    console.log("Bottone Fix Time premuto: cambiato ora evento con " + window.orarioVisualizzatoFormattato);

}
//#endregion

//#region GESTIONE HIGHLIGHTS PORTRAIT
window.controllaDisponibilitaHighlights = controllaDisponibilitaHighlights;
function controllaDisponibilitaHighlights() {
  const btnToggle = document.getElementById('toggle-highlights');
  const highlightsContainer = document.getElementById('highlights-container'); // Il div che contiene la lista
  const section = document.getElementById('highlights-section');
  const btnGrafico = document.getElementById('btn-apri-grafico')
  const btnTop5 = document.getElementById('btn-apri-Top5')
  const starBtn = document.getElementById('ls-star-btn');

  if (window.highlightsAvailable) {
    [btnToggle, btnGrafico, btnTop5].forEach(b => {
        if (b) {
            b.disabled = false;
            b.style.opacity = "1";
            b.style.cursor = "pointer";
        }
    });    
    // Assicurati che la sezione contenitore sia visibile (ma non necessariamente aperta)
    if (section) section.style.display = "flex"; 

    // mostra la stellina in landscape
    starBtn.style.display = 'block';

  } else {
    [btnToggle, btnGrafico, btnTop5].forEach(b => {
        if (b) {
            b.disabled = true;
            b.style.opacity = "0.5";
            b.style.cursor = "not-allowed";
        }
    });    

    // OPZIONALE: Se gli highlights erano aperti, li chiudiamo
    if (highlightsContainer) {
      highlightsContainer.classList.add('hidden');
    }
    // nasconde la stellina in landscape
    starBtn.style.display = 'none';
  }
}

window.toggleHighlights = toggleHighlights;
function toggleHighlights(forzaStato) {
  if (!window.highlightsAvailable) return;

  const btnToggle = document.getElementById('toggle-highlights');
  const controls = document.getElementById('highlights-controls');
  const label = document.getElementById('highlight-label');
  const btnGrafico = document.getElementById('btn-apri-grafico');
  const btnTop5 = document.getElementById('btn-apri-Top5');

  // Recuperiamo lo span che contiene il testo dentro il bottone
  const btnText = btnToggle?.querySelector('.text-label');

  // Determina se mostrare o nascondere:
  // Se forzaStato è definito (true/false) usa quello, altrimenti fa il toggle invertendo lo stato attuale
  const isNowVisible = forzaStato !== undefined 
    ? forzaStato 
    : !controls.classList.contains('show');

  // Applica lo stato alla classe (se isNowVisible è true aggiunge 'show', se false la rimuove)
  controls.classList.toggle('show', isNowVisible);

  if (isNowVisible) {
    // --- APERTURA ---
    btnToggle?.classList.replace('btn-toggle-off', 'btn-toggle-on');
    
    [btnGrafico, btnTop5].forEach(b => {
      if (b) b.style.display = 'none';
    });

    // RIMUOVI IL TESTO DAL BOTTONE
    if (btnText) btnText.textContent = ""; 

    if (label) {
      label.style.display = 'block';
      label.innerText = "Seleziona un'azione";
    }
    
    inizializzaHighlights();
    window.isReviewMode = true;
  } else {
    // --- CHIUSURA ---
    btnToggle?.classList.replace('btn-toggle-on', 'btn-toggle-off');
    
    [btnGrafico, btnTop5].forEach(b => {
      if (b) b.style.display = 'flex';
    });

    // RIPRISTINA IL TESTO NEL BOTTONE
    if (btnText) btnText.textContent = "Highlights";

    currentHighlightIndex = -1;

    if (label) {
      label.style.display = 'none';
      label.innerText = "";
    }
    window.isReviewMode = false;

    // quando esco dagli Highlights da un video live, vai alla diretta.
    if (typeof isLiveStream === 'function' && isLiveStream()) {
      window.syncToLive();
    }
  }
}

function inizializzaHighlights() {
  // Rimosso il controllo if (currentHighlightIndex >= 0) per permettere il reset
  if (window.fullMatchHistory && window.fullMatchHistory.length > 0) {
    //window.highlightsAvailable = true;
    currentHighlightIndex = (window.matchStartTime > 0) ? -2 : -1;; // Indichiamo che siamo prima del primo evento

    // inserisci in selectedPlayerIds la lista dei giocatori convocati, altrimenti non troverà nessun evento
    const convocati = getConvocatiFiltrati()
    selectedPlayerIds = convocati.map(g => g.numero);

    window.controllaDisponibilitaHighlights();
    aggiornaUIHighlight();
  }
}

window.gestisciHighlight = gestisciHighlight;
function gestisciHighlight(azione) {
    if (!window.fullMatchHistory) return;

    // 1. GENERIAMO LA LISTA DEGLI ID LOGICI ATTUALMENTE VISIBILI (FILTRATI)
    // Questa logica deve essere identica a quella che usi in aggiornaUIHighlight
    const timelineVisibile = [];
    
    // Inseriamo sempre i messaggi di sistema (Inizio/Fine) perché sono sempre visibili
    timelineVisibile.push(-2); // Inizio Diretta
    if (window.matchStartTime > 0) timelineVisibile.push(-1); // Inizio Partita

    window.fullMatchHistory.forEach((ev, idx) => {
        if (ev.eventType === "punto") {
            const isMyTeam = ev.idGiocatore && ev.idGiocatore !== "";
            const puntiStr = String(ev.puntiRealizzati || 0); // Converte in stringa ("0", "1", "2", "3")
            
            // Applichiamo il filtro combinato Giocatori + Punti
            if (selectedPlayerIds.length > 0 && selectedPuntiFilters.includes(puntiStr)) {
                if (isMyTeam) {
                    if (selectedPlayerIds.includes(String(ev.idGiocatore))) {
                        timelineVisibile.push(idx);
                    }
                } else {
                    if (selectedPlayerIds.includes("-")) {
                        timelineVisibile.push(idx);
                    }
                }
            }
        }
    });

    timelineVisibile.push(window.fullMatchHistory.length); // Fine Diretta

    // 2. TROVIAMO LA POSIZIONE ATTUALE NELLA TIMELINE FILTRATA
    let vIndex = timelineVisibile.indexOf(currentHighlightIndex);
    
    // Se l'indice attuale non è nella lista (magari è stato appena filtrato fuori),
    // troviamo quello più vicino o resettiamo al primo disponibile
    if (vIndex === -1) {
        vIndex = 0;
    }

    window.userNavigatedToEnd = false;

    // 3. LOGICA DI NAVIGAZIONE SULLA LISTA FILTRATA
    switch (azione) {
        case 'start':
            currentHighlightIndex = timelineVisibile[0];
            break;

        case 'prev':
            if (vIndex > 0) {
                currentHighlightIndex = timelineVisibile[vIndex - 1];
            }
            break;

        case 'next':
            if (vIndex < timelineVisibile.length - 1) {
                currentHighlightIndex = timelineVisibile[vIndex + 1];
                // Se siamo arrivati all'ultimo elemento (Fine Diretta)
                if (vIndex + 1 === timelineVisibile.length - 1) {
                    window.userNavigatedToEnd = true;
                }
            } else {
                window.userNavigatedToEnd = true;
            }
            break;

        case 'end':
            currentHighlightIndex = timelineVisibile[timelineVisibile.length - 1];
            window.userNavigatedToEnd = true;
            break;
    }

    // 4. ESECUZIONE AGGIORNAMENTO
    bloccoSincronizzazioneManuale = true;
    
    // Passiamo true per eseguire il seek effettivo nel video
    aggiornaUIHighlight(true);

}

window.sincronizzaIndiceHighlightColVideo = sincronizzaIndiceHighlightColVideo;
function sincronizzaIndiceHighlightColVideo() {
    // 1. Controlli preliminari (Uscita anticipata)
    if (!window.isReviewMode || !window.fullMatchHistory.length || !window.player || bloccoSincronizzazioneManuale) return;

    const isLandscape = window.innerWidth > window.innerHeight;
    const idElement = isLandscape ? 'ls-auto-next' : 'ls-auto-next-pt';

    const autoNextCheckbox = document.getElementById(idElement);
    const isAutoEnabled = autoNextCheckbox ? autoNextCheckbox.checked : false;

    // Se l'automatismo è spento, non vogliamo che il video cambi l'indice da solo
    if (window.isAdmin && !isAutoEnabled) return;

    // 2. GENERIAMO LA TIMELINE VISIBILE (Stessa logica di gestisciHighlight)
    const timelineVisibile = [];
    timelineVisibile.push(-2); // Inizio Diretta
    if (window.matchStartTime > 0) timelineVisibile.push(-1); // Inizio Partita

    window.fullMatchHistory.forEach((ev, idx) => {
        if (ev.eventType === "punto") {
            const isMyTeam = ev.idGiocatore && ev.idGiocatore !== "";
            const puntiStr = String(ev.puntiRealizzati || 0);

            // Filtro combinato Giocatori/Avversari + Punti
            if (selectedPlayerIds.length > 0 && selectedPuntiFilters.includes(puntiStr)) {
                if (isMyTeam) {
                    if (selectedPlayerIds.includes(String(ev.idGiocatore))) timelineVisibile.push(idx);
                } else {
                    if (selectedPlayerIds.includes("-")) timelineVisibile.push(idx);
                }
            }
        }
    });
    timelineVisibile.push(window.fullMatchHistory.length); // Fine Diretta

    // 3. CALCOLO DEI TEMPI
    const secondiVisualizzati = window.AppPlayer.getCurrentTime();
    const secondiInizioDiretta = hmsToSeconds(window.oraInizioDiretta);
    const DELAY_SUCCESSIVO = 3; 

    // 4. TROVIAMO QUALE DEGLI EVENTI *VISIBILI* CORRISPONDE AL TEMPO ATTUALE
    let nuovoIndice = timelineVisibile[0]; // Partiamo dal primo elemento visibile

    // Cicliamo solo sugli indici presenti nella timeline filtrata
    for (let i = 0; i < timelineVisibile.length; i++) {
        const idxLogico = timelineVisibile[i];
        
        // Se è un evento reale (non Inizio/Fine)
        if (idxLogico >= 0 && idxLogico < window.fullMatchHistory.length) {
            const ev = window.fullMatchHistory[idxLogico];
            let offsetEventoVideo = hmsToSeconds(ev.timestampReale) - secondiInizioDiretta;
            if (offsetEventoVideo < 0) offsetEventoVideo += 86400;

            // Se il video è ancora "dentro" la finestra di questo evento
            if (secondiVisualizzati < (offsetEventoVideo + DELAY_SUCCESSIVO)) {
                nuovoIndice = idxLogico;
                break; 
            }
        } else if (idxLogico === window.fullMatchHistory.length) {
            // Se siamo arrivati alla fine della timeline filtrata
            nuovoIndice = window.fullMatchHistory.length;
        }
    }

    // 5. PROTEZIONI E AGGIORNAMENTO
    // Non tornare mai indietro automaticamente se l'utente ha selezionato un punto più avanti
    if (nuovoIndice < currentHighlightIndex) {
        return; 
    }

    // Se l'indice è cambiato, aggiorniamo la UI
    if (nuovoIndice !== currentHighlightIndex) {
        currentHighlightIndex = nuovoIndice;
        
        // Usiamo false qui perché il video si sta già muovendo da solo (play naturale),
        // vogliamo solo che la lista si colori e scorra correttamente.
        aggiornaUIHighlight(isAutoEnabled); 
        
        updatePreviewLabel();
        updateFixTimeVisibility();
    }
}

function aggiornaUIHighlight(eseguiSeek = true) {
    const isLandscape = window.innerWidth > window.innerHeight;
    
    // Riferimenti UI
    const labelPortrait = document.getElementById('highlight-label');
    const containerLandscape = document.getElementById('ls-list-content');

    if (!window.fullMatchHistory) return;

    const timeline = [];
    let punteggioA = 0;
    let punteggioB = 0;

    // 1. COSTRUZIONE TIMELINE UNIFICATA E CALCOLO PUNTEGGI
    // Inseriamo l'evento "Inizio Diretta"
    timeline.push({
        tipo: 'DIRETTA',
        testo: `${window.oraInizioDiretta || "00:00:00"} INIZIO DIRETTA`,
        score: "0-0",
        seek: 0,
        isEventoReale: false,
        idLogico: -2
    });

    if (window.matchStartTime > 0) {
        timeline.push({
            tipo: 'PARTITA',
            testo: `${window.aggiungiSecondiAOrario(window.oraInizioDiretta, window.matchStartTime)} INIZIO PARTITA`,
            score: "0-0",
            seek: window.matchStartTime,
            isEventoReale: false,
            idLogico: -1
        });
    }

    window.fullMatchHistory.forEach((ev, idx) => {
        const isMyTeam = ev.idGiocatore && ev.idGiocatore !== "";
        const punti = parseInt(ev.puntiRealizzati || 0);
        const puntiStr = String(ev.puntiRealizzati || 0);

        const scorePrima = window.isMyTeam(window.teamA) ? `${punteggioA}-${punteggioB}` : `${punteggioB}-${punteggioA}`;

        if (ev.eventType === "punto") {
            // Calcolo punteggio sempre (per coerenza dei dati della partita)
            if (isMyTeam) punteggioA += punti;
            else punteggioB += punti;

            // --- LOGICA FILTRO MODIFICATA (Giocatori + Punti) ---
            // Se l'array dei giocatori è vuoto o il tipo di tiro non è selezionato, saltiamo l'evento
            if (selectedPlayerIds.length === 0 || !selectedPuntiFilters.includes(puntiStr)) {
                return; 
            }

            // Se l'array NON è vuoto, controlliamo le selezioni specifiche del giocatore
            if (isMyTeam) {
                if (!selectedPlayerIds.includes(String(ev.idGiocatore))) return;
            } else {
                if (!selectedPlayerIds.includes("-")) return;
            }
            // ----------------------------------------------------

            const cognome = isMyTeam ? window.GetCognome(ev.idGiocatore) : "AVVERSARI";
            const pStr = punti ? `+${punti}` : "0";
            
            // Note/Quarto
            let quarto = "-";
            try {
                const objNote = typeof ev.note === 'string' ? JSON.parse(ev.note) : ev.note;
                quarto = objNote?.quarto || "-";
            } catch(e) {}

            timeline.push({
                tipo: 'EVENTO',
                idxOriginale: idx,
                idLogico: idx,
                isMyTeam: isMyTeam,
                punti: punti,
                cognome: cognome,
                quarto: quarto,
                score: scorePrima,
                timestamp: ev.timestampReale,
                testo: `${pStr} ${cognome.substring(0, 12).padEnd(12, ' ')} - ${ev.timestampReale}`,
                seek: ev,
                isEventoReale: true
            });
        }
    });

    const durataVideo = typeof window.AppPlayer.getDuration === 'function' ? window.AppPlayer.getDuration() : 0;
    timeline.push({
        tipo: 'FINE',
        // testo: `FINE DIRETTA   - ${durataVideo > 0 ? window.aggiungiSecondiAOrario(window.oraInizioDiretta, durataVideo) : "--:--:--"}`,
        testo: `${durataVideo > 0 ? window.aggiungiSecondiAOrario(window.oraInizioDiretta, durataVideo) : "--:--:--"} FINE DIRETTA`,
        score: window.isMyTeam(window.teamA) ? `${punteggioA}-${punteggioB}` : `${punteggioB}-${punteggioA}`,
        seek: durataVideo,
        isEventoReale: false,
        idLogico: window.fullMatchHistory.length
    });

    // 2. AGGIORNAMENTO UI PORTRAIT
    if (labelPortrait) {
        const vIndex = timeline.findIndex(t => t.idLogico === currentHighlightIndex);
        if (vIndex !== -1) {
            const getRigaHTML = (index, isCorrente) => {
                if (index < 0 || index >= timeline.length) return "";
                const item = timeline[index];
                const classeSquadra = (item.isEventoReale && !item.isMyTeam) ? 'highlight-squadra-b' : 'highlight-squadra-a';
                const classeCorrente = isCorrente ? 'highlight-current' : '';
                const indicatore = isCorrente ? "===> " : "     ";
                const testoFormattato = item.testo.replace(/ /g, '&nbsp;');
                return `<div class="${classeSquadra} ${classeCorrente}">${indicatore}${testoFormattato}</div>`;
            };

            labelPortrait.innerHTML = [
                getRigaHTML(vIndex - 1, false),
                getRigaHTML(vIndex, true),
                getRigaHTML(vIndex + 1, false)
            ].filter(h => h !== "").join("");
        }
    }


    // 3. AGGIORNAMENTO UI LANDSCAPE (Unificato con logica Portrait)
    if (containerLandscape) {
        containerLandscape.innerHTML = "";
        
        timeline.forEach((item) => {
            const div = document.createElement('div');
            
            // Gestione classi CSS
            const isSelected = item.idLogico === currentHighlightIndex;
            let typeClass = "";
            
            if (item.isEventoReale) {
                typeClass = item.isMyTeam ? 'ls-item-myTeam' : 'ls-item-team-b';
            } else {
                typeClass = 'ls-item-system'; // Nuova classe per Inizio/Fine
            }
            
            div.className = `ls-event-item ${typeClass} ${isSelected ? 'selected' : ''}`;
            div.id = `ls-ev-${item.idLogico}`;
            
            // Rendering del contenuto basato sul tipo
            if (item.isEventoReale) {
                // Formato Canestro: [HH:MM:SS] Q1 0-0 +2 COGNOME
                const pStr = item.punti > 0 ? `+${item.punti}` : "0";
                div.innerHTML = `${item.timestamp} ${item.quarto} ${item.score.padEnd(5, ' ')} ${pStr.padStart(3, ' ')} ${item.cognome}`;
            } else {
                // Formato Sistema: [INIZIO PARTITA] -------- 0-0
                // Usiamo il .testo già generato nella timeline
                div.innerHTML = `${item.testo}`;
                div.style.fontStyle = "italic";
                div.style.opacity = "0.8";
            }

            div.onclick = (e) => {
                e.stopPropagation();
                // 1. Aggiorna l'indice globale
                currentHighlightIndex = item.idLogico; 
                
                // 2. Esegue il salto nel video
                if (item.isEventoReale) {
                    eseguiSeekHighlight(item.seek);
                } else {
                    window.AppPlayer.seekTo(item.seek, true);
                }
                
                // 3. REFRESH TOTALE: Questo aggiornerà sia la classe .selected in LS 
                // che la label a tre righe in Portrait (anche se sei in LS, i dati saranno pronti)
                aggiornaUIHighlight(false); 
                
                updatePreviewLabel();
                updateFixTimeVisibility();
            };

            
            containerLandscape.appendChild(div);
        });
        
        updatePreviewLabel();

        // Auto-scroll migliorato
        const activeItem = containerLandscape.querySelector('.ls-event-item.selected');
        if (activeItem) {
            activeItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    // 4. ESECUZIONE SEEK
    if (eseguiSeek) {
        const target = timeline.find(t => t.idLogico === currentHighlightIndex);
        if (target) {
            if (target.isEventoReale) eseguiSeekHighlight(target.seek);
            else window.AppPlayer.seekTo(target.seek, true);
        }
    }
}

function eseguiSeekHighlight(evento) {
  if (evento) {
    // BLOCCA la sincronizzazione automatica per evitare che "torni indietro"
    bloccoSincronizzazioneManuale = true;

    const input = document.getElementById('highlight-duration');
    const SHIFT_VIDEO_TIME = input ? parseInt(input.value) : 10;
    
    const secondiInizioVideo = hmsToSeconds(window.oraInizioDiretta);
    const secondiEvento = hmsToSeconds(evento.timestampReale);
    
    let diffSecondi = secondiEvento - secondiInizioVideo;
    if (diffSecondi < 0) diffSecondi += 86400; 
    
    const seekTime = diffSecondi - SHIFT_VIDEO_TIME;

    if (window.player && typeof window.AppPlayer.seekTo === 'function') {
        window.AppPlayer.seekTo(seekTime, true);
        
        // SBLOCCA dopo 2 secondi: tempo sufficiente affinché il player si posizioni
        // e la funzione di sincronizzazione veda il nuovo orario
        setTimeout(() => {
            bloccoSincronizzazioneManuale = false;
        }, 2000);
    }
  }
}

//#endregion
