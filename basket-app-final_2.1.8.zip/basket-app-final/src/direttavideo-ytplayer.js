window.pipConfig = {
    time: "",
    zoom: 2.5,
    size: 15, // % rispetto alla larghezza dello schermo
    aspectRatio: 1.77, // Aggiunto: 16 / 9 = 1.77
    skew: 0,
    xPerc: 0.5, 
    yPerc: 0.2,    
    xPos: 0.01,
    yPos: 0.01,
    initialized: true
};
let LIVE_OFFSET = 10; // se c'è un ritardo fra la live di Youtube e l'ora attuale, allora mostra l'orologino, altrimeni mostra il pallino rosso lampeggiante (live)
const sensitivity1 = 5.0; // <--- AMPLIFICATORE: 1.0 è reale, 3.0 triplica il movimento
const sensitivity2 = 3.0; // <--- AMPLIFICATORE: 1.0 è reale, 3.0 triplica il movimento
const pipConfig_top = "1%";
const pipConfig_right = "1%";
const pipConfig_border = "2px solid #ff0000";

let orarioVisualizzato = null;
let maxCurrentTime = 0;
let userIsBehindBecauseOfPause = false;
let playerPip; 
let isDragging = false;
let uiTimeout;
let currentZoom = 1;
let longPressTimer;
let isLongPressZoomActive = false;
let isDraggingPip = false;
let pipWasMoved = false;
let pipStartX, pipStartY; // Per memorizzare dove il dito/mouse ha toccato la PiP
const pipDragThreshold = 10; // Margine di 10px per distinguere tap da drag    
const playIcon = '<path d="M8 5v14l11-7z"/>';
const pauseIcon = '<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>';
let isSettingPip = false; 
let tempPipConfig; 
let playerCal;     
let frameCount = 0;
let calTimer; // Timer per la pressione continua
let isDraggingCal = false;

let initialPinchDistance = null;
let initialZoomAtPinch = 1;

let lastClickTime = 0;
const doubleClickDelay = 300; // Millisecondi entro cui considerare il secondo click

let calPoints = []; 
let pointLongPressTimer;
const LONG_PRESS_DURATION = 600; // millisecondi per attivare la selezione

//#region PLAYER_ADAPTER

// Costanti degli stati per uniformare Twitch all'ecosistema YouTube presente nella tua PWA
window.AppPlayerState = {
    UNSTARTED: -1,
    ENDED: 0,
    PLAYING: 1,
    PAUSED: 2,
    BUFFERING: 3,
    CUED: 5
};

window.activePlayerType = 'youtube'; // 'youtube' o 'twitch'
window.twitchPlayerInstance = null; // Istanza dell'Interactive Player di Twitch

// STATI INTERNI DI TWITCH (Tracciati tramite Event Listener nativi)
// Poiché Twitch non ha un metodo sincrono "getPlayerState()", salviamo lo stato corrente qui
window.currentTwitchState = window.AppPlayerState.UNSTARTED;

window.AppPlayer = {
    setPlaybackQuality: function(suggestedQuality) {
        if (window.activePlayerType === 'youtube') {
            if (window.player && typeof window.player.setPlaybackQuality === 'function') {
                window.player.setPlaybackQuality(suggestedQuality);
            }
        } else if (window.activePlayerType === 'twitch') {
            if (window.twitchPlayerInstance) {
                // Mappatura delle qualità standard di YouTube verso i formati Twitch
                let twitchQuality = suggestedQuality;
                
                switch(suggestedQuality.toLowerCase()) {
                    case 'hd1080':
                    case 'highres':
                        twitchQuality = '1080p'; // Twitch proverà a caricare 1080p o 1080p60 se disponibile
                        break;
                    case 'hd720':
                        twitchQuality = '720p'; // o 720p60
                        break;
                    case 'medium':
                        twitchQuality = '480p';
                        break;
                    case 'small':
                        twitchQuality = '360p';
                        break;
                    case 'tiny':
                        twitchQuality = '160p';
                        break;
                    case 'auto':
                    case 'default':
                        twitchQuality = 'auto'; // Gestione automatica del bitrate di Twitch
                        break;
                }

                // Verifica se la qualità richiesta è supportata dallo stream corrente prima di impostarla
                const availableQualities = window.twitchPlayerInstance.getQualities(); // Array di oggetti {group: "1080p", name: "1080p (source)"}
                const hasQuality = availableQualities.some(q => q.group === twitchQuality);

                if (hasQuality || twitchQuality === 'auto') {
                    window.twitchPlayerInstance.setQuality(twitchQuality);
                } else if (availableQualities.length > 0) {
                    // Fallback sulla prima qualità disponibile (generalmente la sorgente o l'auto)
                    console.warn(`Qualità Twitch '${twitchQuality}' non disponibile. Uso il default.`);
                }
            }
        }
    },
    getVideoData: function() {
        if (window.activePlayerType === 'youtube') {
            if (window.player && typeof window.player.getVideoData === 'function') {
                return window.player.getVideoData();
            }
            return { video_id: "", title: "", author: "" };
        } else if (window.activePlayerType === 'twitch') {
            if (window.twitchPlayerInstance) {
                // Recupera la configurazione corrente (canale o video VOD)
                const channel = window.twitchPlayerInstance.getChannel() || "";
                const videoId = window.twitchPlayerInstance.getVideo() || "";
                
                return {
                    video_id: videoId || channel, // Usa l'ID video se VOD, altrimenti il nome canale
                    author: channel || "Twitch Streamer",
                    title: videoId ? `Twitch VOD: ${videoId}` : `Twitch Live: ${channel}`,
                    is_twitch: true // Flag opzionale utile se nel codice devi fare controlli specifici
                };
            }
            return { video_id: "", title: "", author: "" };
        }
        return { video_id: "", title: "", author: "" };
    },
    getPlayerState: function() {
        if (window.activePlayerType === 'youtube') {
            if (window.player && typeof window.player.getPlayerState === 'function') {
                return window.player.getPlayerState();
            }
            return window.AppPlayerState.UNSTARTED;
        } else if (window.activePlayerType === 'twitch') {
            // Restituisce lo stato mappato in tempo reale dagli eventi di Twitch
            return window.currentTwitchState;
        }
        return window.AppPlayerState.UNSTARTED;
    },
    play: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.playVideo();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            window.twitchPlayerInstance.play();
        }
    },
    pause: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.pauseVideo();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            window.twitchPlayerInstance.pause();
        }
    },
    mute: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.mute();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            window.twitchPlayerInstance.setMuted(true);
        }
    },
    unMute: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.unMute();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            window.twitchPlayerInstance.setMuted(false);
        }
    },
    isMuted: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            return window.player.isMuted();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            return window.twitchPlayerInstance.getMuted();
        }
        return false;
    },
    getCurrentTime: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            return window.player.getCurrentTime();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            return window.twitchPlayerInstance.getCurrentTime();
        }
        return 0;
    },
    getDuration: function() {
        if (window.activePlayerType === 'youtube' && window.player) {
            return window.player.getDuration();
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            return window.twitchPlayerInstance.getDuration(); // Restituisce 0 se è una Live Stream su Twitch
        }
        return 0;
    },
    seekTo: function(seconds) {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.seekTo(seconds, true);
        } else if (window.activePlayerType === 'twitch' && window.twitchPlayerInstance) {
            window.twitchPlayerInstance.seek(seconds);
        }
    },
    setPlaybackRate: function(rate) {
        if (window.activePlayerType === 'youtube' && window.player) {
            window.player.setPlaybackRate(rate);
        }
        //ATTENZIONE: disabilitare in twitch la funzionalità
        // Nota: Twitch non supporta il cambio di velocità per i flussi Live Stream.
    }
};
//#endregion

//#region GESTIONE_TWITCH

// =======================================================
// GESTIONE EVENTI TWITCH PER AGGIORNARE LO STATO INTERNO
// =======================================================
function setupTwitchStateListeners() {
    if (!window.twitchPlayerInstance) return;

    // Quando la riproduzione comincia effettivamente
    window.twitchPlayerInstance.addEventListener(Twitch.Player.PLAY, () => {
        window.currentTwitchState = window.AppPlayerState.PLAYING;
        // Se nel codice principale usi una funzione di callback globale per il cambio stato (es. onPlayerStateChange)
        if (typeof window.onPlayerStateChange === 'function') {
            window.onPlayerStateChange({ data: window.AppPlayerState.PLAYING });
        }
    });

    // Quando viene premuto Pausa
    window.twitchPlayerInstance.addEventListener(Twitch.Player.PAUSE, () => {
        window.currentTwitchState = window.AppPlayerState.PAUSED;
        if (typeof window.onPlayerStateChange === 'function') {
            window.onPlayerStateChange({ data: window.AppPlayerState.PAUSED });
        }
    });

    // Quando il video si ferma o la live finisce
    window.twitchPlayerInstance.addEventListener(Twitch.Player.ENDED, () => {
        window.currentTwitchState = window.AppPlayerState.ENDED;
        if (typeof window.onPlayerStateChange === 'function') {
            window.onPlayerStateChange({ data: window.AppPlayerState.ENDED });
        }
    });
}

window.createTwitchPlayer = createTwitchPlayer;
function createTwitchPlayer(channelNameOrVideoId, isVOD = false) {
    // Nascondi YouTube e mostra Twitch
    document.getElementById('ytplayer').classList.add('hidden');
    document.getElementById('twitchplayer').classList.remove('hidden');
    window.activePlayerType = 'twitch';

    const options = {
        width: '100%',
        height: '100%',
        autoplay: false,
        muted: true,
        parent: ["localhost", 
            "locch65.github.io"] // Inserisci qui i tuoi domini di produzione/sviluppo
    };

    if (isVOD) {
        options.video = channelNameOrVideoId; // Se passi un ID numerico di un video registrato
    } else {
        options.channel = channelNameOrVideoId; // Se passi il nome del canale live
    }

    // Inizializza il player nello stesso wrapper dell'interfaccia
    window.twitchPlayerInstance = new Twitch.Player("twitchplayer", options);

    window.twitchPlayerInstance.addEventListener(Twitch.Player.READY, () => {
        console.log("✅ Player Twitch Pronto");
        // L'istanza nativa window.twitchPlayerInstance è già configurata, passiamo al setup della UI
        
        finalizeInitPlayer('twitch');
    });    
}

//#endregion

/**
 * Inietta dinamicamente l'interfaccia di controllo e l'overlay trasparente.
 * Chiamata all'interno di onPlayerReady.
 */
function injectYtControls() {
    if (document.getElementById('ui-layer')) return;

    const wrapper = document.getElementById('player-wrapper');
    
    const overlay = document.createElement('div');
    overlay.id = 'transparent-overlay';
    wrapper.appendChild(overlay);

    const centralPlayBtnHtml = `
        <div id="central-play-pause" class="central-control">
            <button id="btn-central-toggle" class="play-btn">
                <svg id="svg-central" viewBox="0 0 24 24" fill="white" width="64px" height="64px">
                    <path d="M8 5v14l11-7z"></path> </svg>
            </button>
        </div>
    `;
    // Creiamo la stringa per il bottone solo se isAdmin è vero
    // Se isAdmin è falso, la variabile sarà una stringa vuota
    const adminButton = window.isAdmin ? `
        <button id="btn-set-pip" title="Imposta PiP Tabellone">
            <svg viewBox="0 0 24 24"><path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14zm-10-7h9v6h-9z"/></svg>
        </button>` : '';

    const uiHTML = `
        <div id="ui-layer">
            <div class="timeline-container" id="time-line-slider">
                <input type="range" id="time-slider" min="0" value="0" step="1">
            </div>

            <div class="controls-bar">
                <div class="btn-group">
                    <button id="btn-play-pause">
                        <svg id="play-pause-icon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                    <button id="btn-mute">
                        <svg id="mute-icon" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/></svg>
                    </button>
                    
                    <button id="btn-prev-frame" class="btn-step" title="Frame Indietro">
                        <svg viewBox="0 0 24 24" class="moviola-icon">
                            <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="white"/>
                            <circle cx="12" cy="18" r="1" fill="white"/>
                        </svg>
                    </button>
                    
                    <button id="btn-next-frame" class="btn-step" title="Frame Avanti">
                        <svg viewBox="0 0 24 24" class="moviola-icon">
                            <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" fill="white"/>
                            <circle cx="12" cy="18" r="1" fill="white"/>
                        </svg>
                    </button>

                    <span id="time-display">0:00 / 0:00</span>

                    ${adminButton} 

                    <select id="select-speed">
                        <option value="0.5">0.5x</option>
                        <option value="1" selected>1x</option>
                        <option value="1.5">1.5x</option>
                        <option value="2">2x</option>
                    </select>
                    <select id="select-quality">
                        <option value="default" disabled selected>Risoluzione</option>
                        <option value="hd1080">1080p</option>
                        <option value="hd720">720p</option>
                        <option value="large">480p</option>
                        <option value="medium">360p</option>
                        <option value="small">240p</option>
                    </select>
                </div>
            </div>
        </div>
    `;

    wrapper.insertAdjacentHTML('beforeend', centralPlayBtnHtml);
    wrapper.insertAdjacentHTML('beforeend', uiHTML);
    console.log("✅ Interfaccia YouTube iniettata. Admin status:", window.isAdmin);
}

function injectCalibrationHTML() {
    const hudOverlay = document.getElementById('hud-overlay');
    // Se non c'è l'overlay o il popup esiste già, esci
    if (!hudOverlay || document.getElementById('pip-calibrator')) return;

    const calHTML = `
      <div id="pip-calibrator" class="popup-calibration">
          <div class="cal-header">
              <span style="font-weight: bold; color: var(--yt-red);">CALIBRAZIONE TABELLONE</span>
          </div>
          
          <div class="cal-main-content">
              <div class="cal-preview-box">
                  <div id="cal-player-wrapper" style="position: absolute; width: 100%; height: 100%; top:0; left:0; overflow:hidden;">
                      <div id="ytplayer-cal"></div>
                  </div>
                  <div id="cal-touch-surface" style="position: absolute; top:0; left:0; width:100%; height:100%; z-index:1002; background: transparent; cursor: move;"></div> 
              </div>

              <div class="cal-controls-container">
                  <div class="cal-control-group">
                      <button class="cal-btn" 
                        onmousedown="window.startContinuousAction(window.zoomCal, -0.05)" 
                        onmouseup="window.stopContinuousAction()"
                        onmouseleave="window.stopContinuousAction()" 
                        ontouchstart="window.startContinuousAction(window.zoomCal, -0.05)" 
                        ontouchend="window.stopContinuousAction()">-</button>

                      <span class="cal-label">ZOOM: <span id="cal-zoom-val">2.5x</span></span>

                      <button class="cal-btn" 
                        onmousedown="window.startContinuousAction(window.zoomCal, 0.05)" 
                        onmouseup="window.stopContinuousAction()" 
                        onmouseleave="window.stopContinuousAction()" 
                        ontouchstart="window.startContinuousAction(window.zoomCal, 0.05)" 
                        ontouchend="window.stopContinuousAction()">+</button>
                  </div>

                  <div class="cal-control-group">
                      <button class="cal-btn" 
                        onmousedown="window.startContinuousAction(window.sizeCal, -1)" 
                        onmouseup="window.stopContinuousAction()" 
                        onmouseleave="window.stopContinuousAction()" 
                        ontouchstart="window.startContinuousAction(window.sizeCal, -1)" 
                        ontouchend="window.stopContinuousAction()">-</button>

                      <span class="cal-label">SIZE: <span id="cal-size-val">20%</span></span>

                      <button class="cal-btn" 
                        onmousedown="window.startContinuousAction(window.sizeCal, 1)" 
                        onmouseup="window.stopContinuousAction()" 
                        onmouseleave="window.stopContinuousAction()" 
                        ontouchstart="window.startContinuousAction(window.sizeCal, 1)" 
                        ontouchend="window.stopContinuousAction()">+</button>
                  </div>

                <div class="cal-control-group" style="display: flex; flex-direction: column; align-items: center; gap: 8px;">
                    
                    <div style="display: flex; align-items: center; justify-content: center; gap: 10px; width: 100%;">
                        <button class="cal-btn" 
                            onmousedown="window.startContinuousAction(window.aspectRatioCal, -0.01)" 
                            onmouseup="window.stopContinuousAction()"
                            onmouseleave="window.stopContinuousAction()" 
                            ontouchstart="window.startContinuousAction(window.aspectRatioCal, -0.01)" 
                            ontouchend="window.stopContinuousAction()">-</button>

                        <span class="cal-label">Aspect Ratio: <span id="cal-aspect-val">1.77</span></span>

                        <button class="cal-btn" 
                            onmousedown="window.startContinuousAction(window.aspectRatioCal, 0.01)" 
                            onmouseup="window.stopContinuousAction()" 
                            onmouseleave="window.stopContinuousAction()" 
                            ontouchstart="window.startContinuousAction(window.aspectRatioCal, 0.01)" 
                            ontouchend="window.stopContinuousAction()">+</button>
                    </div>

                    <select id="cal-aspect-presets" class="cal-select" onchange="window.setAspectPreset(this.value)" style="width: 100%; max-width: 200px;">
                        <option value="" disabled selected hidden>Presets</option>
                        <option value="0.66">0.66 (2:3)</option>
                        <option value="0.75">0.75 (3:4)</option>
                        <option value="1.0">1.0 (1:1)</option>
                        <option value="1.15">1.15</option>
                        <option value="1.22">1.22</option>
                        <option value="1.33">1.33 (4:3)</option>
                        <option value="1.5">1.5 (3:2)</option>
                        <option value="1.77">1.77 (16:9)</option>
                        <option value="2.33">2.33 (21:9)</option>
                    </select>
                </div>
                  <div class="cal-control-group">
                      <button class="cal-btn" onclick="window.skewCal(-1)">-</button>
                      <span class="cal-label">SKEW: <span id="cal-skew-val">0°</span></span>
                      <button class="cal-btn" onclick="window.skewCal(1)">+</button>
                  </div>
              </div>
          </div>

          <div class="cal-actions">
              <button id="cal-save" class="save-btn" style="justify-content: center" >CONFERMA</button>
              <button id="cal-close" class="close-btn" style="justify-content: center" >ANNULLA</button>
          </div>
      </div>
    `;

    hudOverlay.insertAdjacentHTML('beforeend', calHTML);
}

async function openPipCalibrator(currentConfig) {
    // 1. Assicurati che l'HTML sia iniettato
    injectCalibrationHTML();
    
    tempPipConfig = JSON.parse(JSON.stringify(currentConfig));
    const popup = document.getElementById('pip-calibrator');
    
    // 2. Mostra il popup forzando la visibilità (come fai per la barra landscape)
    popup.classList.remove('hidden');
    popup.style.display = 'flex'; 
    updateCalUI();
    updateCalPreview();

    if (!playerCal) {
        playerCal = new YT.Player('ytplayer-cal', {
            height: '100%', width: '100%',
            videoId: window.AppPlayer.getVideoData().video_id,
            playerVars: { 'controls': 0, 'mute': 1, 'enablejsapi': 1, 'iv_load_policy': 3 },
            events: { 'onReady': () => updateCalPreview() }
        });
        initCalDrag();
        initCalZoom();
        initPointSelection();
    } else {
        updateCalPreview();
    }

    return new Promise((resolve) => {
        document.getElementById('cal-save').onclick = () => {
            popup.style.display = 'none';
            tempPipConfig.initialized = true;
            playerPip.setPlaybackQuality('hd1080');
            resolve(tempPipConfig);
        };
        document.getElementById('cal-close').onclick = () => {
            popup.style.display = 'none';
            currentConfig.initialized = false;
            resolve(currentConfig);
        };
    });
}

function savePIPtoDB(config) {
    // Solo l'amministratore può salvare la posizione della PIP nel database.
    if (window.isAdmin) {
        // 1. Assegna l'orario corrente visualizzato
        const timestampCorrente = window.orarioVisualizzatoFormattato;
        config.time = timestampCorrente;

        // 2. Prepara l'oggetto per l'array locale (seguendo la struttura del DB)
        const nuovoEntry = {
            matchId: window.matchId,
            timestamp: timestampCorrente,
            initialized: config.initialized,
            details: JSON.stringify(config) // Salviamo i dettagli come stringa JSON
        };

        // 3. Aggiorna livePipData localmente
        const index = window.livePipData.findIndex(item => item.timestamp === timestampCorrente);
        
        if (index !== -1) {
            // Se esiste già una config per questo secondo, la sovrascriviamo
            window.livePipData[index] = nuovoEntry;
        } else {
            // Altrimenti la aggiungiamo e ri-ordiniamo l'array
            window.livePipData.push(nuovoEntry);
            window.livePipData.sort((a, b) => {
                if (a.timestamp < b.timestamp) return -1;
                if (a.timestamp > b.timestamp) return 1;
                return 0;
            });
        }

        // 4. Salva sul server
        window.saveToFirebaseHistory('livePIPs/' + window.matchId, window.livePipData);
        window.saveToServerPIP(window.matchId, config.initialized, config);
        
        console.log(`? Config PiP salvata in locale e inviata al server [${timestampCorrente}]`);
    }
}

// Variabile globale per tracciare l'ultimo stato applicato
let lastAppliedPipTimestamp = null;

/**
 * Imposta la configurazione PiP in base all'orario visualizzato con controllo di ridondanza.
 * @param {string} orarioVisualizzatoFormattato - Orario nel formato 'HH:mm:ss'
 */
window.syncPipWithTimestamp = syncPipWithTimestamp;
function syncPipWithTimestamp(orarioVisualizzatoFormattato) {
    if (!window.livePipData || window.livePipData.length === 0) {
        hidePipLayer();
        return;
    }

    // 1. Trova l'elemento valido con timestamp <= orario attuale
    let currentValidConfig = null;

    for (let i = 0; i < window.livePipData.length; i++) {
        if (window.livePipData[i].timestamp > orarioVisualizzatoFormattato) break;
        currentValidConfig = window.livePipData[i];
    }

    // 2. Se non ho trovato nulla, nascondo e resetto il tracker
    if (!currentValidConfig) {
        if (lastAppliedPipTimestamp !== null) {
            hidePipLayer();
            lastAppliedPipTimestamp = null;
        }
        return;
    }

    // 3. CONTROLLO CAMBIAMENTO: Se l'elemento trovato è lo stesso di prima, esco
    if (currentValidConfig.timestamp === lastAppliedPipTimestamp) {
        return; 
    }

    // 4. Se arriviamo qui, l'elemento è cambiato. Aggiorniamo il tracker.
    lastAppliedPipTimestamp = currentValidConfig.timestamp;

    // 5. Applichiamo la logica di visualizzazione
    if (currentValidConfig.initialized === true || currentValidConfig.initialized === "true") {
        try {
            const configDetails = typeof currentValidConfig.details === 'string' 
                ? JSON.parse(currentValidConfig.details) 
                : currentValidConfig.details;
            
            window.pipConfig = configDetails;
            
            if (typeof setPipPosition === "function") {
                setPipPosition(window.pipConfig);
            }
            
            const pipLayer = document.getElementById('pip-layer');
            if (pipLayer) pipLayer.style.display = 'block';
            const pipbtn = document.getElementById('btn-set-pip');
            if (pipbtn) pipbtn.classList.add('active');

            
            console.log(`✨ PiP aggiornata al timestamp: ${lastAppliedPipTimestamp}`);
        } catch (e) {
            console.error("Errore nel parsing dei dettagli PiP:", e);
        }
    } else {
        hidePipLayer();
        console.log(`? PiP disattivata (initialized=false) al timestamp: ${lastAppliedPipTimestamp}`);
    }
}

/**
 * Utility per nascondere la PiP e resettare la visibilità
 */
function hidePipLayer() {
    const pipContainer = document.getElementById('pip-container');
    if (pipContainer) pipContainer.style.display = 'none';

    const pipbtn = document.getElementById('btn-set-pip');
    if (pipbtn) pipbtn.classList.remove('active');
}

function initPointSelection() {
    const surface = document.getElementById('cal-touch-surface');

    const startTimer = (e) => {
        // Se stiamo già trascinando con due dita (pinch), non attiviamo il punto singolo
        if (e.touches && e.touches.length > 1) return;

        pointLongPressTimer = setTimeout(() => {
            // Se arriviamo qui, l'utente ha tenuto premuto abbastanza a lungo
            handlePointSelection(e);
        }, LONG_PRESS_DURATION);
    };

    const clearTimer = () => {
        clearTimeout(pointLongPressTimer);
    };

    // Eventi Touch
    surface.addEventListener('touchstart', startTimer, { passive: false });
    surface.addEventListener('touchend', clearTimer);
    surface.addEventListener('touchmove', clearTimer); // Se muove il dito, annulla il long press

    // Eventi Mouse (per desktop)
    surface.addEventListener('mousedown', (e) => { if(e.button === 0) startTimer(e); });
    surface.addEventListener('mouseup', clearTimer);
    surface.addEventListener('mousemove', clearTimer);
}

function initCalZoom() {
    const previewBox = document.querySelector('.cal-preview-box');

    // Funzione per calcolare la distanza tra due dita
    function getTouchDist(e) {
        return Math.hypot(
            e.touches[0].pageX - e.touches[1].pageX,
            e.touches[0].pageY - e.touches[1].pageY
        );
    }

    previewBox.addEventListener('touchstart', (e) => {
        if (e.touches.length === 2) {
            e.preventDefault();
            initialPinchDistance = getTouchDist(e);
            initialZoomAtPinch = tempPipConfig.zoom;
        }
    }, { passive: false });

    previewBox.addEventListener('touchmove', (e) => {
        if (e.touches.length === 2 && initialPinchDistance) {
            e.preventDefault();
            const currentDist = getTouchDist(e);
            const scale = currentDist / initialPinchDistance;
            
            // Calcola il nuovo zoom (min 1, max 5 come i tuoi bottoni)
            let newZoom = initialZoomAtPinch * scale;
            tempPipConfig.zoom = Math.min(Math.max(newZoom, 1), 5);
            
            // Aggiorna l'interfaccia
            const zoomValDisplay = document.getElementById('cal-zoom-val');
            if (zoomValDisplay) zoomValDisplay.innerText = tempPipConfig.zoom.toFixed(1) + "x";
            
            updateCalPreview();
        }
    }, { passive: false });

    previewBox.addEventListener('touchend', () => {
        initialPinchDistance = null;
    });
}

function initCalDrag() {
    const surface = document.getElementById('cal-touch-surface');
    let startX, startY;
    let startConfigX, startConfigY;

    const handleStart = (e) => {
        isDraggingCal = true;
        if (e.cancelable) e.preventDefault();

        // Punto di contatto iniziale
        startX = e.touches ? e.touches[0].clientX : e.clientX;
        startY = e.touches ? e.touches[0].clientY : e.clientY;

        // Posizione attuale della configurazione
        startConfigX = tempPipConfig.xPerc;
        startConfigY = tempPipConfig.yPerc;
    };

    const handleMove = (e) => {
        if (!isDraggingCal) return;
        if (e.cancelable) e.preventDefault();

        const currentX = e.touches ? e.touches[0].clientX : e.clientX;
        const currentY = e.touches ? e.touches[0].clientY : e.clientY;

        // 1. Calcoliamo lo spostamento in Pixel puri
        const deltaXPixels = currentX - startX;
        const deltaYPixels = currentY - startY;

        const rect = surface.getBoundingClientRect();
        const visualZoom = tempPipConfig.zoom * 10.0;

        const moveX = deltaXPixels / (rect.width * visualZoom);
        const moveY = deltaYPixels / (rect.height * visualZoom);

        tempPipConfig.xPerc = Math.max(0, Math.min(1, startConfigX - moveX));
        tempPipConfig.yPerc = Math.max(0, Math.min(1, startConfigY - moveY));

        updateCalPreview();
    };

    const handleEnd = () => { isDraggingCal = false; };

    surface.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);
    surface.addEventListener('touchstart', handleStart, { passive: false });
    surface.addEventListener('touchmove', handleMove, { passive: false });
    surface.addEventListener('touchend', handleEnd);
}

window.startContinuousAction = startContinuousAction;
function startContinuousAction(actionFn, ...args) {
    actionFn(...args);
    clearTimeout(calTimer);
    calTimer = setInterval(() => {
        actionFn(...args);
    }, 50); 
}

window.stopContinuousAction = stopContinuousAction;
function stopContinuousAction() {
    clearInterval(calTimer);
}

function moveCal(dx, dy) {
    tempPipConfig.xPerc += (dx / 1000);
    tempPipConfig.yPerc += (dy / 562);
    tempPipConfig.xPerc = Math.max(0, Math.min(1, tempPipConfig.xPerc));
    tempPipConfig.yPerc = Math.max(0, Math.min(1, tempPipConfig.yPerc));
    updateCalPreview();
}

window.zoomCal = zoomCal;
function zoomCal(delta) {
    let newZoom = tempPipConfig.zoom + delta;
    tempPipConfig.zoom = Math.max(0.1, Math.min(15, Math.trunc(newZoom * 100) / 100));
    document.getElementById('cal-zoom-val').innerText = tempPipConfig.zoom.toFixed(1) + "x";
    updateCalPreview();
}

window.skewCal = skewCal;
function skewCal(delta) {
    tempPipConfig.skew += delta;
    document.getElementById('cal-skew-val').innerText = tempPipConfig.skew + "°";
    updateCalPreview();
}

window.sizeCal = sizeCal;
function sizeCal(d) { 
    tempPipConfig.size = Math.max(5, Math.min(95, tempPipConfig.size + d)); 
    updateCalUI(); 
    updateCalPreview();
}

window.aspectRatioCal = aspectRatioCal;
function aspectRatioCal(delta) {
    const previewBox = document.querySelector('.cal-preview-box');
    const rect = previewBox.getBoundingClientRect();

    // 1. Salva il punto reale del video
    const videoX = tempPipConfig.xPerc * rect.width;
    const videoY = tempPipConfig.yPerc * rect.height;

    // 2. Cambia AR
    tempPipConfig.aspectRatio = Math.max(0.2, Math.min(3.0, tempPipConfig.aspectRatio + delta));

    // 3. Aggiorna SOLO layout
    updateCalUI();

    // 4. Leggi il nuovo rect della previewBox
    const newRect = previewBox.getBoundingClientRect();

    // 5. Ricalcola xPerc/yPerc nel nuovo sistema
    tempPipConfig.xPerc = videoX / newRect.width;
    tempPipConfig.yPerc = videoY / newRect.height;

    // 6. Aggiorna la preview
    updateCalPreview();
}

window.setAspectPreset = setAspectPreset;
function setAspectPreset(val) {
    if (!val) return;

    const previewBox = document.querySelector('.cal-preview-box');
    const rect = previewBox.getBoundingClientRect();

    const videoX = tempPipConfig.xPerc * rect.width;
    const videoY = tempPipConfig.yPerc * rect.height;

    tempPipConfig.aspectRatio = parseFloat(val);

    updateCalUI();

    const newRect = previewBox.getBoundingClientRect();
    tempPipConfig.xPerc = videoX / newRect.width;
    tempPipConfig.yPerc = videoY / newRect.height;

    updateCalPreview();

    setTimeout(() => {
        document.getElementById('cal-aspect-presets').selectedIndex = 0;
    }, 100);
}

function updateCalUI() {
    // 1. Controllo sicurezza
    if (!tempPipConfig) return;

    // 2. Aggiornamento testi numerici
    const aspectDisplay = document.getElementById('cal-aspect-val');
    if (aspectDisplay) aspectDisplay.innerText = tempPipConfig.aspectRatio.toFixed(2);
    
    const zoomDisplay = document.getElementById('cal-zoom-val');
    if (zoomDisplay) zoomDisplay.innerText = tempPipConfig.zoom.toFixed(2) + "x";

    const sizeDisplay = document.getElementById('cal-size-val');
    if (sizeDisplay) {
        // Usa .size o .sizePerc in base a come lo hai salvato nel DB
        sizeDisplay.innerText = (tempPipConfig.size || tempPipConfig.sizePerc || 20) + "%";
    }

    const skewDisplay = document.getElementById('cal-skew-val');
    if (skewDisplay) skewDisplay.innerText = (tempPipConfig.skew || 0) + "°";

    // 3. Calcolo dimensioni Preview Box (Tua logica originale)
    const previewBox = document.querySelector('.cal-preview-box');
    const ar = tempPipConfig.aspectRatio;
    const screenW = window.innerWidth;
    const screenH = window.innerHeight;

    let maxSafeW, maxSafeH;
    if (screenW > screenH) { 
        maxSafeW = screenW - 400; 
        maxSafeH = screenH - 80;
    } else {
        maxSafeW = screenW * 0.9;
        maxSafeH = screenH - 400;
    }

    let targetW = maxSafeW;
    let targetH = targetW / ar;

    if (targetH > maxSafeH) {
        targetH = maxSafeH;
        targetW = targetH * ar;
    }
    if (targetW > maxSafeW) {
        targetW = maxSafeW;
        targetH = targetW / ar;
    }

    if (previewBox) {
        previewBox.style.width = Math.floor(targetW) + "px";
        previewBox.style.height = Math.floor(targetH) + "px";
    }
    
    // 4. IMPORTANTE: Applica la trasformazione visiva al video
    // Altrimenti vedi i numeri giusti ma il video non è zoomato/tagliato
    updateCalPreview(); 
}

function handlePointSelection(e) {
    const surface = document.getElementById('cal-touch-surface');
    const rect = surface.getBoundingClientRect();
    
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    
    // Coordinate locali rispetto alla box di preview
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    calPoints.push({ x, y });

    if (calPoints.length === 2) {
        const p1 = calPoints[0];
        const p2 = calPoints[1];

        const dx = Math.abs(p2.x - p1.x);
        const dy = Math.abs(p2.y - p1.y);

        if (dy > 0 && dx > 0) {
            // 1. Nuovo Aspect Ratio
            tempPipConfig.aspectRatio = dx / dy;

            // 2. Calcolo del Centro Relativo (0.0 - 1.0)
            // Questo è il punto "mirino" rispetto alla superficie totale
            tempPipConfig.xPerc = ((p1.x + p2.x) / 2) / rect.width;
            tempPipConfig.yPerc = ((p1.y + p2.y) / 2) / rect.height;

            updateCalUI(); 
            updateCalPreview();
        }
        calPoints = []; 
    }
}

function updateCalPreview() {
    if (!playerCal || !playerCal.getIframe()) return;

    const wrapper = document.getElementById('cal-player-wrapper');
    const z = tempPipConfig.zoom * 10.0; // Il tuo moltiplicatore
    
    // Il wrapper deve essere grande z volte la preview
    wrapper.style.width = (z * 100) + "%";
    wrapper.style.height = "auto";
    wrapper.style.aspectRatio = "16/9";

    /* FORMULA DI CENTRATURA COERENTE:
       Vogliamo che il punto xPerc del video coincida con il centro (50%) della box.
       Siccome il wrapper è grande 'z', la posizione del punto xPerc 
       all'interno del wrapper è (xPerc * 100%).
       Per portarlo al centro della box esterna:
    */
    const leftMove = 50 - (tempPipConfig.xPerc * 100 * z);
    const topMove = 50 - (tempPipConfig.yPerc * 100 * z);

    wrapper.style.left = leftMove + "%";
    wrapper.style.top = topMove + "%";
    
    // Applichiamo lo skew e resettiamo il translate se lo usavi, 
    // perché left/top bastano a centrare
    wrapper.style.transform = `skewX(${tempPipConfig.skew}deg)`;

    if (playerCal && playerCal.seekTo) {
        const diff = Math.abs(window.AppPlayer.getCurrentTime() - playerCal.getCurrentTime());
        if (diff > 1.5) { // Tolleranza leggermente maggiore per evitare micro-scatti
          playerCal.seekTo(window.AppPlayer.getCurrentTime(), true);
        }
    }
}

// Funzione di supporto per applicare lo stile in modo pulito
function applyPipStyle(pip, x, y, wPerc, hPerc) {
    pip.style.transition = "all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)";
    
    // Gestione bordi magnetici con micro-margine percentuale (es. 0.5% invece di 2px)
    let left = (x * 100);
    let top = (y * 100);

    // Se è attaccato al bordo destro o inferiore, usiamo "auto" e "bottom/right" 
    // per una migliore stabilità durante il ridimensionamento
    if (x + wPerc >= 0.98) {
        pip.style.left = "auto";
        pip.style.right = "1%"; // 1% è il tuo nuovo "2px" reattivo
    } else {
        pip.style.left = left + "%";
        pip.style.right = "auto";
    }

    if (y + hPerc >= 0.98) {
        pip.style.top = "auto";
        pip.style.bottom = "1%";
    } else {
        pip.style.top = top + "%";
        pip.style.bottom = "auto";
    }
}

function setPipPosition(config) {
    if (!config.initialized) return;
    const xPerc = config.xPerc;
    const yPerc = config.yPerc;

    const pipWrapper = document.getElementById('pip-player-wrapper');
    const pipContainer = document.getElementById('pip-container');
    const z = config.zoom * 10.0; 

    pipContainer.style.width = config.size + "%";

    pipContainer.style.height = "auto";
    pipContainer.style.aspectRatio = config.aspectRatio.toString();

    pipContainer.style.top = (config.yPos * 100) + "%";
    pipContainer.style.bottom = "auto";
    pipContainer.style.left = (config.xPos * 100) + "%";
    pipContainer.style.right = "auto";
    pipContainer.style.display = "block";
    pipContainer.style.border = pipConfig_border;

    pipWrapper.style.width = (z * 100) + "%";
    pipWrapper.style.height = "auto";
    pipWrapper.style.aspectRatio = "16/9";
    
    pipWrapper.style.position = "absolute";

    const leftMove = -(xPerc * z * 100) + 50; 
    const topMove = -(yPerc * z * 100) + 50;

    pipWrapper.style.left = leftMove + "%";
    pipWrapper.style.top = topMove + "%";
    pipWrapper.style.transform = "none";
    pipWrapper.style.transform = `skewX(${config.skew}deg)`;

    if (playerPip && playerPip.seekTo && window.AppPlayer.getCurrentTime && window.AppPlayer.getPlayerState) {
        playerPip.seekTo(window.AppPlayer.getCurrentTime(), true);
        if (window.AppPlayer.getPlayerState() === window.AppPlayerState.PLAYING) playerPip.playVideo();
    }
}

/**
 * Calcola la posizione normalizzata (0.0 - 1.0) della PiP con snap alla griglia.
 * @param {HTMLElement} pip - L'elemento della PiP (es. #pip-container).
 * @param {HTMLElement} container - Il contenitore (es. #player-wrapper).
 * @returns {Object} Oggetto con le coordinate snappedX e snappedY.
 */
function getNormalizedPipPosition(pip, container) {
    if (!pip || !container) return { snappedX: 0, snappedY: 0 };

    const containerRect = container.getBoundingClientRect();
    const pipRect = pip.getBoundingClientRect();
    
    // 1. CALCOLO POSIZIONE RELATIVA
    let relXPerc = (pipRect.left - containerRect.left) / containerRect.width;
    let relYPerc = (pipRect.top - containerRect.top) / containerRect.height;

    // 2. SNAP ALLA GRIGLIA (5%)
    const snapGrid = 0.05;
    let snappedX = Math.round(relXPerc / snapGrid) * snapGrid;
    let snappedY = Math.round(relYPerc / snapGrid) * snapGrid;

    // 3. LIMITI (Considerando l'ingombro della PiP)
    const pipWidthPerc = pip.offsetWidth / containerRect.width;
    const pipHeightPerc = pip.offsetHeight / containerRect.height;
    
    snappedX = Math.max(0, Math.min(snappedX, 1 - pipWidthPerc));
    snappedY = Math.max(0, Math.min(snappedY, 1 - pipHeightPerc));

    // Arrotondamento per evitare micro-decimali dovuti alla precisione JS
    return { 
        snappedX: Number(snappedX.toFixed(3)), 
        snappedY: Number(snappedY.toFixed(3)), 
        pipWidthPerc: Number(pipWidthPerc.toFixed(3)), 
        pipHeightPerc: Number(pipHeightPerc.toFixed(3))
    };
}

let frameInterval = null;


function initializePlayerOverlays(myPlayer) {
    const overlay = document.getElementById('transparent-overlay');
    const ytElement = document.getElementById('ytplayer');
    const wrapper = document.getElementById('player-wrapper');
    const uiLayer = document.getElementById('ui-layer');
    const timeSlider = document.getElementById('time-slider');
    const pipContainer = document.getElementById('pip-container');

    // --- HELPER: Controllo visibilità UI ---
    // Verifica se la barra è visibile (opacity != "0")
    const isUiVisible = () => {
        return window.getComputedStyle(uiLayer).opacity !== "0";
    };

    // --- LOGICA DRAG & SNAP PIP ---
    function initPipDrag(pip, container) {
        let offsetX, offsetY;
        
        const startDrag = (e) => {
            if (isSettingPip) return;
            isDraggingPip = true;
            pipWasMoved = false;

            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            
            pipStartX = clientX;
            pipStartY = clientY;

            const rect = pip.getBoundingClientRect();
            offsetX = clientX - rect.left;
            offsetY = clientY - rect.top;
            pip.style.transition = "none";
            
            // Se trasciniamo la PiP, resettiamo il timer dell'HUD per tenerlo vivo
            window.resetUITimer();
        };

        const doDrag = (e) => {
            if (!isDraggingPip) return;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;

            const deltaX = Math.abs(clientX - pipStartX);
            const deltaY = Math.abs(clientY - pipStartY);

            if (deltaX > pipDragThreshold || deltaY > pipDragThreshold) {
                pipWasMoved = true; 
                const containerRect = container.getBoundingClientRect();
                let x = clientX - containerRect.left - offsetX;
                let y = clientY - containerRect.top - offsetY;

                x = Math.max(0, Math.min(x, containerRect.width - pip.offsetWidth));
                y = Math.max(0, Math.min(y, containerRect.height - pip.offsetHeight));

                pip.style.left = x + "px";
                pip.style.top = y + "px";
                pip.style.right = "auto";
            }
        };

        const stopDrag = () => {
            if (!isDraggingPip) return;
            isDraggingPip = false;
            if (pipWasMoved) {
                const coords = getNormalizedPipPosition(pipContainer, wrapper);
                window.pipConfig.xPos = coords.snappedX;
                window.pipConfig.yPos = coords.snappedY;
                applyPipStyle(pip, coords.snappedX, coords.snappedY, coords.pipWidthPerc, coords.pipHeightPerc);
                setTimeout(() => { pipWasMoved = false; }, 200);
                savePIPtoDB(window.pipConfig);
            }
        };

        pip.addEventListener('mousedown', startDrag);
        pip.addEventListener('touchstart', startDrag, {passive: false});
        window.addEventListener('mousemove', doDrag);
        window.addEventListener('touchmove', doDrag, {passive: false});
        window.addEventListener('mouseup', stopDrag);
        window.addEventListener('touchend', stopDrag);
    }

    initPipDrag(pipContainer, wrapper);
    
    // --- LOGICA ZOOM & GESTURE ---
    let startX, startY;
    let isDoubleTap = false;
    const moveThreshold = 15;

    function startAction(e) {
        if (isDraggingPip) return;
        isDoubleTap = (e.touches && e.touches.length === 2);
        
        startX = (e.touches && isDoubleTap) ? e.touches[1].clientX : (e.touches ? e.touches[0].clientX : e.clientX);
        startY = (e.touches && isDoubleTap) ? e.touches[1].clientY : (e.touches ? e.touches[0].clientY : e.clientY);

        clearTimeout(longPressTimer);
        // Se l'utente tocca l'overlay, mostriamo la UI se era nascosta
        window.resetUITimer();

        longPressTimer = setTimeout(() => {
            if (isSettingPip) return;
            isLongPressZoomActive = true;
            uiLayer.style.opacity = "0"; // Nasconde UI durante lo zoom
            uiLayer.style.pointerEvents = "none";
            uiLayer.style.zIndex = "10";
            const zoomLevel = isDoubleTap ? 3 : 2;
            applyZoomPan(startX, startY, zoomLevel);
        }, 500);
    }

    function moveAction(e) {
        if (!isLongPressZoomActive) {
            let curX = e.touches ? e.touches[0].clientX : e.clientX;
            let curY = e.touches ? e.touches[0].clientY : e.clientY;
            if (Math.abs(curX - startX) > moveThreshold || Math.abs(curY - startY) > moveThreshold) {
                clearTimeout(longPressTimer);
            }
            return;
        }
        if (e.cancelable) e.preventDefault();
        let currentX = (e.touches && e.touches.length === 2) ? e.touches[1].clientX : (e.touches ? e.touches[0].clientX : e.clientX);
        let currentY = (e.touches && e.touches.length === 2) ? e.touches[1].clientY : (e.touches ? e.touches[0].clientY : e.clientY);
        applyZoomPan(currentX, currentY, isDoubleTap ? 3 : 2);
    }

    function endAction() {
        clearTimeout(longPressTimer);
        if (isLongPressZoomActive) {
            isLongPressZoomActive = false;
            isDoubleTap = false;
            ytElement.style.transform = `scale(${currentZoom}) translate(0, 0)`;
            uiLayer.style.opacity = "1";
            uiLayer.style.pointerEvents = "auto";
            uiLayer.style.zIndex = "20";

        }
    }

    function applyZoomPan(currentX, currentY, scale) {
        const rect = wrapper.getBoundingClientRect();
        const sensitivity = scale === 3 ? sensitivity1 : sensitivity2; 
        let deltaX = (currentX - startX) / rect.width;
        let deltaY = (currentY - startY) / rect.height;
        let virtualX = deltaX * sensitivity;
        let virtualY = deltaY * sensitivity;
        const limit = (scale - 1) / (2 * scale);
        const constrainedX = Math.max(-limit, Math.min(virtualX, limit));
        const constrainedY = Math.max(-limit, Math.min(virtualY, limit));
        ytElement.style.transform = `scale(${scale}) translate(${-constrainedX * 100}%, ${-constrainedY * 100}%)`;
    }

    /**
     * Gestisce l'avanzamento a scatti (singoli o continui)
     * @param {string} btnId - L'ID del bottone (es. 'btn-next-frame')
     * @param {number} delta - Di quanto spostarsi (es. 0.1 o -0.1)
     */
    function attachFrameRepeat(btnId, delta) {
        const btn = document.getElementById(btnId);
        if (!btn) return;

        // Funzione interna per eseguire lo spostamento
        const performStep = () => {
            if (!isUiVisible() || !myPlayer) return;

            // 1. Gestione Icona Play/Pause
            const icon = document.getElementById('play-pause-icon');
            if (icon) {
                icon.innerHTML = playIcon; //pauseIcon; // '<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>';
            }

            // 2. Metti in pausa i player
            myPlayer.pause();
            if (playerPip) playerPip.pauseVideo();

            // 3. Calcola e applica il nuovo tempo
            const newTime = myPlayer.getCurrentTime() + delta;
            
            myPlayer.seekTo(newTime, true);
            if (playerPip) {
                playerPip.seekTo(newTime, true);
            }
        };

        const startAction = (e) => {
            // Blocca menu contestuali o scroll su mobile
            if (e.type === 'touchstart' && e.cancelable) e.preventDefault();
            if (e.type === 'mousedown' && e.button !== 0) return;

            performStep(); // Primo scatto immediato al "touch"

            // Avvia la ripetizione continua dopo 250ms (delay iniziale)
            clearInterval(frameInterval);
            frameInterval = setInterval(performStep, 100); // 10 frame al secondo durante la pressione
        };

        const stopAction = () => {
            clearInterval(frameInterval);
            frameInterval = null;
        };

        // Rimuoviamo eventuali onclick preesistenti
        btn.onclick = null;

        // Eventi Mouse
        btn.addEventListener('mousedown', startAction);
        btn.addEventListener('mouseleave', stopAction);
        window.addEventListener('mouseup', stopAction); // Più sicuro per intercettare il rilascio fuori dal tasto

        // Eventi Touch (Mobile)
        btn.addEventListener('touchstart', startAction, { passive: false });
        btn.addEventListener('touchend', stopAction);
    }

    overlay.addEventListener('touchstart', startAction, { passive: false });
    overlay.addEventListener('touchmove', moveAction, { passive: false });
    overlay.addEventListener('touchend', endAction);
    overlay.addEventListener('mousedown', startAction);
    window.addEventListener('mousemove', moveAction, { passive: false });
    window.addEventListener('mouseup', endAction);
    
    // --- CLICK OVERLAY (UI / SEEK) ---
    overlay.addEventListener('click', async (e) => {
        const rect = wrapper.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const currentTime = Date.now();

        if (currentTime - lastClickTime < doubleClickDelay) {
            if (isSettingPip) return;
            const isRightSide = clickX > rect.width / 2;
            const skipAmount = isRightSide ? 10 : -10;
            if (myPlayer && myPlayer.seekTo) {
                myPlayer.seekTo(myPlayer.getCurrentTime() + skipAmount, true);
                const feedback = document.createElement('div');
                feedback.className = 'skip-feedback';
                feedback.style.left = isRightSide ? "75%" : "25%";
                feedback.innerText = isRightSide ? "＋10s" : "－10s";
                wrapper.appendChild(feedback);
                setTimeout(() => feedback.remove(), 800);
            }
            lastClickTime = 0;
            return; 
        }
        lastClickTime = currentTime;

        if (isSettingPip) {
            const rect = wrapper.getBoundingClientRect();
            // ATTENZIONE: eliminare codice
            // window.pipConfig.xPerc = (e.clientX - rect.left) / rect.width;
            // window.pipConfig.yPerc = (e.clientY - rect.top) / rect.height;

            // window.pipConfig.xPos = window.pipConfig.xPerc;
            // window.pipConfig.yPos = window.pipConfig.yPerc;

            // window.pipConfig = await openPipCalibrator(window.pipConfig);
            // setPipPosition(window.pipConfig);
            // savePIPtoDB(window.pipConfig);
            // isSettingPip = false;
            // document.getElementById('btn-set-pip').classList.remove('active');
            // overlay.style.zIndex = "15";
        } else {        
            // Se la UI è invisibile, il primo click la mostra e basta
            if (!isLongPressZoomActive) window.resetUITimer();
        }
    });

    pipContainer.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!pipWasMoved && window.isAdmin) {
            window.pipConfig = await openPipCalibrator(window.pipConfig);
            if (window.pipConfig.initialized) {
                setPipPosition(window.pipConfig);
                savePIPtoDB(window.pipConfig);
            }
        }
    });         

    // --- CONTROLLI UI (Accettati solo se visibili) ---
    const btnCentral = document.getElementById('btn-central-toggle');

    // 1. Logica di Toggle
    btnCentral.onclick = (e) => {
        //try {
            e.stopPropagation(); // Evita conflitti con altri click sul video
            if (window.AppPlayer.getPlayerState) {
                const state = window.AppPlayer.getPlayerState();
                if (state === window.AppPlayerState.PLAYING) {
                    window.AppPlayer.pause();
                } else {
                    window.AppPlayer.play();
                }
            }
        //} catch(e) {}
    };


    document.getElementById('btn-play-pause').onclick = () => {
        //try {
            if (!isUiVisible()) return; // Blocco se UI nascosta
            if (myPlayer && myPlayer.getPlayerState) {
                const state = myPlayer.getPlayerState();
                const icon = document.getElementById('play-pause-icon');
                if (state === window.AppPlayerState.PLAYING) {
                    myPlayer.pause();
                    if (playerPip) playerPip.pauseVideo();

                    icon.innerHTML = playIcon; //'<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>';
                } else {
                    myPlayer.play();
                    if (playerPip) playerPip.playVideo();
                    // cambia l'icona
                    icon.innerHTML = pauseIcon; //playIcon; //'<path d="M8 5v14l11-7z"/>';
                }
            }
        //} catch(e) {}
    };

    document.getElementById('btn-mute').onclick = () => {
        if (!isUiVisible()) return;
        if (myPlayer && myPlayer.isMuted) {
            if (myPlayer.isMuted()) {
                myPlayer.unMute();
                document.getElementById('mute-icon').innerHTML = '<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/>';
            } else {
                myPlayer.mute();
                document.getElementById('mute-icon').innerHTML = '<path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>';
            }
        }
    };
    document.getElementById('mute-icon').innerHTML = '<path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>';

    // Applichiamo la funzione ai due bottoni
    attachFrameRepeat('btn-next-frame', 0.1);
    attachFrameRepeat('btn-prev-frame', -0.1);

    if (window.isAdmin) {
        document.getElementById('btn-set-pip').onclick = async function() {
            if (!isUiVisible()) return;

            this.classList.toggle('active');
            
            // Gestione Overlay (opzionale, basata sulla tua logica isSettingPip)
            const isActive = this.classList.contains('active');
            //overlay.style.zIndex = isActive ? "30" : "15";

            if (isActive) {
                // APERTURA
                const prevState = window.pipConfig.initialized;
                window.pipConfig = await openPipCalibrator(window.pipConfig);
                if (window.pipConfig.initialized) {
                    setPipPosition(window.pipConfig);
                    savePIPtoDB(window.pipConfig);
                }
                else {
                    // resetta il bottone
                    if (!prevState && ! window.pipConfig.initialized)
                      this.classList.toggle('active');
                }
            }
            else {
                // CHIUSURA / PAUSA
                
                // 1. Metti in pausa il video del PIP se esiste
                if (playerPip && typeof playerPip.pauseVideo === "function") {
                    playerPip.pauseVideo();
                }

                // 2. Rendi invisibile il contenitore
                const pipContainer = document.getElementById('pip-container');
                if (pipContainer) {
                    pipContainer.style.display = "none";
                }
                window.pipConfig.initialized = false;
                savePIPtoDB(window.pipConfig);
            }
        };
    }

    timeSlider.oninput = () => {
        if (!isUiVisible()) return;
        isDragging = true;
        if (myPlayer && myPlayer.seekTo) myPlayer.seekTo(timeSlider.value, true);
    };
    timeSlider.onchange = () => isDragging = false;

    document.getElementById('select-speed').onchange = (e) => {
        if (!isUiVisible()) return;
        if (myPlayer && myPlayer.setPlaybackRate) myPlayer.setPlaybackRate(parseFloat(e.target.value));
    };

    document.getElementById('select-quality').onchange = (e) => {
        if (!isUiVisible()) return;
        const selectedQuality = e.target.value;
        if (myPlayer && myPlayer.setPlaybackQuality) {
            myPlayer.setPlaybackQuality(selectedQuality);
            if (playerPip) playerPip.setPlaybackQuality(selectedQuality);
        }
    };

    // --- LOOP DI AGGIORNAMENTO ---
    setInterval(() => {
        if (myPlayer && myPlayer.getCurrentTime && !isDragging) {
            const cur = myPlayer.getCurrentTime();
            const dur = myPlayer.getDuration() || 0;
            timeSlider.max = dur;
            timeSlider.value = cur;
            document.getElementById('time-display').innerText = `${formatTime(cur)} / ${formatTime(dur)}`;

            // Sync PIP
            if (playerPip && playerPip.getPlayerState
                // && myPlayer.getPlayerState() === 1 && 
                // playerPip.getPlayerState() === 1
                ) 
                {
                const diff = Math.abs(cur - playerPip.getCurrentTime());
                if (diff > 0.5) playerPip.seekTo(cur, true);
            }
        }

        frameCount++;
        if (myPlayer && myPlayer.getPlaybackQuality && frameCount % 4 === 0) {
            const quality = myPlayer.getPlaybackQuality();
            const select = document.getElementById('select-quality');
            if (select) select.options[0].text = (quality === 'auto' ? "Auto" : quality);
        }

        updateCentralBtn();

    }, 500);

}

// 2. Sincronizzazione Icona e Visibilità
// Inserisci questo dentro l'intervallo o la funzione che aggiorna la UI ogni secondo
function updateCentralBtn() {
    const svgCentral = document.getElementById('svg-central');
    const centralContainer = document.getElementById('central-play-pause');

    if (!window.player || !svgCentral) return;
    try {
        const state = window.AppPlayer.getPlayerState();
        const playPath = "M8 5v14l11-7z";
        const pausePath = "M6 19h4V5H6v14zm8-14v14h4V5h-4z";

        if (state === window.AppPlayerState.PLAYING) {
            svgCentral.querySelector('path').setAttribute('d', pausePath);
        } else {
            svgCentral.querySelector('path').setAttribute('d', playPath);
        }

        // Sincronizza visibilità con ui-layer
        const uiLayer = document.getElementById('ui-layer');
        if (uiLayer) {
            centralContainer.style.opacity = uiLayer.style.opacity;
            centralContainer.style.pointerEvents = (uiLayer.style.opacity === "0") ? "none" : "auto";
        }

        const icon = document.getElementById('play-pause-icon');
        if (icon) {
            if (state === window.AppPlayerState.PLAYING)
                icon.innerHTML = pauseIcon;
            else
                icon.innerHTML = playIcon;

        }
    } catch (e) { }

}

let bufferingTimeout = null;
const MAX_BUFFERING_TIME = 10000; // 10 secondi

// Funzione di emergenza se il segnale non torna
function handleLiveCrash() {
    const playerWrapper = document.getElementById('player-wrapper');
    console.error("? Segnale video perso definitivamente.");
    
    // 1. Feedback visivo sul bordo
    if (playerWrapper) {
        playerWrapper.style.transition = "border 0.5s";
        playerWrapper.style.border = "3px solid var(--yt-red)";
        playerWrapper.style.position = "relative"; // Assicura che il popup sia centrato rispetto al wrapper
    }

    // 2. Controllo se il popup esiste già per evitare duplicati
    if (document.getElementById('crash-overlay')) return;

    // 3. Creazione dell'overlay del popup
    const overlay = document.createElement('div');
    overlay.id = 'crash-overlay';
    
    // Stile CSS via JS
    Object.assign(overlay.style, {
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: '100000',
        borderRadius: '8px',
        backdropFilter: 'blur(4px)'
    });

    // 4. Contenuto del popup
    // togliamo il tasto Reload che non è affidabile. Tanto il popup viene tolto in automatico quando torna disponibile il video
    // overlay.innerHTML = `
    //     <div style="text-align: center; color: white; font-family: sans-serif;">
    //         <div style="font-size: 40px; margin-bottom: 10px;">⚠️</div>
    //         <h2 style="margin: 0 0 15px 0;">Video non disponibile</h2>
    //         <p style="margin-bottom: 20px; font-size: 14px; opacity: 0.8;">La connessione con YouTube è stata interrotta. <br><br> I risultati live continuano ad essere disponibili...</p>
    //         <button id="btn-reload-crash" style="
    //             background-color: var(--yt-red);
    //             color: white;
    //             border: none;
    //             padding: 10px 25px;
    //             font-size: 16px;
    //             font-weight: bold;
    //             border-radius: 5px;
    //             cursor: pointer;
    //             box-shadow: 0 4px 15px rgba(255, 0, 0, 0.3);
    //         ">Reload</button>
    //     </div>
    // `;
    // 5. Azione del bottone Reload. Che abbiamo disabilitato
    // document.getElementById('btn-reload-crash').onclick = () => {
    //     // Prova a forzare un piccolo salto temporale per risvegliare il player
    //     const currentTime = window.AppPlayer.getCurrentTime();
    //     window.AppPlayer.seekTo(currentTime + 0.1, true);

    //     // Oppure ricarica il video mantenendo la posizione
    //     // window.player.loadVideoById(window.AppPlayer.getVideoData().video_id, currentTime);
    // };

    overlay.innerHTML = `
        <div style="text-align: center; color: white; font-family: sans-serif;">
            <div style="font-size: 40px; margin-bottom: 10px;">⚠️</div>
            <h2 style="margin: 0 0 15px 0;">Video non disponibile</h2>
            <p style="margin-bottom: 20px; font-size: 14px; opacity: 0.8;">La connessione con YouTube è stata interrotta. <br><br> I risultati live continuano ad essere disponibili...</p>
        </div>
    `;

    playerWrapper.appendChild(overlay);

}

window.showStopVideoBtn = showStopVideoBtn;
function showStopVideoBtn() {
    const stopBtn = document.getElementById("stopVideoBtn");
    const isLandscape = window.innerWidth > window.innerHeight;
    if (!window.isAdmin && !isLandscape && stopBtn && window.posterInitialized) 
        stopBtn.classList.remove("hidden");
    else              
        stopBtn.classList.add("hidden");

}

function onPlayerStateChange(event) {
    // fa anche la gestione del video in buffering indefinitivamente
    const iconElement = document.getElementById('play-pause-icon');
    const playerWrapper = document.getElementById('player-wrapper');

    //console.log("onPlayerStateChange: " + event.data);

    // 1. GESTIONE PLAYING (Stato 1)
    if (event.data === YT.PlayerState.PLAYING) {

        if (window.NEW_PLAYER_INTERFACE) window.showStopVideoBtn();

        // --- LOGICA DI RIMOZIONE OVERLAY ---
        const existingOverlay = document.getElementById('crash-overlay');
        if (existingOverlay) {
            existingOverlay.remove(); // Rimuove il popup se il video torna in vita
        }
        
        if (playerWrapper) {
            playerWrapper.style.border = "none"; // Rimuove il bordo rosso
        }
        window.resetUITimer();
        
        // Rimuovi eventuali avvisi di blocco
        //if (playerWrapper) playerWrapper.style.border = "none";
        clearTimeout(bufferingTimeout);

        if (playerPip && playerPip.playVideo) {
            playerPip.seekTo(window.AppPlayer.getCurrentTime(), true);
            playerPip.playVideo();
        }
    } 
    
    // 2. GESTIONE BUFFERING (Stato 3)
    else if (event.data === YT.PlayerState.BUFFERING) {
        console.warn("⚠️ Buffering rilevato...");
        
        // Avvia il timer per rilevare se la live è "morta"
        clearTimeout(bufferingTimeout);
        bufferingTimeout = setTimeout(() => {
            handleLiveCrash();
        }, MAX_BUFFERING_TIME);
    }

    // 3. GESTIONE PAUSA O ALTRO (Stato 2, 0, 5)
    else {
        clearTimeout(bufferingTimeout); // Se metti in pausa, non è un crash

        if (playerPip && playerPip.pauseVideo) {
            playerPip.pauseVideo();
        }
    }

//    syncPlayPauseIcons();

}

function syncPlayPauseIcons() {
    // NON FUNZIONA
    if (!window.player) return;

    const state = window.AppPlayer.getPlayerState();
    
    // Riferimenti ai bottoni (assicurati che gli ID corrispondano ai tuoi)
    const btnCentral = document.getElementById('btn-central-toggle');
    const btnBar = document.getElementById('play-pause-icon'); // Il bottone già esistente nella barra
    
    // Path delle icone (SVG standard YouTube)
    const playPath = "M8 5v14l11-7z";
    const pausePath = "M6 19h4V5H6v14zm8-14v14h4V5h-4z";

    const isPlaying = (state === window.AppPlayerState.PLAYING);
    const newPath = isPlaying ? pausePath : playPath;

    // Aggiorna Bottone Centrale
    if (btnCentral) {
        const svg = btnCentral.querySelector('svg path');
        if (svg) svg.setAttribute('d', newPath);
    }

    // Aggiorna Bottone Barra
    if (btnBar) {
        const svg = btnBar.querySelector('svg path');
        if (svg) svg.setAttribute('d', newPath);
    }
}

function formatTime(sec) {
    let m = Math.floor(sec / 60);
    let s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' + s : s}`;
}

window.resetUITimer = resetUITimer;
function resetUITimer() {
    //try {
        if (isLongPressZoomActive) return;
        const ui = document.getElementById('ui-layer');
        ui.style.opacity = "1";
        ui.style.pointerEvents = "auto";
        ui.style.zIndex = "20";

        clearTimeout(uiTimeout);
        if (window.player && window.AppPlayer.getPlayerState && window.AppPlayer.getPlayerState() === 1) {
            uiTimeout = setTimeout(() => { 
                ui.style.opacity = "0"; 
                ui.style.pointerEvents = "none";
                ui.style.zIndex = "10";
            }, 4000);
        }
    //} catch(e) {}
}

//#region GESTIONE PLAYER YOUTUBE

window.onYouTubeIframeAPIReady = function () {
  console.log("YouTube API Ready");
};

function onPlayerReady() {
  console.log("✅ Player YouTube pronto");
  // Collega l'istanza nativa a window.player richiesta dal tuo Adapter
  window.player = window.player || window.AppPlayerInstance; 

  finalizeInitPlayer('youtube');
}

window.createPlayer = createPlayer;
function createPlayer(url, vId) {
  if (!vId) return;
  if (url.includes("you"))
    window.createYTPlayer(vId)
  else if (url.includes("twitch"))
    window.createTwitchPlayer(vId, true);
}

window.createYTPlayer = createYTPlayer;
function createYTPlayer(vId) {
  if (!vId) return;

  document.getElementById('ytplayer').classList.remove('hidden');
  document.getElementById('twitchplayer').classList.add('hidden');
  window.activePlayerType = 'youtube';

  window.player = new YT.Player('ytplayer', {
    height: '100%',
    width: '100%',
    videoId: vId,
    playerVars: {
      'autoplay': 1,
      'controls': 0,
      'rel': 0,
      'modestbranding': 1,
      'playsinline': 1
    },
    events: {
      'onReady': onPlayerReady,
      'onStateChange': onPlayerStateChange
    }
  });

  playerPip = new YT.Player('ytplayer-pip', {
      videoId: vId,
      playerVars: { 'controls': 0, 'disablekb': 1, 'rel': 0, 'modestbranding': 1, 'iv_load_policy': 3, 'mute': 1 },
      events: {
          'onReady': () =>  console.log("Player PiP pronto.") // setPipPosition(window.pipConfig) // ; 
      }
  });
}

function finalizeInitPlayer(tipoPlayer) {
  console.log(`? Finalizzazione interfaccia comune tramite Adapter per: ${tipoPlayer}`);

  // 1. Configura il tipo di player attivo per l'Adapter
  window.activePlayerType = tipoPlayer;

  // 2. Nascondi lo spinner di caricamento
  const videoSpinner = document.getElementById("video-loading");
  if (videoSpinner) videoSpinner.classList.add("hidden");

  // 3. Gestione MUTE universale tramite l'Adapter
  if (typeof window.AppPlayer.mute === 'function') {
    window.AppPlayer.mute();
  }

  // 4. CONTROLLO LIVE / SEEK UNIVERSALE
  if (window.isLiveStream()) {
    if (window.activePlayerType === 'youtube') {
      // Trucco specifico per forzare YouTube al "punto ora" della live
      if (typeof window.AppPlayer.seekTo === 'function') {
        window.AppPlayer.seekTo(1000000);
      }
      setTimeout(() => {
        if (typeof window.syncToLive === 'function') window.syncToLive();
      }, 1000);
    }
    // Nota: Twitch va in live autonomamente all'avvio, l'Adapter non ha bisogno di manipolare il tempo.
  } else {
    // Se è un video registrato (VOD), salta al punto di inizio partita usando il seekTo unificato
    if (typeof window.AppPlayer.seekTo === 'function') {
      window.AppPlayer.seekTo(window.matchStartTime);
    }
  }

  // 5. Avvia la riproduzione tramite l'Adapter
  if (typeof window.AppPlayer.play === 'function') {
    window.AppPlayer.play();
  }

  // 6. Stabilizzazione della timeline HUD
  setTimeout(() => {
    if (window.timelineInterval) clearInterval(window.timelineInterval);
    if (typeof window.tickTimeline === 'function') {
      window.timelineInterval = setInterval(window.tickTimeline, window.REFRESH_TIME);
    }
    
    // Sincronizzazione del maxCurrentTime tramite il getCurrentTime unificato dell'Adapter
    if (typeof window.AppPlayer.getCurrentTime === 'function') {
      maxCurrentTime = window.AppPlayer.getCurrentTime(); 
    }
  }, 1000); 

  // 7. Iniezione controlli dinamici e overlay grafici sopra il video
  if (typeof injectYtControls === 'function') injectYtControls();
  if (typeof initializePlayerOverlays === 'function') initializePlayerOverlays(window.AppPlayer);

  // 8. Imposta l'icona sul pulsante Pausa (poiché il player parte in riproduzione)
  const icon = document.getElementById('play-pause-icon');
  if (icon && typeof pauseIcon !== 'undefined') {
    icon.innerHTML = pauseIcon;
  }
}


window.isLiveStream = isLiveStream;
function isLiveStream() {
  const data = window.AppPlayer.getVideoData();
  const duration = window.AppPlayer.getDuration();
  
  // Se data.isLive è vero, ottimo. 
  // ALTRIMENTI, se la durata è 0 durante il caricamento, è quasi certamente una Live.
  // Un video normale ha sempre una durata > 0 appena pronto.
  return data.isLive === true || duration === 0;
}

function updateLiveEdge() {
  const current = window.AppPlayer.getCurrentTime();
  if (current > maxCurrentTime) {
    maxCurrentTime = current;
    userIsBehindBecauseOfPause = false;
  }
}

function isBehindLiveEdge(threshold = 7) { 
  if (window.isLiveStream()) {
    // Nelle live di YouTube, la durata totale è il punto "ora"
    const liveEdge = window.AppPlayer.getDuration(); 
    const current = window.AppPlayer.getCurrentTime();
    
    // Se la differenza tra la fine del video e dove sei tu è > soglia, sei in ritardo
    const diff = Math.abs(hmsToSeconds(window.systemClockVisualizzato) - hmsToSeconds(window.orarioVisualizzatoFormattato));
    return diff > threshold;
  }
  
  // Per i video registrati (finti live), manteniamo la tua logica originale
  const current = window.AppPlayer.getCurrentTime();
  return (maxCurrentTime - current) > threshold;
}

function isUserBehindLive() {
  // Caso 1: sei in pausa
  if (window.AppPlayer.getPlayerState() === window.AppPlayerState.PAUSED) {
    return true;
  }

  // Caso 2: eri in pausa e hai appena ripreso
  if (userIsBehindBecauseOfPause) {
    return true;
  }

  // Caso 3: sei indietro rispetto al live edge
  return isBehindLiveEdge(LIVE_OFFSET);
}

window.syncToLive = syncToLive;
function syncToLive() {
  if (!window.player || typeof window.AppPlayer.seekTo !== "function") return;

  // 1. Se è una trasmissione Live reale di YouTube
  if (window.isLiveStream()) {
    // Cercando un valore altissimo (es. 1 miliardo), 
    // YouTube ci porta automaticamente all'ultimo secondo disponibile
    window.AppPlayer.seekTo(1000000000, true);
  } else {
    // 2. Se è un video "finto live" o registrato
    // Usiamo la variabile maxCurrentTime che hai già nel tuo script
    window.AppPlayer.seekTo(maxCurrentTime, true);
  }

  // Resettiamo lo stato di "ritardo"
  userIsBehindBecauseOfPause = false;
  
  // Assicuriamoci che il video riparta se era in pausa
  window.AppPlayer.play();
  
  console.log("Sincronizzazione al Live Edge completata.");
}

window.checkLiveStatus = checkLiveStatus;
function checkLiveStatus() {
  const liveStatusBadge = document.getElementById("hud-live-status");
  if (!window.player || !liveStatusBadge || typeof window.AppPlayer.getDuration !== "function") return;

  updateLiveEdge();

  const isLive = !isUserBehindLive();

  if (window.isLiveStream()) {
    liveStatusBadge.classList.remove("hidden");
    if (isLive) {
      liveStatusBadge.classList.remove("is-delayed");
      liveStatusBadge.classList.add("is-live");
      liveStatusBadge.innerHTML = "●";
    } else {
      liveStatusBadge.classList.remove("is-live");
      liveStatusBadge.classList.add("is-delayed");
      liveStatusBadge.innerHTML = "?";
    }
  } else {
    liveStatusBadge.classList.add("hidden");
  }

  if (window.oraInizioDiretta) {
    const parti = window.oraInizioDiretta.split(":");
    const orarioInizioVideo = new Date();
    orarioInizioVideo.setHours(parseInt(parti[0], 10), parseInt(parti[1], 10), parseInt(parti[2] || 0, 10), 0);

    // --- CORREZIONE QUI ---
    let currentTime = window.AppPlayer.getCurrentTime();
    const durataTotale = window.AppPlayer.getDuration();
    const statoPlayer = window.AppPlayer.getPlayerState();

    // Se il video è finito (Stato 0), forziamo il tempo alla durata totale
    if (statoPlayer === window.AppPlayerState.ENDED || (durataTotale > 0 && currentTime < 1 && window.userNavigatedToEnd)) {
      currentTime = durataTotale;
    }

    orarioVisualizzato = new Date(orarioInizioVideo.getTime() + (currentTime * 1000));
    // -----------------------

    const vHH = String(orarioVisualizzato.getHours()).padStart(2, '0');
    const vMM = String(orarioVisualizzato.getMinutes()).padStart(2, '0');
    const vSS = String(orarioVisualizzato.getSeconds()).padStart(2, '0');

    window.orarioVisualizzatoFormattato = `${vHH}:${vMM}:${vSS}`;

    const clockEl = document.getElementById("hud-video-time");
    if (clockEl) {
      clockEl.textContent = window.orarioVisualizzatoFormattato;
    }
  }
}

//#endregion

/**
 * Forzatura visiva temporanea per aggirare il blocco Autoplay di Twitch.
 * Porta l'Iframe in prima linea, esegue il play e ripristina la struttura.
 */
window.nascondiOverlayUI = nascondiOverlayUI;
function nascondiOverlayUI() {
  const overlay = document.getElementById("transparent-overlay");
  const uiLayer = document.getElementById("ui-layer");

  // Nascondiamo i colpevoli delle sovrapposizioni
  if (overlay) overlay.style.setProperty("display", "none", "important");
  if (uiLayer) uiLayer.style.setProperty("display", "none", "important");

  // Ripristiniamo tutto dopo 200 millisecondi (quando il video è già partito)
  setTimeout(() => {
    if (overlay) overlay.style.display = "block";
    if (uiLayer) uiLayer.style.display = "flex"; // o lo stile originale del tuo CSS
  }, 5000);

  
}