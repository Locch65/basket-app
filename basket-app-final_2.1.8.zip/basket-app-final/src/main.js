import './style-variables.css'

import './common.js';
import './myTeamConfig.js';
import './calendario.js';
import './direttavideo-highlights.js';
import './direttavideo-ytplayer.js';
import './direttavideo.js';
import './menus.js';
import './maps.js';
import './AI_interface.js';
import './U14_FN.js';

console.log("Main bundle caricato correttamente.");