const MY_TEAM = window.MY_TEAM_SHORTNAME.toUpperCase(); // definito in myTeamConfig.js: ad es. "POLI_SMILE"

const V1_CONFIG_FIP = {
    'U14': {
        name: 'U14 - Titolo',
        mainUrl:    'https://fip.it/risultati/?group=campionati-regionali&regione_codice=PI&comitato_codice=RPI&sesso=F&codice_campionato=U14/F&codice_fase=4',
        detailsUrl: 'https://fip.it/risultati/?group=campionati-regionali&regione_codice=PI&comitato_codice=RPI&sesso=F&codice_campionato=U14/F&codice_fase=4&codice_girone=78071'
    },
    'U15': {
        name: 'U15 - Coppa',
        mainUrl:    'https://fip.it/risultati/?group=campionati-regionali&regione_codice=PI&comitato_codice=RPI&sesso=F&codice_campionato=U15/F&codice_fase=3',
        detailsUrl: 'https://fip.it/risultati/?group=campionati-regionali&regione_codice=PI&comitato_codice=RPI&sesso=F&codice_campionato=U15/F&codice_fase=3&codice_girone=78161'
        // Nota: Aggiungi qui l'eventuale codice_girone specifico se necessario come per l'U14
    }
};

const FIP_CACHE = {
    classifiche: {}, // Es: { 'U14': [{squadra: 'POLI_SMILE', punti: 20, ...}, ...], 'U15': [...] }
    partite: {}      // Es: { 'U14': [match1, match2, ...], 'U15': [...] }
};


function generaConfigFip(arrayChiavi, arrayStringhe) {
    const config = {};

    arrayStringhe.forEach((stringaMultilinea, index) => {
        // Se la stringa associata è indefinita o vuota, passa alla successiva
        if (!stringaMultilinea) return;

        // Divide la stringa in righe eliminando spazi bianchi superflui o righe vuote
        const righe = stringaMultilinea.split('\n').map(r => r.trim()).filter(r => r.length > 0);
        
        // Se la stringa non ha almeno il titolo e un URL, la salta
        if (righe.length < 2) return;

        const name = righe[0];             // La prima riga è sempre il nome (es: "U15 - Coppa")
        const mainUrl = righe[1];          // La seconda riga è il mainUrl
        const detailsUrl = righe[2] || ''; // La terza (se c'è) è il detailsUrl, altrimenti vuota

        // Prende la chiave corrispondente passata dall'array esterno. 
        // Se per qualche motivo manca, fa il fallback sul vecchio metodo dello spazio.
        const chiaveCategoria = arrayChiavi[index] || name.split(' ')[0];

        // Costruiamo l'oggetto usando la chiave esplicita
        config[chiaveCategoria] = {
            name: name,
            mainUrl: mainUrl,
            detailsUrl: detailsUrl
        };
    });

    return config;
}

const CONFIG_FIP = (window.APP_VERSION.startsWith("2.")) ? 
    generaConfigFip(window.MY_TEAM_CAMPIONATO, [window.MY_TEAM_LINK_FIP_MAIN_1, window.MY_TEAM_LINK_FIP_MAIN_2]) :
    V1_CONFIG_FIP;

// Funzione per tornare alla classifica
window.showClassifica = showClassifica;
function showClassifica() {
    // --- RIPRISTINO TITOLO ORIGINALE ---
    document.querySelector('.brand-section h2').textContent = "CLASSIFICHE FIP";

    document.getElementById('table-container').classList.remove('hidden');
    document.querySelector('.filter-container').classList.remove('hidden');
    document.getElementById('details-container').classList.add('hidden');
    // Mostra il suggerimento quando torni alla classifica
    document.getElementById('hint-classifica').classList.remove('hidden');
    document.getElementById('btn-calendario-completo').classList.remove('hidden');

    // --- GESTIONE VISIBILITÀ REFRESH ---
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    if (isAdmin) {
        document.getElementById('admin-actions').classList.remove('hidden');
    }        
}

window.updateCategory = updateCategory;
function updateCategory() {
    const container = document.getElementById('table-container')
    const selected = document.querySelector('input[name="categoria"]:checked').value;
    const config = CONFIG_FIP[selected];
    
    if (Object.keys(CONFIG_FIP).length === 0 || CONFIG_FIP[selected] === undefined) {
        alert("Classifiche FIP non configurate correttamente. Chiedi all'amministratore.");
        if (container) container.innerHTML = "";
        return;
    }

    document.getElementById('fip-external-link').href = config.mainUrl;

    // Se abbiamo la classifica ma NON abbiamo le partite, forziamo un caricamento silenzioso delle partite
    // per permettere il ricalcolo dei colori rossi nella tabella.
    if (FIP_CACHE.classifiche[selected] && !FIP_CACHE.partite[selected]) {
            // Carichiamo le partite in background per il cross-check
            silentlyLoadMatches(selected, config.detailsUrl);
    }

    if (FIP_CACHE.classifiche[selected]) {
        renderTableFromData(FIP_CACHE.classifiche[selected]);
    } else {
        fetchAndParseTable(selected, config.mainUrl, false, true);
    }
}

// Funzione helper per caricare i dati necessari al confronto senza bloccare l'UI
async function silentlyLoadMatches(cat, detailsUrl) {
    try {
        const params = new URLSearchParams({
            appVersion: window.APP_VERSION,
            teamId: window.getTeamId(),
            getAllTeamMatches: true,
            url: detailsUrl,
            team: "*",
            userId: userId,
            action: "GetAllTeamMatches",
            details: JSON.stringify(typeof getDeviceData !== 'undefined' ? getDeviceData : {})
        });
        const response = await fetch(`${window.getBackendUrl()}?${params.toString()}`);
        const data = await response.json();
        if (data && data.status !== "error") {
            FIP_CACHE.partite[cat] = data;
            // Una volta ottenute le partite, ri-renderizziamo per mostrare i rossi
            const currentSelected = document.querySelector('input[name="categoria"]:checked').value;
            if (currentSelected === cat) renderTableFromData(FIP_CACHE.classifiche[cat]);
        }
    } catch(e) { console.error("Errore caricamento silente", e); }
}    

function renderTableFromData(data) {
    const container = document.getElementById('table-container');
    const selected = document.querySelector('input[name="categoria"]:checked').value;
    const notaElement = document.getElementById('nota-classifica');
    
    const allMatches = FIP_CACHE.partite[selected] || [];
    let mostraNota = false;

    let html = `
        <table class="fip-custom-table">
            <thead>
                <tr>
                    <th class="col-squadra">Squadra</th>
                    <th class="col-dati">P</th><th class="col-dati">G</th>
                    <th class="col-dati">V</th><th class="col-dati">S</th>
                    <th class="col-dati">PF</th><th class="col-dati">PS</th>
                </tr>
            </thead>
            <tbody>`;

    data.forEach(item => {
        const isMyTeam = item.nome.toUpperCase().includes(MY_TEAM);
        
        let realeVinte = 0;
        let realePerse = 0;
        
        allMatches.forEach(m => {
            const isTeamA = m.teamA.toUpperCase() === item.nome.toUpperCase();
            const isTeamB = m.teamB.toUpperCase() === item.nome.toUpperCase();
            if (isTeamA || isTeamB) {
                const winStatus = determinaVittoria(item.nome, m.teamA, m.scoreA, m.teamB, m.scoreB);
                if (winStatus === true) realeVinte++;
                else if (winStatus === false) realePerse++;
            }
        });

        const hasDiscrepancy = parseInt(item.vinte) !== realeVinte || parseInt(item.perse) !== realePerse;
        if (hasDiscrepancy) mostraNota = true;

        const redStyle = hasDiscrepancy ? "color: #ef4444; font-weight: bold;" : "";
        
        // --- MODIFICA: onclick spostato sul TR ---
        html += `
            <tr class="${isMyTeam ? 'highlight' : ''}" 
                onclick="loadTeamDetails('${item.nome.replace(/'/g, "\\'")}')">
                <td class="col-squadra font-bold">
                    ${item.nome}
                </td>
                <td class="col-dati font-bold punti-cell" style="${redStyle}">
                    ${item.punti}${hasDiscrepancy ? '<sup>*</sup>' : ''}
                </td>
                <td class="col-dati" style="${redStyle}">${item.giocate}</td>
                <td class="col-dati" style="${redStyle}">${item.vinte}</td>
                <td class="col-dati" style="${redStyle}">${item.perse}</td>
                <td class="col-dati" style="${redStyle}">${item.fatti}</td>
                <td class="col-dati" style="${redStyle}">${item.subiti}</td>
            </tr>`;
    });

    html += `</tbody></table>`;
    container.innerHTML = html;

    if (mostraNota) {
        notaElement.classList.remove('hidden');
    } else {
        notaElement.classList.add('hidden');
    }
}

async function fetchAndParseTable(cat, targetUrl, forceRefresh = false, forceRender = true) {
    const container = document.getElementById('table-container');

    // Se non è un refresh forzato e i dati esistono, abbiamo già gestito in updateCategory,
    // ma aggiungiamo un controllo di sicurezza qui.
    if (!forceRefresh && FIP_CACHE.classifiche[cat]) {
        renderTableFromData(FIP_CACHE.classifiche[cat]);
        return;
}

container.innerHTML = '<div class="loading">Recupero classifica aggiornata...</div>';

const params = new URLSearchParams({
        appVersion: window.APP_VERSION,
        teamId: window.getTeamId(),
        fetchExternal: "true",
        url: targetUrl,
        userId: typeof userId !== 'undefined' ? userId : 'guest',
        action: "GetClassifica", 
        details: JSON.stringify(typeof getDeviceData !== 'undefined' ? getDeviceData : {}) 
});

try {
    const response = await fetch(`${window.getBackendUrl()}?${params.toString()}`);
    const htmlString = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    const sourceTable = doc.querySelector('.results-tab.results-ranking-full[data-trigger="ranking"] table');

    if (!sourceTable) throw new Error("Dati non disponibili");

    const rows = sourceTable.querySelectorAll('tbody tr');
    const rankingData = [];

    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 8) {
            rankingData.push({
                nome: cols[1].innerText.trim(),
                punti: cols[2].innerText.trim(),
                giocate: cols[3].innerText.trim(),
                vinte: cols[4].innerText.trim(),
                perse: cols[5].innerText.trim(),
                fatti: cols[6].innerText.trim(),
                subiti: cols[7].innerText.trim()
            });
        }
    });

    // SALVATAGGIO NELLA CACHE (ARRAY)
    FIP_CACHE.classifiche[cat] = rankingData;
    
    if (forceRender) renderTableFromData(rankingData);
} catch (error) {
    //console.error(error);
    container.innerHTML = `<div class="loading" style="color:red; animation:none;">Errore nel caricamento.</div>`;
}
}

window.loadTeamDetails = loadTeamDetails;
async function loadTeamDetails(teamName) {
    const selectedCat = document.querySelector('input[name="categoria"]:checked').value;
    const config = CONFIG_FIP[selectedCat];

    // NASCONDI IL TASTO REFRESH IN DETTAGLIO
    document.getElementById('admin-actions').classList.add('hidden');

    document.querySelector('.brand-section h2').textContent = `Partite ${config.name}`;
    document.getElementById('table-container').classList.add('hidden');
    document.getElementById('nota-classifica').classList.add('hidden');
    document.querySelector('.filter-container').classList.add('hidden');
    // Nascondi il suggerimento nella pagina di dettaglio
    document.getElementById('hint-classifica').classList.add('hidden');        
    document.getElementById('details-container').classList.remove('hidden');
    document.getElementById('btn-calendario-completo').classList.add('hidden');
    document.getElementById('selected-team-name').textContent = teamName;

    // Controllo cache per le partite
    if (FIP_CACHE.partite[selectedCat]) {
        let matches = FIP_CACHE.partite[selectedCat];
        
        // Se non è la wildcard "*", filtra per la squadra specifica
        if (teamName !== "*") {
            matches = matches.filter(m => 
                m.teamA.toUpperCase().includes(teamName.toUpperCase()) || 
                m.teamB.toUpperCase().includes(teamName.toUpperCase())
            );
        }

        const processed = matches.map(m => ({
            ...m,
            isWin: determinaVittoria(teamName === "*" ? MY_TEAM : teamName, m.teamA, m.scoreA, m.teamB, m.scoreB)
        }));
        
        renderDetails(teamName, processed);
        return;
    }

    // Se non in cache (es. primo avvio senza refresh admin), scarica normalmente
    const listContainer = document.getElementById('team-matches-list');
    listContainer.innerHTML = '<div class="loading">Recupero dati dal server...</div>';

    try {
        const params = new URLSearchParams({
            appVersion: window.APP_VERSION,
            teamId: window.getTeamId(),
            getAllTeamMatches: true, // Chiama il nuovo caso aggiunto sopra
            url: config.detailsUrl,
            team: teamName,
            userId: userId,
            action: "GetAllTeamMatches",
            details: JSON.stringify(getDeviceData)
        });

        const response = await fetch(`${window.getBackendUrl()}?${params.toString()}`);
        const allMatches = await response.json();

        if (allMatches.status === "error") throw new Error(allMatches.message);

        // Map dei risultati per determinare vittoria/sconfitta/futura
        const processedMatches = allMatches.map(m => ({
            ...m,
            isWin: determinaVittoria(teamName, m.teamA, m.scoreA, m.teamB, m.scoreB)
        }));

        renderDetails(teamName, processedMatches);

    } catch (error) {
        listContainer.innerHTML = `<div class="loading" style="color:red; animation:none;">Errore: ${error.message}</div>`;
    }
}

function determinaVittoria(target, tA, sA, tB, sB) {
    // Pulizia dei dati
    const scoreA = sA.trim();
    const scoreB = sB.trim();

    // Se i punteggi sono vuoti o non sono numeri, è una partita futura
    if (scoreA === "" || scoreB === "" || isNaN(parseInt(scoreA))) {
        return null; 
    }

    const ptsA = parseInt(scoreA);
    const ptsB = parseInt(scoreB);
    
    const isTeamA = tA.toUpperCase().includes(target.toUpperCase());
    
    if (isTeamA) return ptsA > ptsB;
    return ptsB > ptsA;
}

function renderDetails(teamName, matches) {
    const listContainer = document.getElementById('team-matches-list');
    if (matches.length === 0) {
        listContainer.innerHTML = "<p style='text-align:center; padding:20px;'>Nessun risultato trovato.</p>";
        return;
    }

    listContainer.innerHTML = matches.map(m => {
        let statusClass = "";
        let scoreDisplay = "";

        // Logica per determinare lo stato del tab (isWin può essere true, false o null)
        if (m.isWin === null) {
            statusClass = "future"; 
            scoreDisplay = `<span class="status-badge status-future" style="background:#f1f5f9; color:#94a3b8; border:1px solid #e2e8f0;">Da giocare</span>`;
        } else if (m.isWin === true || teamName === "*") {
            statusClass = "win";
            scoreDisplay = `<span class="font-bold" style="background:#dcfce7; color:#166534; padding:2px 8px; border-radius:4px;">${m.scoreA} - ${m.scoreB}</span>`;
        } else {
            statusClass = "loss";
            scoreDisplay = `<span class="font-bold" style="background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:4px;">${m.scoreA} - ${m.scoreB}</span>`;
        }

        // Costruiamo la stringa della data/ora (se presenti)
        const dateTimeDisplay = (m.date || m.time) 
            ? ` • <i class="far fa-calendar-alt"></i> ${m.date || ''} ${m.time || ''}` 
            : '';

        return `
            <div class="match-detail-card ${statusClass}" style="${statusClass === 'future' ? 'background: #fff; border-left: 4px solid #cbd5e1;' : ''}">
                <div class="match-info" style="color: #64748b; font-size: 0.95rem; margin-bottom: 8px; display: flex; justify-content: space-between;">
                    <span>${m.info}</span>
                    <span style="font-size: 0.9rem;">${dateTimeDisplay}</span>
                </div>
                <div class="match-teams" style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
                    <span style="flex: 1; text-align: left; line-height: 1.2; ${m.teamA.toUpperCase().includes(MY_TEAM) ? 'color: var(--fip-blue); font-weight: bold;' : ''}">${m.teamA}</span>
                    <div style="flex: 0 0 auto; min-width: 60px; text-align: center;">${scoreDisplay}</div>
                    <span style="flex: 1; text-align: right; line-height: 1.2; ${m.teamB.toUpperCase().includes(MY_TEAM) ? 'color: var(--fip-blue); font-weight: bold;' : ''}">${m.teamB}</span>
                </div>
            </div>
        `;
    }).join('');
}

function checkAdminRefresh() {
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    const adminActions = document.getElementById('admin-actions');

    if (isAdmin && adminActions) {
        const btn = document.getElementById('btn-refresh-fip');
        adminActions.classList.remove('hidden');

        btn.onclick = async function() {
            const container = document.getElementById('table-container');
            btn.disabled = true; // Disabilita il tasto durante l'operazione
            
            // Messaggio lampeggiante all'interno del div tabella
            container.innerHTML = '<div class="loading">Aggiornamento globale dal sito FIP...</div>';
            
            try {
                const categorie = Object.keys(CONFIG_FIP);
                
                for (const cat of categorie) {
                    const config = CONFIG_FIP[cat];
                    
                    // 1. Aggiorna la classifica in cache (forzando il refresh)
                    // Passiamo true per ignorare la cache esistente e forzare la fetch
                    await fetchAndParseTable(cat, config.mainUrl, true, false);
                    
                    // 2. Aggiorna tutte le partite in cache (Wildcard "*")
                    // Chiamiamo loadTeamDetails in modalità "silenziosa" per popolare FIP_CACHE.partite
                    const params = new URLSearchParams({
                        appVersion: window.APP_VERSION,
                        teamId: window.getTeamId(),
                        getAllTeamMatches: true, // Chiama il nuovo caso aggiunto sopra
                        url: config.detailsUrl,
                        team: "*",
                        userId: userId,
                        action: "GetAllTeamMatches",
                        details: JSON.stringify(getDeviceData)
                    });
                    
                    const response = await fetch(`${window.getBackendUrl()}?${params.toString()}`);
                    const matchesData = await response.json();
                    
                    if (matchesData.status !== "error") {
                        FIP_CACHE.partite[cat] = matchesData;
                    }
                }

                // 3. Salvataggio della cache aggiornata nel localStorage
                saveCacheToLocalStorage();
                
                //alert("Dati aggiornati con successo!");

            } catch (error) {
                console.error("Errore durante il refresh:", error);
                //alert("Si è verificato un errore durante l'aggiornamento.");
            } finally {
                btn.disabled = false;
                
                // Se l'utente era in una schermata di dettaglio, torna alla classifica
                showClassifica();
                updateCategory();
            }
        };
        // Listener per il nuovo tasto Sync
        document.getElementById('btn-sync-firebase').onclick = async function() {
            if (confirm("Vuoi salvare su Firebase?")) {
                try {
                    window.saveToFirebaseHistory('classificheFIP/', FIP_CACHE);
                    } catch (e) {
                    alert("Errore durante la sincronizzazione: " + e.message);
                } finally {
                    this.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Sync Firebase';
                    this.disabled = false;
                }
            }
        };            
    }
}

// Da chiamare dopo ogni aggiornamento della cache
function saveCacheToLocalStorage() {
    window.setLocalStorage('FIP_DATA_CACHE', JSON.stringify(FIP_CACHE));
}

// Da chiamare all'inizio di init()
window.loadCacheFromLocalStorage = loadCacheFromLocalStorage;
function loadCacheFromLocalStorage() {
    const saved = window.getLocalStorage('FIP_DATA_CACHE');
    if (saved) {
        const parsed = JSON.parse(saved);
        FIP_CACHE.classifiche = parsed.classifiche || {};
        FIP_CACHE.partite = parsed.partite || {};
    }
}    

window.mostraCalendarioCompleto = function() {
    // Chiamiamo la funzione esistente passando "*" per caricare tutto
    loadTeamDetails("*");
};

async function init() {
    const startTime = performance.now();
    
    // 1. Tenta il caricamento da Firebase (Percorso: "fip_data/")
    // Supponiamo che saveCacheToLocalStorage() salvi l'intero oggetto FIP_CACHE
    try {
        // Utilizziamo la funzione helper per leggere da Firebase
        const data = await readFromFirebaseHistory("classificheFIP/");

        if (data) {
            const endTime = performance.now();
            console.log(`Dati Firebase caricati in ${(endTime - startTime).toFixed(2)} ms`);
            
            // Popoliamo la cache in memoria con i dati da Firebase
            FIP_CACHE.classifiche = data.classifiche || {};
            FIP_CACHE.partite = data.partite || {};
            
            // Aggiorniamo la cache locale per usi offline futuri
            saveCacheToLocalStorage();
        } else {
            throw new Error("Percorso Firebase vuoto");
        }
    } catch (err) {
        console.error("Errore Firebase, provo a usare la cache locale:", err);
        
        // FALLBACK: Tenta di recuperare i dati dal localStorage
        window.loadCacheFromLocalStorage();
        
        if (!FIP_CACHE.classifiche || Object.keys(FIP_CACHE.classifiche).length === 0) {
            console.warn("Nessun dato disponibile né in Firebase né in cache locale.");
        }
    }

    // 2. Registrazione utente e controlli UI
    if (typeof window.registerUserId === 'function') {
        try { await window.registerUserId(); } catch (e) {}
    }

    // 3. Verifica se mostrare il tasto refresh (solo per Admin)
    checkAdminRefresh();

    // 4. Renderizza la categoria selezionata (ora userà i dati appena caricati)
    updateCategory();
    
}

window.addEventListener('DOMContentLoaded', init);

