let datiOriginali = [];
let datiFinali = [];
let statoOrdine = JSON.parse(window.getLocalStorage("statoOrdineStats")) || { colonna: 'punti', ascendente: false };

async function loadPartiteCalendario() {
    try {
        // Leggiamo l'array da Firebase
        const dataFirebase = await readFromFirebaseHistory("partite/");
        if (dataFirebase) {
            // Trasformiamo l'array di Firebase in stringa JSON
            return JSON.stringify(dataFirebase);
        }
        
    } catch (e) { 
        console.error("Errore caricamento Calendario:", e); 
        return "";
    }
}


async function inizializzaDati() {
    const cacheRoster = window.getLocalStorage("datiRoster");
    const cacheStats = window.getLocalStorage("datiTutteLeStats");

    let roster, stats;

    // 1. Tentativo di caricamento da Cache
    if (cacheRoster && cacheStats) {
    try {
        roster = JSON.parse(cacheRoster);
        stats = JSON.parse(cacheStats);
    } catch (e) {
        console.error("Errore parsing cache, svuoto...", e);
        window.removeLocalStorage("datiRoster");
        window.removeLocalStorage("datiTutteLeStats");
    }
    }

    
    // 2. Se non abbiamo i dati (o la cache era corrotta), scarichiamo dal server
    if (!roster || !stats) {

        const dati = await window.aggiornaDatiRosterEStats();
        if (dati) {
            roster = dati.roster;
            stats = dati.stats;
            const isAdmin = window.getLocalStorage("isAdmin") === "true";
            if (isAdmin) saveToFirebaseRoster('roster/', dati.roster); 
        }

    }

    if (! ((roster.status === "error" || roster.length === 0) || stats.status === "error") )
    // 3. Passaggio alla mappatura (ora stats ha la chiave statisticheGiocatori)
        await mappaAzioniGiocatori(roster, stats);
    else {
        document.getElementById("loading").style.display = "none";
        alert("Roster non ancora disponibile!");    
    }    
}

async function mappaAzioniGiocatori(roster, stats) {
let partite = null;
    
    try {
        // Usiamo 'await' per fermare l'esecuzione finché Firebase non risponde
        const data = await window.readFromFirebaseHistory("partite/");
        if (data) {
            // Trasformiamo l'array di Firebase in stringa JSON
            partite = JSON.stringify(data);
        }
    } catch (err) {
        partite = "";
    }

    datiOriginali = roster.map((player, index) => {
        const azioniGiocatore = stats.statisticheGiocatori.filter(s => {
//            if (s.matchId && String(s.matchId).toLowerCase().includes("test")) {
            if (s.matchId && (String(s.matchId).toLowerCase().includes("test") || !partite.includes(s.matchId))) {
                return false;
            }
            return (
                s.giocatore === player.Nome + " " + player.Cognome ||
//                (s.numero == player["Numero Maglia"] && s.giocatore.includes(player.Cognome))
                (s.numero == player["Numero Maglia"])
            );
        });

        return {
            ...player,
            indiceOriginale: index,
            azioni: azioniGiocatore
        };
    });
    
    applicaFiltriECalcoli();
}

window.applicaFiltriECalcoli = function () {
    //const categoria = document.querySelector('input[name="catFilter"]:checked').value;
    const categoria = getCategoriaSelezionata();
    //const tipoCalcolo = document.querySelector('input[name="calcType"]:checked').value;
    const tipoCalcolo = getTipoCalcoloSelezionato();

    datiFinali = datiOriginali.map(player => {
        const azioniFiltrate = player.azioni.filter(a => {
            const id = a.matchId ? String(a.matchId) : "";
            if (categoria === "Tutti") return id.includes("U14") || id.includes("U15");
            return id.includes(categoria);
        });

        const matchIds = [...new Set(azioniFiltrate.map(s => s.matchId))];
        let tl = 0, t2 = 0, t3 = 0, puntiTotali = 0;
        
        // Variabili per %TL filtrata
        let tiriLiberiSegnati = 0;
        let tiriLiberiSbagliati = 0;

        azioniFiltrate.forEach(s => {
            try {
                const contatori = JSON.parse(s.contatori || "{}");
                tl += parseInt(contatori["1"]) || 0;
                t2 += parseInt(contatori["2"]) || 0;
                t3 += parseInt(contatori["3"]) || 0;

                // Calcolo %TL solo se il dato "0" (sbagliati) è presente nell'azione filtrata
                if (contatori.hasOwnProperty("0")) {
                    tiriLiberiSegnati += parseInt(contatori["1"]) || 0;
                    tiriLiberiSbagliati += parseInt(contatori["0"]) || 0;
                }
            } catch (e) { }
        });

        puntiTotali = (tl * 1) + (t2 * 2) + (t3 * 3);
        const pg = matchIds.length;
        const divisore = (tipoCalcolo === "Media" && pg > 0) ? pg : 1;

        // Calcolo percentuale filtrata
        const totaleTentativi = tiriLiberiSegnati + tiriLiberiSbagliati;
        const percentualeFiltrata = totaleTentativi > 0 
            ? Math.round((tiriLiberiSegnati / totaleTentativi) * 100) 
            : "N/D";

        return {
            ...player,
            partite: pg,
            punti: tipoCalcolo === "Media" ? (puntiTotali / divisore) : puntiTotali, // Rimosso toFixed qui se vuoi i decimali anche sui punti
            tl: tipoCalcolo === "Media" ? (tl / divisore) : tl,
            t2: tipoCalcolo === "Media" ? (t2 / divisore) : t2,
            t3: tipoCalcolo === "Media" ? (t3 / divisore) : t3,
            matchIdsFiltrati: matchIds,
            "%TL": percentualeFiltrata 
        };
    });

    applicaOrdinamento();
}

function renderTable() {
    const tbody = document.getElementById("table-body");
    const tfoot = document.getElementById("table-foot");
    const thead = document.querySelector("#roster-table thead tr");
    
    document.getElementById("loading").style.display = "none";
    document.getElementById("roster-table").style.display = "table";

    // 1. Header (invariato)
    if (thead && !thead.innerHTML.includes("%TL")) {
        thead.innerHTML = `
            <th onclick="gestisciClickOrdinamento('Numero Maglia')">#</th>
            <th onclick="gestisciClickOrdinamento('Cognome')">Giocatore</th>
            <th onclick="gestisciClickOrdinamento('partite')">PG</th>
            <th style="width: 45px;" onclick="gestisciClickOrdinamento('punti')">PTS</th>
            <th style="width: 40px;" onclick="gestisciClickOrdinamento('%TL')">%TL</th>
            <th onclick="gestisciClickOrdinamento('tl')">TL</th>
            <th onclick="gestisciClickOrdinamento('t2')">T2</th>
            <th onclick="gestisciClickOrdinamento('t3')">T3</th>
        `;
    }

    tbody.innerHTML = "";
    if (tfoot) tfoot.innerHTML = ""; 

    let setPartiteSquadra = new Set();
    
    // Variabili per accumulare i totali ASSOLUTI di squadra (senza medie dei singoli)
    let squadraPuntiAssoluti = 0;
    let squadraTL_Assoluti = 0;
    let squadraT2_Assoluti = 0;
    let squadraT3_Assoluti = 0;
    
    let squadraTL_Segnati = 0;
    let squadraTL_Sbagliati = 0;

    // const categoria = document.querySelector('input[name="catFilter"]:checked').value;
    const categoria = getCategoriaSelezionata();

    // --- Calcolo dei Totali basato sui filtri di gara ---
    datiFinali.forEach((p) => {
        if (p.matchIdsFiltrati) {
            p.matchIdsFiltrati.forEach(id => setPartiteSquadra.add(id));
        }

        // Estraiamo i dati assoluti direttamente dalle azioni filtrate per la categoria
        p.azioni.forEach(azione => {
            const idMatch = azione.matchId ? String(azione.matchId) : "";
            const appartieneACategoria = (categoria === "Tutti") 
                ? (idMatch.includes("U14") || idMatch.includes("U15"))
                : idMatch.includes(categoria);

            if (appartieneACategoria) {
                try {
                    const c = JSON.parse(azione.contatori || "{}");
                    
                    // Canestri fatti (assoluti)
                    const c1 = parseInt(c["1"]) || 0;
                    const c2 = parseInt(c["2"]) || 0;
                    const c3 = parseInt(c["3"]) || 0;

                    squadraTL_Assoluti += c1;
                    squadraT2_Assoluti += c2;
                    squadraT3_Assoluti += c3;
                    squadraPuntiAssoluti += (c1 * 1) + (c2 * 2) + (c3 * 3);

                    // Per %TL di squadra
                    if (c.hasOwnProperty("0")) {
                        squadraTL_Segnati += c1;
                        squadraTL_Sbagliati += parseInt(c["0"]) || 0;
                    }
                } catch(e) { }
            }
        });
    });

    const tentativiTotaliSquadra = squadraTL_Segnati + squadraTL_Sbagliati;
    const percentualaSquadra = tentativiTotaliSquadra > 0 
        ? Math.round((squadraTL_Segnati / tentativiTotaliSquadra) * 100) + "%" 
        : "";

    // --- CALCOLO VALORI RIGA SQUADRA ---
    const totPG_Squadra = setPartiteSquadra.size;
    //const tipoCalcolo = document.querySelector('input[name="calcType"]:checked').value;
    const tipoCalcolo = getTipoCalcoloSelezionato();
    
    // Se l'utente vuole la Media, dividiamo i totali assoluti per le partite totali, altrimenti teniamo i totali assoluti
    const divisoreSquadra = (tipoCalcolo === "Media" && totPG_Squadra > 0) ? totPG_Squadra : 1;

    const visualizzaSquadraPTS = squadraPuntiAssoluti / divisoreSquadra;
    const visualizzaSquadraTL = squadraTL_Assoluti / divisoreSquadra;
    const visualizzaSquadraT2 = squadraT2_Assoluti / divisoreSquadra;
    const visualizzaSquadraT3 = squadraT3_Assoluti / divisoreSquadra;

    const formattaSquadra = (valore) => {
        return valore % 1 === 0 ? valore : valore.toFixed(1);
    };

    // --- Rendering della riga TOTALE in alto ---
    const rowTotale = document.createElement("tr");
    rowTotale.className = "tfoot-totale"; 
    rowTotale.style.backgroundColor = "#bdc3c7"; 
    rowTotale.style.color = "#2c3e50";
    rowTotale.style.fontWeight = "bold";
    rowTotale.style.borderBottom = "3px solid #7f8c8d"; 

    rowTotale.innerHTML = `
        <td></td>
        <td class="col-nome">${tipoCalcolo === "Media" ? "MEDIA SQUADRA" : "TOTALE"}</td>
        <td>${totPG_Squadra}</td>
        <td class="pts-bold" style="width: 45px;">${formattaSquadra(visualizzaSquadraPTS)}</td>
        <td style="width: 40px; font-size: 1.0rem; text-align: center;">${percentualaSquadra}</td>
        <td>${formattaSquadra(visualizzaSquadraTL)}</td>
        <td>${formattaSquadra(visualizzaSquadraT2)}</td>
        <td>${formattaSquadra(visualizzaSquadraT3)}</td>
    `;
    tbody.appendChild(rowTotale);

    // --- Rendering dei singoli giocatori ---
    datiFinali.forEach((p) => {
        const visualizzaPercentuale = p["%TL"] === "N/D" ? "" : p["%TL"] + "%";
        
        const formattaDato = (valore) => {
            const num = parseFloat(valore) || 0;
            return num % 1 === 0 ? num : num.toFixed(1);
        };

        const row = document.createElement("tr");
        row.onclick = () => { window.location.href = `anagrafica.html?player=${p.indiceOriginale}`; };

        row.innerHTML = `
            <td><strong>${p["Numero Maglia"]}</strong></td>
            <td class="col-nome">${p.Cognome} ${p.Nome.charAt(0)}.</td>
            <td>${p.partite}</td>
            <td class="pts-bold" style="width: 45px;">${formattaDato(p.punti)}</td>
            <td style="width: 40px; font-size: 1.0rem; text-align: center;">${visualizzaPercentuale}</td>
            <td>${formattaDato(p.tl)}</td>
            <td>${formattaDato(p.t2)}</td>
            <td>${formattaDato(p.t3)}</td>
        `;
        tbody.appendChild(row);
    });
}
window.gestisciClickOrdinamento = gestisciClickOrdinamento;
function gestisciClickOrdinamento(colonna) {
    if (statoOrdine.colonna === colonna) {
    statoOrdine.ascendente = !statoOrdine.ascendente;
    } else {
    statoOrdine.colonna = colonna;
    statoOrdine.ascendente = (colonna === 'Cognome');
    }
    window.setLocalStorage("statoOrdineStats", JSON.stringify(statoOrdine));
    applicaOrdinamento();
}

function applicaOrdinamento() {
    datiFinali.sort((a, b) => {
    let vA = a[statoOrdine.colonna];
    let vB = b[statoOrdine.colonna];

    if (statoOrdine.colonna !== 'Cognome') {
        vA = parseFloat(vA) || 0;
        vB = parseFloat(vB) || 0;
    }

    if (typeof vA === 'string') {
        return statoOrdine.ascendente ? vA.localeCompare(vB) : vB.localeCompare(vA);
    }
    return statoOrdine.ascendente ? vA - vB : vB - vA;
    });

    aggiornaIconeHeader();
    renderTable();
}

function aggiornaIconeHeader() {
    const headers = document.querySelectorAll('th');
    const mappatura = {
        'Numero Maglia': '#', 
        'Cognome': 'Giocatore', 
        'partite': 'PG',
        'punti': 'PTS', 
        '%TL': '%TL', // <--- Aggiungi questa riga
        'tl': 'TL', 
        't2': 'T2', 
        't3': 'T3'
    };
    headers.forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    const testoPulito = th.innerText.replace(/[▲▼]/g, '').trim();
    if (testoPulito === mappatura[statoOrdine.colonna]) {
        th.classList.add(statoOrdine.ascendente ? 'sort-asc' : 'sort-desc');
    }
    });
}

window.forzaAggiornamentoRoster = forzaAggiornamentoRoster;
function forzaAggiornamentoRoster() {
    window.removeLocalStorage("datiRoster");
    window.removeLocalStorage("datiTutteLeStats");
    location.reload();
}

function salvaStatistichePerGemini() {
    const reportPerIA = datiOriginali.map(player => {
        
        const calcolaDettagli = (cat) => {
            const azioni = player.azioni.filter(a => a.matchId && String(a.matchId).includes(cat));
            let t1 = 0, t2 = 0, t3 = 0;
            
            azioni.forEach(s => {
                try {
                    const c = JSON.parse(s.contatori || "{}");
                    t1 += parseInt(c["1"]) || 0;
                    t2 += parseInt(c["2"]) || 0;
                    t3 += parseInt(c["3"]) || 0;
                } catch (e) {}
            });

            return {
                punti_totali: (t1 * 1) + (t2 * 2) + (t3 * 3),
                canestri_da_1: t1,
                canestri_da_2: t2,
                canestri_da_3: t3,
                partite_giocate: [...new Set(azioni.map(a => a.matchId))].length
            };
        };

        return {
            giocatore: player.Cognome,
            nome_completo: `${player.Nome} ${player.Cognome}`,
            numero_maglia: player["Numero Maglia"],
            statistiche_U14: calcolaDettagli("U14"),
            statistiche_U15: calcolaDettagli("U15")
        };
    });

    window.setLocalStorage("dati_stats_ia", JSON.stringify(reportPerIA));
    console.log("Dati ottimizzati per Gemini salvati.");
}

function getCategoriaSelezionata() {
    const campionatiConfig = window.MY_TEAM_CAMPIONATO;
    if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
        return campionatiConfig[0];
    }
    const btnText = document.getElementById("btnFilterCatText");
    return btnText ? btnText.textContent.trim() : "Tutti";
}

function getTipoCalcoloSelezionato() {
    const btnText = document.getElementById("btnCalcTypeText");
    return btnText ? btnText.textContent.trim() : "Totale";
}

/**
 * Applica l'animazione di popup al testo e la rotazione alla freccia
 */
function animaBottoneFiltro(btnElement, textElement) {
    if (!btnElement) return;

    // 1. Animazione del testo
    if (textElement) {
        textElement.classList.remove("animate-pop");
        // Forza il reflow per riavviare l'animazione CSS
        void textElement.offsetWidth; 
        textElement.classList.add("animate-pop");
    }

    // 2. Rotazione della freccia
    const arrow = btnElement.querySelector(".btn-arrow");
    if (arrow) {
        arrow.classList.add("rotate");
        setTimeout(() => arrow.classList.remove("rotate"), 200);
    }
}

async function startApp() {
    try {
        const myTeamFullName = document.getElementById("myTeamFullName");
        if (myTeamFullName && window.MY_TEAM_FULLNAME) {
            myTeamFullName.textContent = window.MY_TEAM_FULLNAME;
        }

        // --- 1. GESTIONE BOTTONE/LABEL CAMPIONATO ---
        const containerCat = document.getElementById("campionatoContainer");
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;

        if (containerCat) {
            if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
                const nomeCampionato = campionatiConfig[0];
                containerCat.className = "label-single-camp";
                containerCat.textContent = nomeCampionato;
            } else {
                let opzioniCat = ["Tutti"];
                if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                    opzioniCat = ["Tutti", ...campionatiConfig];
                }

                let idxCat = 0;
                // Aggiunta classe btn-campionato per cambiare colore
                containerCat.innerHTML = `
                    <button id="btnFilterCat" type="button" class="cycle-filter-btn btn-campionato">
                        <span id="btnFilterCatText">${opzioniCat[0]}</span>
                        <span class="btn-arrow">▼</span>
                    </button>
                `;

                const btnFilterCat = document.getElementById("btnFilterCat");
                const btnFilterCatText = document.getElementById("btnFilterCatText");

                btnFilterCat.addEventListener("click", () => {
                    idxCat = (idxCat + 1) % opzioniCat.length;
                    btnFilterCatText.textContent = opzioniCat[idxCat];

                    // Esegue l'animazione
                    animaBottoneFiltro(btnFilterCat, btnFilterCatText);
    
                    applicaFiltriECalcoli();
                });
            }
        }

        // --- 2. GESTIONE BOTTONE PUNTI (TOTALE / MEDIA) ---
        const btnCalcType = document.getElementById("btnCalcType");
        const btnCalcTypeText = document.getElementById("btnCalcTypeText");

        if (btnCalcType && btnCalcTypeText) {
            const opzioniCalc = ["Totale", "Media"];
            let idxCalc = 0;

            btnCalcType.addEventListener("click", () => {
                idxCalc = (idxCalc + 1) % opzioniCalc.length;
                btnCalcTypeText.textContent = opzioniCalc[idxCalc];
                
                // Esegue l'animazione
                animaBottoneFiltro(btnCalcType, btnCalcTypeText);

                applicaFiltriECalcoli();
            });
        }

        // 3. Identificazione utente e device
        await window.registerUserId(); 

        // 4. Caricamento e rendering dati
        await inizializzaDati();

        salvaStatistichePerGemini();
        
    } catch (error) {
        console.error("Errore durante l'avvio:", error);
    }
}

async function OLDstartApp() {
    try {
        // Imposta il nome completo della squadra
        const myTeamFullName = document.getElementById("myTeamFullName");
        if (myTeamFullName && window.MY_TEAM_FULLNAME) {
            myTeamFullName.textContent = window.MY_TEAM_FULLNAME;
        }

        // --- GESTIONE DINAMICA RADIO BUTTON CAMPIONATO ---
        const campionati = window.MY_TEAM_CAMPIONATO;
        
        // Recupera i radio button e il contenitore
        const radioCamp1 = document.querySelector('input[name="catFilter"][value="1"]');
        const radioCamp2 = document.querySelector('input[name="catFilter"][value="2"]');
        const radioTutti = document.querySelector('input[name="catFilter"][value="Tutti"]');
        
        // Usa il contenitore genitore del primo radio button per gestire il gruppo
        const gruppoCampionati = radioCamp1 ? radioCamp1.closest('.filter-group') : null;

        if (Array.isArray(campionati)) {
            if (campionati.length === 1 && gruppoCampionati) {
                // --- CASO: UN SOLO CAMPIONATO ---
                const nomeUnicoCampionato = campionati[0];

                // Nascondi tutti i radio button (e le loro label associate)
                if (radioCamp1) radioCamp1.parentElement.style.display = 'none';
                if (radioCamp2) radioCamp2.parentElement.style.display = 'none';
                if (radioTutti) radioTutti.parentElement.style.display = 'none';

                // Crea e inserisci una span con il nome del campionato
                const etichettaSingola = document.createElement('span');
                etichettaSingola.textContent = ` ${nomeUnicoCampionato}`;
                etichettaSingola.style.marginLeft = '5px'; // Spaziatura dal testo "Campionato:"
                etichettaSingola.style.fontSize = '1.5rem';
                gruppoCampionati.appendChild(etichettaSingola);
                
                // Opzionale: potresti voler chiamare applicaFiltriECalcoli con il valore unico qui, 
                // se necessario per l'inizializzazione corretta dello stato
                // window.applicaFiltriECalcoli(nomeUnicoCampionato);

            } else if (campionati.length >= 2) {
                // --- CASO: DUE O PIU' CAMPIONATI ---
                if (radioCamp1) {
                    const testoCamp1 = campionati[0];
                    radioCamp1.value = testoCamp1; 
                    if (radioCamp1.parentElement) {
                        radioCamp1.parentElement.childNodes[1].textContent = ` ${testoCamp1}`;
                    }
                }

                if (radioCamp2) {
                    const testoCamp2 = campionati[1];
                    radioCamp2.value = testoCamp2; 
                    if (radioCamp2.parentElement) {
                        radioCamp2.parentElement.childNodes[1].textContent = ` ${testoCamp2}`;
                    }
                }

                // --- COLLEGAMENTO EVENTI SUI RADIO BUTTON DEL CAMPIONATO ---
                const radioCampionati = document.querySelectorAll('input[name="catFilter"]');
                radioCampionati.forEach(radio => {
                    radio.removeAttribute('onclick');

                    radio.addEventListener('change', (e) => {
                        const captionCorrente = e.target.parentElement.textContent.trim();
                        
                        if (typeof window.applicaFiltriECalcoli === 'function') {
                            window.applicaFiltriECalcoli(captionCorrente);
                        } else if (typeof applicaFiltriECalcoli === 'function') {
                            applicaFiltriECalcoli(captionCorrente);
                        }
                    });
                });
            }
        }

        // 1. Aspettiamo che l'identificazione utente e device sia completata
        await window.registerUserId(); 

        // 2. Solo ora facciamo partire il caricamento e il calcolo dei dati
        await inizializzaDati();

        salvaStatistichePerGemini();
        
    } catch (error) {
        console.error("Errore durante l'avvio:", error);
    }
}


// Avviamo il tutto
startApp();

