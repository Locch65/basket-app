// --- Helper Animazione Bottone ---
function animaBottoneFiltro(btnElement, textElement) {
    if (!btnElement) return;

    if (textElement) {
        textElement.classList.remove("animate-pop");
        void textElement.offsetWidth; // Force reflow
        textElement.classList.add("animate-pop");
    }

    const arrow = btnElement.querySelector(".btn-arrow");
    if (arrow) {
        arrow.classList.add("rotate");
        setTimeout(() => arrow.classList.remove("rotate"), 200);
    }
}

let chartStatsCampionato = null;
let liveMatchData = null;

window.mostraStatisticheCampionato = function() {
    let modal = document.getElementById('modalStatsCampionato');
    const campionatiConfig = window.MY_TEAM_CAMPIONATO;

    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modalStatsCampionato';
        modal.className = 'popup';
        modal.style.display = 'none';

        // Costruzione dinamica dell'elemento filtro Campionato
        let htmlFiltroCampionato = "";
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlFiltroCampionato = `<span id="statCampText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlFiltroCampionato = `
                <button id="btnStatCamp" type="button" class="cycle-filter-btn">
                    <span id="statCampText">Tutti</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }

        modal.innerHTML = `
            <style>
                /* Layout Filtri e Switch */
                .modal-filters-wrapper {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 12px;
                    margin-bottom: 15px;
                    width: 100%;
                }

                .filter-group-stat {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    gap: 8px;
                    white-space: nowrap;
                }

                .switch-container {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 10px;
                    background: rgba(0,0,0,0.2);
                    padding: 6px 12px;
                    border-radius: 12px;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                .switch {
                    position: relative;
                    display: inline-block;
                    width: 44px;
                    height: 22px;
                }
                .switch input { opacity: 0; width: 0; height: 0; }
                .slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background-color: #ccc;
                    transition: .3s;
                    border-radius: 22px;
                }
                .slider:before {
                    position: absolute;
                    content: "";
                    height: 16px;
                    width: 16px;
                    left: 3px;
                    bottom: 3px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                }
                input:checked + .slider { background-color: #dc3545; }
                input:checked + .slider:before { transform: translateX(22px); }
                .label-toggle { font-size: 0.85rem; font-weight: bold; color: #ffffff; white-space: nowrap; }

                /* Stile Label Singola */
                .label-single-camp {
                    font-size: 1.3rem;
                    font-weight: bold;
                    color: #ffffff;
                    padding: 0.4rem 0.6rem;
                }

                /* Bottone Ciclico Campionato */
                .cycle-filter-btn {
                    display: inline-flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 0.6rem;
                    background: #4a5568;
                    color: white;
                    border: 1px solid #2d3748;
                    padding: 0.4rem 0.8rem;
                    border-radius: 6px;
                    font-size: 1.2rem;
                    font-weight: bold;
                    cursor: pointer;
                    transition: background-color 0.2s ease, transform 0.1s ease;
                }

                .cycle-filter-btn:hover { background: #2d3748; }
                .cycle-filter-btn:active { transform: scale(0.95); }

                .cycle-filter-btn .btn-arrow {
                    font-size: 0.8rem;
                    margin-left: 0.2rem;
                    display: inline-block;
                    transition: transform 0.2s ease;
                }

                .cycle-filter-btn .btn-arrow.rotate { transform: rotate(180deg); }

                /* Animazione cambio testo */
                .animate-pop { animation: popText 0.25s ease-out; }

                @keyframes popText {
                    0% { opacity: 0.3; transform: scale(0.85); }
                    50% { opacity: 1; transform: scale(1.08); }
                    100% { opacity: 1; transform: scale(1); }
                }

                /* 🌟 ADATTAMENTO SPECIFICO LANDSCAPE: Filtro e Switch affiancati sulla stessa riga */
                @media screen and (orientation: landscape) and (max-height: 600px) {
                    .modal-filters-wrapper {
                        flex-direction: row !important;
                        justify-content: center;
                        gap: 20px;
                        margin-bottom: 10px;
                    }

                    .switch-container {
                        padding: 4px 10px;
                    }

                    #modalStatsCampionato .popup-content {
                        max-height: 95vh;
                        padding: 12px;
                    }

                    #modalStatsCampionato canvas {
                        max-height: 180px !important;
                    }
                }
            </style>

            <div class="popup-content" style="max-width: 95%; width: 600px; max-height: 90vh; overflow-y: auto; padding: 20px;">
                <h2 style="margin-bottom:15px; color: white; text-align:center;">Statistiche Campionato</h2>
                
                <!-- Contenitore unico per la gestione responsive -->
                <div class="modal-filters-wrapper">
                    <div class="filter-group-stat">
                        <strong>Campionato:</strong>
                        ${htmlFiltroCampionato}
                    </div>

                    <div class="switch-container">
                        <span class="label-toggle">Punti Gara</span>
                        <label class="switch">
                            <input type="checkbox" id="toggleTipoGrafico">
                            <span class="slider"></span>
                        </label>
                        <span class="label-toggle">Progressivo</span>
                    </div>
                </div>

                <div id="containerTabellaStats"></div>

                <div style="height: 280px; margin-top: 10px;">
                    <canvas id="canvasStatsCampionato"></canvas>
                </div>

                <button class="close-btn" style="margin-top:20px; width:100%; padding:12px; background:#444; color:#fff; border:none; border-radius:8px; cursor:pointer; font-weight:bold;">Chiudi</button>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('.close-btn').onclick = () => modal.style.display = 'none';

        // Event listener per lo switch Progressivo / Punti Gara
        modal.querySelector('#toggleTipoGrafico').addEventListener('change', () => {
            const filtroCat = document.getElementById('statCampText').textContent.trim();
            elaboraDatiStats(filtroCat);
        });

        // Event listener per il Bottone Ciclico
        const btnStatCamp = document.getElementById('btnStatCamp');
        const statCampText = document.getElementById('statCampText');

        if (btnStatCamp && statCampText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = 0;

            btnStatCamp.addEventListener('click', () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                statCampText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnStatCamp, statCampText);
                elaboraDatiStats(opzioniCat[idxCat]);
            });
        }
    }

    modal.style.display = 'flex';
    
    // Inizializza la categoria iniziale salvata nel testo della label/bottone
    const filtroIniziale = document.getElementById('statCampText') ? document.getElementById('statCampText').textContent.trim() : "Tutti";
    elaboraDatiStats(filtroIniziale);
};

window.OLD2_mostraStatisticheCampionato = function() {
    let modal = document.getElementById('modalStatsCampionato');
    const campionatiConfig = window.MY_TEAM_CAMPIONATO;

    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modalStatsCampionato';
        modal.className = 'popup';
        modal.style.display = 'none';

        // Costruzione dinamica dell'elemento filtro Campionato
        let htmlFiltroCampionato = "";
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlFiltroCampionato = `<span id="statCampText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlFiltroCampionato = `
                <button id="btnStatCamp" type="button" class="cycle-filter-btn">
                    <span id="statCampText">Tutti</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }

        modal.innerHTML = `
            <style>
                /* Stili per lo Switch */
                .switch-container {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 12px;
                    background: rgba(0,0,0,0.05);
                    padding: 12px;
                    border-radius: 12px;
                    margin-bottom: 20px;
                }
                .switch {
                    position: relative;
                    display: inline-block;
                    width: 46px;
                    height: 24px;
                }
                .switch input { opacity: 0; width: 0; height: 0; }
                .slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background-color: #ccc;
                    transition: .3s;
                    border-radius: 24px;
                }
                .slider:before {
                    position: absolute;
                    content: "";
                    height: 18px;
                    width: 18px;
                    left: 3px;
                    bottom: 3px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                }
                input:checked + .slider { background-color: #dc3545; }
                input:checked + .slider:before { transform: translateX(22px); }
                .label-toggle { font-size: 0.85rem; font-weight: bold; color: #ffffff; }

                /* Stile Label Singola */
                .label-single-camp {
                    font-size: 1.3rem;
                    font-weight: bold;
                    color: #ffffff;
                    padding: 0.4rem 0.6rem;
                }

                /* Bottone Ciclico Campionato (Grigio Scuro) */
                .cycle-filter-btn {
                    display: inline-flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 0.6rem;
                    background: #4a5568;
                    color: white;
                    border: 1px solid #2d3748;
                    padding: 0.4rem 0.8rem;
                    border-radius: 6px;
                    font-size: 1.2rem;
                    font-weight: bold;
                    cursor: pointer;
                    transition: background-color 0.2s ease, transform 0.1s ease;
                }

                .cycle-filter-btn:hover { background: #2d3748; }
                .cycle-filter-btn:active { transform: scale(0.95); }

                .cycle-filter-btn .btn-arrow {
                    font-size: 0.8rem;
                    margin-left: 0.2rem;
                    display: inline-block;
                    transition: transform 0.2s ease;
                }

                .cycle-filter-btn .btn-arrow.rotate { transform: rotate(180deg); }

                /* Animazione di cambio testo */
                .animate-pop { animation: popText 0.25s ease-out; }

                @keyframes popText {
                    0% { opacity: 0.3; transform: scale(0.85); }
                    50% { opacity: 1; transform: scale(1.08); }
                    100% { opacity: 1; transform: scale(1); }
                }
            </style>

            <div class="popup-content" style="max-width: 95%; width: 600px; max-height: 90vh; overflow-y: auto; padding: 20px;">
                <h2 style="margin-bottom:15px; color: white; text-align:center;">Statistiche Campionato</h2>
                
                <div class="filter-group" style="margin-bottom: 15px; display: flex; justify-content: center; align-items: center; color: white; gap: 10px;">
                    <strong>Campionato:</strong>
                    ${htmlFiltroCampionato}
                </div>

                <div class="switch-container">
                    <span class="label-toggle">Punti Gara</span>
                    <label class="switch">
                        <input type="checkbox" id="toggleTipoGrafico">
                        <span class="slider"></span>
                    </label>
                    <span class="label-toggle">Progressivo</span>
                </div>

                <div id="containerTabellaStats"></div>

                <div style="height: 280px; margin-top: 10px;">
                    <canvas id="canvasStatsCampionato"></canvas>
                </div>

                <button class="close-btn" style="margin-top:20px; width:100%; padding:12px; background:#444; color:#fff; border:none; border-radius:8px; cursor:pointer; font-weight:bold;">Chiudi</button>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('.close-btn').onclick = () => modal.style.display = 'none';

        // Event listener per lo switch Progressivo / Punti Gara
        modal.querySelector('#toggleTipoGrafico').addEventListener('change', () => {
            const filtroCat = document.getElementById('statCampText').textContent.trim();
            elaboraDatiStats(filtroCat);
        });

        // Event listener per il Bottone Ciclico
        const btnStatCamp = document.getElementById('btnStatCamp');
        const statCampText = document.getElementById('statCampText');

        if (btnStatCamp && statCampText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = 0;

            btnStatCamp.addEventListener('click', () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                statCampText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnStatCamp, statCampText);
                elaboraDatiStats(opzioniCat[idxCat]);
            });
        }
    }

    modal.style.display = 'flex';
    
    // Inizializza la categoria iniziale salvata nel testo della label/bottone
    const filtroIniziale = document.getElementById('statCampText') ? document.getElementById('statCampText').textContent.trim() : "Tutti";
    elaboraDatiStats(filtroIniziale);
};

window.OLDmostraStatisticheCampionato = function() {
    let modal = document.getElementById('modalStatsCampionato');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modalStatsCampionato';
        modal.className = 'popup';
        modal.style.display = 'none';
        modal.innerHTML = `
            <style>
                /* Stili per lo Switch */
                .switch-container {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 12px;
                    background: rgba(0,0,0,0.05);
                    padding: 12px;
                    border-radius: 12px;
                    margin-bottom: 20px;
                }
                .switch {
                    position: relative;
                    display: inline-block;
                    width: 46px;
                    height: 24px;
                }
                .switch input { opacity: 0; width: 0; height: 0; }
                .slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background-color: #ccc;
                    transition: .3s;
                    border-radius: 24px;
                }
                .slider:before {
                    position: absolute;
                    content: "";
                    height: 18px;
                    width: 18px;
                    left: 3px;
                    bottom: 3px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                }
                input:checked + .slider { background-color: #dc3545; }
                input:checked + .slider:before { transform: translateX(22px); }
                .label-toggle { font-size: 0.85rem; font-weight: bold; color: #ffffff; }
            </style>

            <div class="popup-content" style="max-width: 95%; width: 600px; max-height: 90vh; overflow-y: auto; padding: 20px;">
                <h2 style="margin-bottom:15px; color: white; text-align:center;">Statistiche Campionato</h2>
                
                <div class="filter-group" style="margin-bottom: 15px; display: flex; justify-content: center; color: white; gap: 15px;">
                    <label><input type="radio" name="statCamp" value="U14"> U14</label>
                    <label><input type="radio" name="statCamp" value="U15"> U15</label>
                    <label><input type="radio" name="statCamp" value="Tutti" checked> Tutti</label>
                </div>

                <div class="switch-container">
                    <span class="label-toggle">Punti Gara</span>
                    <label class="switch">
                        <input type="checkbox" id="toggleTipoGrafico">
                        <span class="slider"></span>
                    </label>
                    <span class="label-toggle">Progressivo</span>
                </div>

                <div id="containerTabellaStats"></div>

                <div style="height: 280px; margin-top: 10px;">
                    <canvas id="canvasStatsCampionato"></canvas>
                </div>

                <button class="close-btn" style="margin-top:20px; width:100%; padding:12px; background:#444; color:#fff; border:none; border-radius:8px; cursor:pointer; font-weight:bold;">Chiudi</button>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('.close-btn').onclick = () => modal.style.display = 'none';
        
        modal.querySelectorAll('input[name="statCamp"], #toggleTipoGrafico').forEach(el => {
            el.addEventListener('change', () => {
                const filtroCat = modal.querySelector('input[name="statCamp"]:checked').value;
                elaboraDatiStats(filtroCat);
            });
        });
    }

    modal.style.display = 'flex';
    elaboraDatiStats("Tutti");
}

function elaboraDatiStats(filtro) {
    const cacheDati = window.getLocalStorage("cache_partite");
    if (!cacheDati || cacheDati === "undefined") return;
    const partite = JSON.parse(cacheDati);

    let filtrate = partite.filter(p => 
        !p.matchId.toLowerCase().includes("test") &&
        p.punteggioA !== null && 
        p.punteggioB !== null && 
        String(p.statoPartita).toLowerCase().includes("terminata") && 
        !isInTheFuture(p.data)
    );

    if (filtro !== "Tutti") {
        filtrate = filtrate.filter(p => String(p.matchId).includes(filtro));
    }

    filtrate.sort((a, b) => 
        parseItalianDate(String(a.data).replace("*", ""), a.orario) - 
        parseItalianDate(String(b.data).replace("*", ""), b.orario)
    );

    let stats = { vinte: 0, perse: 0, fatti: 0, subiti: 0 };
    const datiGrafico = [];
    let accumuloNoi = 0;
    let accumuloLoro = 0;

    filtrate.forEach(p => {
        const pA = parseInt(p.punteggioA) || 0;
        const pB = parseInt(p.punteggioB) || 0;
        const isMyTeam = (window.isMyTeam(p.squadraA) || p.casaTrasferta === "Casa");
        
        const puntiNoi = isMyTeam ? pA : pB;
        const puntiLoro = isMyTeam ? pB : pA;

        if (puntiNoi > puntiLoro) stats.vinte++;
        else if (puntiNoi < puntiLoro) stats.perse++;
        
        stats.fatti += puntiNoi;
        stats.subiti += puntiLoro;
        accumuloNoi += puntiNoi;
        accumuloLoro += puntiLoro;
        
        datiGrafico.push({ 
            data: String(p.data).replace("*", ""), 
            puntiGaraNoi: puntiNoi, 
            puntiGaraLoro: puntiLoro,
            progNoi: accumuloNoi,
            progLoro: accumuloLoro
        });
    });

    const numPartite = filtrate.length || 1;
    const mediaFatti = (stats.fatti / numPartite).toFixed(1);
    const mediaSubiti = (stats.subiti / numPartite).toFixed(1);

    const containerTab = document.getElementById("containerTabellaStats");
    containerTab.innerHTML = `
        <table style="width:100%; border-collapse: collapse; text-align: center; font-size: 1.1rem; margin-bottom: 20px;">
            <tr style="background: #27ae60; color: white;">
                <th style="padding:10px; border:1px solid #ddd;">Vinte</th>
                <th style="padding:10px; border:1px solid #ddd;">Perse</th>
                <th style="padding:10px; border:1px solid #ddd;">Punti Fatti</th>
                <th style="padding:10px; border:1px solid #ddd;">Punti Subiti</th>
            </tr>
            <tr>
                <td style="padding:12px; border:1px solid #ddd; color:green; font-weight:bold;">${stats.vinte}</td>
                <td style="padding:12px; border:1px solid #ddd; color:red; font-weight:bold;">${stats.perse}</td>
                <td style="padding:12px; border:1px solid #ddd; color: white; font-weight:bold;">${stats.fatti}</td>
                <td style="padding:12px; border:1px solid #ddd; color: white; font-weight:bold;">${stats.subiti}</td>
            </tr>
        </table>
    `;

    const isProgressivo = document.getElementById('toggleTipoGrafico').checked;
    // Passiamo anche le medie alla funzione del grafico
    renderGraficoProgressione(datiGrafico, isProgressivo, mediaFatti, mediaSubiti);
}

function renderGraficoProgressione(dati, isProgressivo, mediaNoi, mediaLoro) {
    const ctx = document.getElementById('canvasStatsCampionato').getContext('2d');
    if (chartStatsCampionato) chartStatsCampionato.destroy();

    // Etichette aggiornate
    const labelNoi = isProgressivo ? 'Progressivo ' + window.MY_TEAM : 'Punti ' + window.MY_TEAM;
    const labelLoro = isProgressivo ? 'Progressivo Avversari' : 'Punti Avversari';
    
    const dataNoi = dati.map(d => isProgressivo ? d.progNoi : d.puntiGaraNoi);
    const dataLoro = dati.map(d => isProgressivo ? d.progLoro : d.puntiGaraLoro);

    // Costruiamo i dataset base
    const datasets = [
        {
            label: labelNoi,
            data: dataNoi,
            borderColor: '#dc3545', // Rosso
            backgroundColor: 'rgba(220, 53, 69, 0.1)',
            fill: isProgressivo,
            tension: 0.3,
            pointRadius: 2,
            pointHoverRadius: 4
        },
        {
            label: labelLoro,
            data: dataLoro,
            borderColor: '#0056b3', // Blu
            backgroundColor: 'rgba(0, 86, 179, 0.1)',
            fill: isProgressivo,
            tension: 0.3,
            pointRadius: 2,
            pointHoverRadius: 4
        }
    ];

    // Aggiungiamo le linee medie solo se NON siamo in modalità progressiva
    if (!isProgressivo && mediaNoi && mediaLoro) {
        datasets.push({
//                label: 'Media Poli_smile',
                label: 'Media ' + window.MY_TEAM,
                data: Array(dati.length).fill(mediaNoi),
                borderColor: '#dc3545',
                borderDash: [5, 5],
                borderWidth: 2,
                fill: false,
                pointRadius: 0,
                pointStyle: 'line' // <--- Cambia l'icona in legenda in una linea
            });
            datasets.push({
                label: 'Media Avversari',
                data: Array(dati.length).fill(mediaLoro),
                borderColor: '#0056b3',
                borderDash: [5, 5],
                borderWidth: 2,
                fill: false,
                pointRadius: 0,
                pointStyle: 'line' // <--- Cambia l'icona in legenda in una linea
            });
        }

    chartStatsCampionato = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dati.map(d => d.data),
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            scales: {
                y: { 
                    beginAtZero: true
                }
            },
            plugins: {
                legend: { 
                    position: 'bottom',
                    labels: {
                        // Filtriamo la legenda per non mostrare doppioni se preferisci, 
                        // o lasciamo tutto per chiarezza
                        usePointStyle: true
                    }
                }
            }
        }
    });
}

async function verificaNovitaAllenamenti() {
    const badge = document.getElementById("badge-allenamenti");
    
    // Recuperiamo la stringa salvata nel localStorage
    const cacheLocale = window.getLocalStorage("cache_allenamenti") || "";
    
    try {
        // Leggiamo l'array da Firebase
        const dataFirebase = await readFromFirebaseHistory("allenamenti/");
        
        if (dataFirebase) {
            // Trasformiamo l'array di Firebase in stringa JSON per il confronto
            const stringaFirebase = JSON.stringify(dataFirebase);
            
            // Confronto tra stringhe
            if (stringaFirebase.trim() !== cacheLocale.trim()) {
                badge.style.display = "block";
            } else {
                badge.style.display = "none";
            }
        }
    } catch (e) { 
        console.error("Errore verifica novità:", e); 
    }
}

async function verificaNovitaFIP() {
// Funzione per verificare se ci sono nuovi dati FIP rispetto alla cache locale
    const badge = document.getElementById("badge-fip");
    const cacheLocale = window.getLocalStorage('FIP_DATA_CACHE');
    
    try {
        // Leggiamo i dati da Firebase come facciamo nella pagina classifica
        const dataFirebase = await readFromFirebaseHistory("classificheFIP/");
        
        if (dataFirebase) {
            const dataFirebaseStr = JSON.stringify(dataFirebase);
            
            // Se la cache locale non esiste o è diversa dai dati Firebase, mostra il badge
            if (!cacheLocale || cacheLocale.trim() !== dataFirebaseStr.trim()) {
                badge.style.display = "block";
            }
        }
    } catch (e) {
        console.error("Errore verifica novità FIP:", e);
    }
}

function generaCalendario(rows) {
    if (!rows || rows.length === 0) return "";
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    const mesi = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    const giorniSettimana = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
    const parseData = (str) => { const [g, m, a] = str.split('/').map(Number); return new Date(a, m - 1, g); };
    const getWeekNumber = (d) => {
        const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
        date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
        const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
        return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
    };
    let html = "";
    let ultimaSettimanaIdentificata = null;
    rows.forEach((row, index) => {
        const dataEvento = parseData(row[0]);
        const descrizione = row[1];
        const numSettimana = getWeekNumber(dataEvento);
        if (numSettimana !== ultimaSettimanaIdentificata) {
            const righeSettimana = rows.filter(r => getWeekNumber(parseData(r[0])) === numSettimana);
            const dInizio = parseData(righeSettimana[0][0]);
            const dFine = parseData(righeSettimana[righeSettimana.length - 1][0]);
            let titoloSettimana = (dInizio.getMonth() !== dFine.getMonth()) ? 
                `${dInizio.getDate()} ${mesi[dInizio.getMonth()]} - ${dFine.getDate()} ${mesi[dFine.getMonth()]} ${dFine.getFullYear()}` :
                `${dInizio.getDate()}-${dFine.getDate()} ${mesi[dInizio.getMonth()]} ${dInizio.getFullYear()}`;
            if (ultimaSettimanaIdentificata !== null) html += "<br><br>";
            html += `<u><b>SETTIMANA ${titoloSettimana}</b></u><br><br>`;
            ultimaSettimanaIdentificata = numSettimana;
        }
        const giornoNome = giorniSettimana[dataEvento.getDay()];
        const giornoNumero = dataEvento.getDate();
        let contenutoRiga = `<b>${giornoNome} ${giornoNumero}</b> - ${descrizione}`;
        if (dataEvento.getTime() === oggi.getTime()) contenutoRiga = `<mark>${contenutoRiga}</mark>`;
        else if (dataEvento < oggi) contenutoRiga = `<s>${contenutoRiga}</s>`;
        html += contenutoRiga;
        if (index < rows.length - 1 && getWeekNumber(parseData(rows[index+1][0])) === numSettimana) html += "<br><br>";
    });
    return html;
}

async function ShowAllenamenti() {
    const container = document.getElementById('training-content');
    const popup = document.getElementById('trainingPopup');
    const refreshBtn = document.getElementById('training-icon');
    
    // Mostriamo il popup
    popup.classList.remove('hidden'); popup.style.display = 'flex';
    container.innerHTML = "Caricamento in corso...";

    // --- GESTIONE BOTTONE REFRESH (SOLO ADMIN) ---
    if (window.getLocalStorage("isAdmin") === "true") {
        refreshBtn.onclick = async () => {
            if (refreshBtn) refreshBtn.classList.add('spinning');
            try {
                // 1. Fetch da Google Sheets
                const params = new URLSearchParams({
                    appVersion: window.APP_VERSION,
                    teamId: window.getTeamId(),
                    sheet: "Allenamenti", 
                    userId: userId, 
                    action: "GetAllenamenti", 
                    details: JSON.stringify(getDeviceData) 
                });
                fetch(`${window.getBackendUrl()}?${params.toString()}`)
                    .then(res => res.json())
                    .then(resObj => {
                        if (resObj.status === "success" && Array.isArray(resObj.data) && resObj.data.length > 0) {
                            window.setLocalStorage("cache_allenamenti", JSON.stringify(resObj.data));
                            window.saveToFirebaseHistory('allenamenti/', resObj.data);
                            container.innerHTML = generaCalendario(resObj.data);
                        }
                        else {
                            container.innerHTML = "<i>Nessun allenamento programmato.</i>";
                        }
                    })
                    .finally(() => { if (refreshBtn) refreshBtn.classList.remove('spinning'); });



            } catch (e) {
                alert("Errore aggiornamento: " + e.message);
            } finally {
                //  if (refreshBtn) refreshBtn.classList.remove('spinning'); 
            }
        };
    }

    // --- CARICAMENTO DATI (PRIORITÀ FIREBASE) ---
    try {
        const dataFB = await readFromFirebaseHistory("allenamenti/");
        if (dataFB) {
            container.innerHTML = generaCalendario(dataFB);
            // Aggiorniamo la cache locale per consultazione offline
            window.setLocalStorage("cache_allenamenti", JSON.stringify(dataFB));
            return;
        }
    } catch (e) {
        console.warn("Impossibile leggere da Firebase, provo cache locale...");
    }

    // Fallback se Firebase non risponde o è vuoto
    const cache = window.getLocalStorage("cache_allenamenti");
    if (cache) {
        const arrayAllenamenti = JSON.parse(cache);
        container.innerHTML = generaCalendario(arrayAllenamenti);
    } else {
        container.innerHTML = "Dati non disponibili. Controlla la connessione.";
    }
}
window.ShowAllenamenti = ShowAllenamenti;

window.closePopupTraining = function() { 
    document.getElementById('trainingPopup').style.display = 'none'; 
}

window.GotoLive = function() {
    if (liveMatchData) {
        const p = liveMatchData;
        window.setLocalStorage("matchId", p.matchId || "");
        window.setLocalStorage("teamA", p.squadraA || "");
        window.setLocalStorage("teamB", p.squadraB || "");
        window.setLocalStorage("puntiSquadraA", p.punteggioA || 0);
        window.setLocalStorage("puntiSquadraB", p.punteggioB || 0);
        window.setLocalStorage("convocazioni", p.convocazioni || "");
        window.setLocalStorage("videoURL", p.videoURL || "");
        window.setLocalStorage("videoId", window.extractVideoId(p.videoURL));
        window.setLocalStorage("matchStartTime", window.extractYoutubeTime(p.videoURL));
        window.setLocalStorage("oraInizioDiretta", p.oraInizioDiretta || "");
        window.setLocalStorage("isLive", p.isLive || false);
        window.setLocalStorage("statoPartita", p.statoPartita || "");
        window.location.href = "direttavideo.html?matchId=" + encodeURIComponent(p.matchId);
    }
}

function checkLiveStatus() {
    if (!window.userIsLogged) return;
    
    const btnLive = document.getElementById("btn-live");
    const txtLive = document.getElementById("live-text");
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    const params = new URLSearchParams({ 
        appVersion: window.APP_VERSION,
        teamId: window.getTeamId(),
        sheet: "Partite", 
        userId: userId, 
        action: "Get Partite Live", 
        details: JSON.stringify(getDeviceData) 
    });
    
    fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            // 1. Controllo robusto: se data è null/undefined o data.data è null/undefined, usa array vuoto
            let partite = [];
            if (data) {
                partite = Array.isArray(data) ? data : (data.data || []);
            }

            window.setLocalStorage("cache_partite", JSON.stringify(partite));

            // 2. Il .find() ora è sicuro perché 'partite' è garantito essere un array (anche se vuoto)
            const match = partite.find(p => {
                if (!p) return false; // Sicurezza ulteriore per elementi nulli nell'array
                const isMatchLive = (p.isLive === "true" || p.isLive === true);
                if (isAdmin) return isMatchLive;
                
                const mId = String(p.matchId || "");
                return isMatchLive && (mId.includes("U14") || mId.includes("U15")) && !mId.toLowerCase().includes("test");
            });

            if (match) {
                liveMatchData = match;
                const pA = (match.punteggioA !== undefined && match.punteggioA !== "") ? match.punteggioA : 0;
                const pB = (match.punteggioB !== undefined && match.punteggioB !== "") ? match.punteggioB : 0;
                txtLive.innerHTML = `${match.squadraA}<br>vs<br>${match.squadraB}<br><span style="font-size: 2rem; color: #ff0000; display: block; margin-top: 5px;">${pA} - ${pB}</span>`;
                btnLive.classList.replace("live-off", "live-active");
            } else {
                liveMatchData = null; 
                txtLive.innerHTML = "Live";
                btnLive.classList.replace("live-active", "live-off");
            }
        })
        .catch(err => {
            console.error("Errore nel fetch partite live:", err);
            // In caso di errore di rete, resettiamo lo stato del bottone
            if (btnLive) btnLive.classList.replace("live-active", "live-off");
            if (txtLive) txtLive.innerHTML = "Live";
        });

    window.aggiornaDatiRosterEStats().then(dati => {
        if (isAdmin && dati && dati.roster) {
            const datiString = JSON.stringify(dati.roster);
            if (datiString !== window.getLocalStorage("last_roster_firebase_sync")) {
                saveToFirebaseRoster('roster/', dati.roster);
                window.setLocalStorage("last_roster_firebase_sync", datiString);
            }
        }
    });
}

function mostraPopup() { document.getElementById('customPopup').style.display = 'flex'; }
function chiudiPopup() { document.getElementById('customPopup').style.display = 'none'; }


// --- GESTIONE TEMA E SETTINGS ---------------------------------------------------------
// Stato locale del tema nel popup
let tempTheme = {
    "--primary": "",
    "--bg-color": "",
    "--card-color": "",
    "--text-color": ""
};

// Definiamo i colori di default (Originali Poli_smile)
const defaults = {
    "--primary": "#27ae60",
    "--bg-color": "#1a1a1a",
    "--card-color": "#242424",
    "--text-color": "#ffffff"
};

const presets = {
    myTeam: { 
        "--bg-color": "#121212",    // Nero opaco
        "--card-color": "#d92517",  // Rosso molto scuro
        "--primary": "#f5a623",     // Arancione/Oro logo
        "--text-color": "#f0f0f0"   // Bianco sorriso
    },
    default: { "--bg-color": "#1a1a1a", "--card-color": "#242424", "--primary": "#27ae60", "--text-color": "#ffffff" },
    foresta: { "--bg-color": "#0b1a0e", "--card-color": "#162d1b", "--primary": "#7cfc00", "--text-color": "#e0ffe0" },
    deserto: { "--bg-color": "#2d1b0d", "--card-color": "#4a321f", "--primary": "#ed9121", "--text-color": "#fff3e0" },
    oceano: { "--bg-color": "#001219", "--card-color": "#005f73", "--primary": "#9ad1d4", "--text-color": "#e9ecef" },
    vintage: { "--bg-color": "#2b2d42", "--card-color": "#8d99ae", "--primary": "#ef233c", "--text-color": "#edf2f4" },
    bosco: { "--bg-color": "#1b1b16", "--card-color": "#33332d", "--primary": "#d4a373", "--text-color": "#faedcd" },
    cyberpunk: { "--bg-color": "#0d0221", "--card-color": "#240046", "--primary": "#ff00ff", "--text-color": "#00f5d4" },
    artica: { "--bg-color": "#0a0f14", "--card-color": "#16212a", "--primary": "#00d4ff", "--text-color": "#d1e9ff" },
    eclissi: { "--bg-color": "#121212", "--card-color": "#1e1e1e", "--primary": "#ff4d00", "--text-color": "#e0e0e0" },
    lavanda: { "--bg-color": "#1a1625", "--card-color": "#2d263f", "--primary": "#bd93f9", "--text-color": "#f8f8f2" },
    terra: { "--bg-color": "#1c1917", "--card-color": "#292524", "--primary": "#a8a29e", "--text-color": "#f5f5f4" },
    tramonto: { "--bg-color": "#1a0f1a", "--card-color": "#301934", "--primary": "#ff9e00", "--text-color": "#ffd1dc" },
    matrix: { "--bg-color": "#000000", "--card-color": "#0d0d0d", "--primary": "#00ff41", "--text-color": "#d2ffd2" },
    vino: { "--bg-color": "#1a0505", "--card-color": "#2d0a0a", "--primary": "#9b2226", "--text-color": "#ffdfdf" },
};

document.querySelectorAll('.hsv-slider').forEach(slider => {
    slider.addEventListener('input', () => {
        window.updateCustomPicker();
    });
});

document.querySelectorAll('#group-rgb input').forEach(slider => {
    slider.addEventListener('input', () => {
        window.updateFromRGB();
    });
});

window.toggleColorMode = function() {
    const isRGB = document.getElementById('color-mode-toggle').checked;
    const groupHsl = document.getElementById('group-hsl');
    const groupRgb = document.getElementById('group-rgb');
    
    groupHsl.classList.toggle('hidden', isRGB);
    groupRgb.classList.toggle('hidden', !isRGB);

    // Recupera il colore corrente dell'elemento selezionato (es. --primary)
    const property = document.getElementById('element-selector').value;
    const currentColor = tempTheme[property];

    // Ricalcola e sposta gli slider della modalità appena attivata
    window.updateSliders(currentColor);
};

// 3. Funzione per aggiornare partendo da RGB
window.updateFromRGB = function() {
    const r = document.getElementById('range-r').value;
    const g = document.getElementById('range-g').value;
    const b = document.getElementById('range-b').value;
    
    const hex = "#" + [r, g, b].map(x => {
        const h = parseInt(x).toString(16);
        return h.length === 1 ? "0" + h : h;
    }).join("");

    applyColorToPreview(hex);
};

window.updateSliders = function(color) {
    const hex = forceHexColor(color);
    
    // --- PARTE HSL ---
    const hsv = hexToHSV(hex);
    document.getElementById('range-h').value = hsv.h;
    document.getElementById('range-s').value = hsv.s;
    document.getElementById('range-v').value = hsv.v;
    
    // Aggiorna etichette HSL
    document.getElementById('val-h').innerText = hsv.h;
    document.getElementById('val-s').innerText = hsv.s;
    document.getElementById('val-v').innerText = hsv.v;

    // --- PARTE RGB ---
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    document.getElementById('range-r').value = r;
    document.getElementById('range-g').value = g;
    document.getElementById('range-b').value = b;
    
    // Aggiorna etichette RGB
    document.getElementById('val-r').innerText = r;
    document.getElementById('val-g').innerText = g;
    document.getElementById('val-b').innerText = b;

    // Aggiorna il testo HEX e l'anteprima visiva
    document.getElementById('hexLabel').innerText = hex.toUpperCase();
    applyColorToPreview(hex);
};

// 5. Funzione helper per applicare il colore (unifica la logica)
function applyColorToPreview(hex) {
    const property = document.getElementById('element-selector').value;
    tempTheme[property] = hex;

    // Aggiorna etichette numeriche
    const hsv = hexToHSV(hex);
    document.getElementById('val-h').innerText = hsv.h;
    document.getElementById('val-s').innerText = hsv.s;
    document.getElementById('val-v').innerText = hsv.v;
    
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    document.getElementById('val-r').innerText = r;
    document.getElementById('val-g').innerText = g;
    document.getElementById('val-b').innerText = b;

    document.getElementById('hexLabel').innerText = hex.toUpperCase();

    // Aggiorna anteprima visiva
    const previewCont = document.getElementById('preview-container');
    const previewBtn = document.getElementById('btn-preview');
    if (previewCont && previewBtn) {
        previewCont.style.backgroundColor = tempTheme["--bg-color"];
        previewBtn.style.backgroundColor = tempTheme["--card-color"];
        const previewText = previewBtn.querySelector('span');
        if (previewText) previewText.style.color = tempTheme["--text-color"];
        const previewIcon = previewBtn.querySelector('i');
        if (previewIcon) previewIcon.style.color = tempTheme["--primary"];
    }
}

// Funzione per convertire QUALSIASI colore (rgb o hex sporco) in HEX 7 caratteri
function forceHexColor(colorStr) {
    if (!colorStr) return "#27ae60";
    
    // Se è già HEX, puliscilo e assicurati che sia lungo 7 (es. #ffffff)
    if (colorStr.startsWith('#')) {
        return colorStr.trim().toLowerCase();
    }
    
    // Se è RGB, convertilo
    const rgb = colorStr.match(/\d+/g);
    if (rgb && rgb.length >= 3) {
        return "#" + rgb.slice(0, 3).map(x => {
            const hex = parseInt(x).toString(16);
            return hex.length === 1 ? "0" + hex : hex;
        }).join("");
    }
    return "#27ae60";
}

// Funzione per convertire QUALSIASI colore (rgb o hex sporco) in HEX 7 caratteri
function hsvToHex(h, s, v) {
    s /= 100; v /= 100;
    let f = (n, k = (n + h / 60) % 6) => v - v * s * Math.max(Math.min(k, 4 - k, 1), 0);
    const toHex = x => Math.round(x * 255).toString(16).padStart(2, '0');
    return `#${toHex(f(5))}${toHex(f(3))}${toHex(f(1))}`.toLowerCase();
}

function hexToHSV(hex) {
    // Rimuove il cancelletto e converte in RGB (0-1)
    let r = parseInt(hex.slice(1, 3), 16) / 255;
    let g = parseInt(hex.slice(3, 5), 16) / 255;
    let b = parseInt(hex.slice(5, 7), 16) / 255;

    let max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, v = max;
    let d = max - min;
    s = max === 0 ? 0 : d / max;

    if (max === min) {
        h = 0; // acromatico
    } else {
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }

    return {
        h: Math.round(h * 360), // Tonalità (0-360)
        s: Math.round(s * 100), // Saturazione (0-100)
        v: Math.round(v * 100)  // Valore/Luminosità (0-100)
    };
}

window.apriPopupSettings = function() {
    const root = document.documentElement;
    const style = getComputedStyle(root);
    
    // Inizializza tempTheme con i valori attuali
    Object.keys(tempTheme).forEach(prop => {
        tempTheme[prop] = forceHexColor(style.getPropertyValue(prop).trim());
    });

    document.getElementById('settingsPopup').style.display = 'flex';
    document.getElementById('settingsPopup').classList.remove('hidden');
    
    // Forza aggiornamento sliders sull'elemento attualmente selezionato (es. --primary)
    window.onElementChange();
};

window.chiudiPopupSettings = function() {
    document.getElementById('settingsPopup').style.display = 'none';
};

window.onElementChange = function() {
    const property = document.getElementById('element-selector').value;
    updateSliders(tempTheme[property]);
};

// 6. Aggiorna la vecchia funzione updateCustomPicker per usare la nuova logica
window.updateCustomPicker = function() {
    const h = document.getElementById('range-h').value;
    const s = document.getElementById('range-s').value;
    const v = document.getElementById('range-v').value;
    const hex = hsvToHex(h, s, v);
    applyColorToPreview(hex);
};

window.saveTheme = function() {
    window.setLocalStorage("userCustomTheme", JSON.stringify(tempTheme));
    window.updateTheme();
    window.chiudiPopupSettings();
};

window.updateTheme = function() {
    const root = document.documentElement;
    const isAdmin = window.getLocalStorage("isAdmin") === "true";
    const savedTheme = window.getLocalStorage("userCustomTheme");
    const btnSettings = document.getElementById("btn-settings"); // Recuperiamo il bottone

    if (isAdmin) {
        // --- LOGICA VISIBILITÀ ---
        if (btnSettings) btnSettings.style.display = "none"; // Nascondi se Admin

        // --- CASO ADMIN ---
        Object.keys(defaults).forEach(prop => {
            root.style.setProperty(prop, defaults[prop]);
        });

        const adminColor = getComputedStyle(root).getPropertyValue('--admin-color').trim() || "#ffcc00";
        root.style.setProperty('--primary', adminColor);
        
    } else {
        // --- LOGICA VISIBILITÀ ---
        if (btnSettings) btnSettings.style.display = "flex"; // Mostra se Utente (usiamo flex per mantenere l'allineamento del cerchio)

        if (savedTheme) {
            // --- CASO UTENTE CUSTOM ---
            const theme = JSON.parse(savedTheme);
            Object.keys(theme).forEach(prop => {
                root.style.setProperty(prop, theme[prop]);
            });
        } else {
            // --- CASO DEFAULT ---
            Object.keys(defaults).forEach(prop => {
                root.style.setProperty(prop, defaults[prop]);
            });
        }
    }
};

window.resetTheme = function() {
    tempTheme = {...defaults};
    window.removeLocalStorage("userCustomTheme");
    window.updateTheme();
    window.onElementChange();
};

window.applyPreset = function() {
    const selected = document.getElementById('preset-selector').value;
    if (!selected || !presets[selected]) return;

    const theme = presets[selected];
    
    // Aggiorna l'oggetto temporaneo tempTheme
    Object.keys(theme).forEach(prop => {
        tempTheme[prop] = theme[prop];
    });

    // Forza l'aggiornamento degli slider sull'elemento attualmente selezionato nella droplist "normale"
    const currentProp = document.getElementById('element-selector').value;
    window.updateSliders(tempTheme[currentProp]);
    
    // Messaggio di log opzionale
    console.log("Preset applicato:", selected);
};
// ---------------------------------------------------------------------------------------------

window.createAI_Interface = function() {
    // Controllo se l'utente è admin
    const isAdmin = window.getLocalStorage("isAdmin") === "true";

    if (isAdmin) {
        // Creazione dello stile per il bottone AI
        const style = document.createElement('style');
        style.textContent = `
            .btn-ai-admin {
                position: fixed;
                bottom: 20px;
                left: 20px;
                width: 50px;
                height: 50px;
                background: linear-gradient(135deg, #4285f4, #9b72cb, #d96570);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                text-decoration: none;
                box-shadow: 0 4px 15px rgba(0,0,0,0.3);
                z-index: 2000;
                transition: transform 0.2s;
                border: 2px solid rgba(255,255,255,0.2);
            }
            .btn-ai-admin:active {
                transform: scale(0.9);
            }
            .btn-ai-admin i {
                font-size: 1.5rem;
            }
        `;
        document.head.appendChild(style);

        // Creazione del bottone
        const aiBtn = document.createElement('a');
        aiBtn.href = "AI_interface.html";
        aiBtn.className = "btn-ai-admin";
        // Icona microfono che ricorda un assistente vocale/AI
        aiBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        
        document.body.appendChild(aiBtn);
    }
}

// --- GESTIONE CAMBIO SQUADRA DINAMICO ---
window.apriPopupCambioTeam = function() {
    const popup = document.getElementById("teamSelectorPopup");
    const container = document.getElementById("team-selector-list");
    if (!popup || !container) return;

    // Svuota il contenitore
    container.innerHTML = "";

    // Recupera l'utente corrente per estrarre l'array dei suoi team generato dal server
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (!cachedUser) return;

    const userData = JSON.parse(cachedUser);
    const listaTeam = userData.teams || [];

    if (listaTeam.length === 0) {
        container.innerHTML = `<p style="color: #aaa; font-size: 1.4rem;">Nessuna squadra aggiuntiva associata.</p>`;
    } else {
        // Genera i bottoni per ogni squadra associata
        listaTeam.forEach(team => {
            const itemBtn = document.createElement("div");
            
            itemBtn.style.backgroundColor = "var(--card-color, #222)";
            itemBtn.style.color = "var(--text-color, white)";
            itemBtn.style.padding = "1.2rem";
            itemBtn.style.borderRadius = "8px";
            itemBtn.style.cursor = "pointer";
            itemBtn.style.fontSize = "1.4rem";
            itemBtn.style.fontWeight = "500";
            itemBtn.style.textAlign = "left";
            itemBtn.style.border = "1px solid rgba(255,255,255,0.1)";
            itemBtn.style.transition = "background-color 0.2s";

            // Disabilita il ritardo del tap su mobile mantenendo lo scroll fluido
            itemBtn.style.touchAction = "manipulation";
            itemBtn.style.webkitTapHighlightColor = "transparent";

            // Formattazione testo
            itemBtn.innerText = `${team.id} - ${team.anno}: ${team.campionatoRiferimento} - ${team.squadra}`;

            // 🌟 GESTIONE DISTINZIONE TRA TAP E SCROLL
            let startY = 0;
            let startX = 0;
            let isScrolling = false;

            itemBtn.ontouchstart = function(e) {
                isScrolling = false;
                startY = e.touches[0].clientY;
                startX = e.touches[0].clientX;
            };

            itemBtn.ontouchmove = function(e) {
                // Calcola lo spostamento del dito
                const diffY = Math.abs(e.touches[0].clientY - startY);
                const diffX = Math.abs(e.touches[0].clientX - startX);

                // Se lo spostamento supera i 10px, stiamo scorrendo
                if (diffY > 10 || diffX > 10) {
                    isScrolling = true;
                }
            };

            itemBtn.onclick = function() {
                // Esegue il cambio squadra solo se il dito NON stava scorrendo
                if (!isScrolling) {
                    window.changeTeam(team.id);
                }
            };

            container.appendChild(itemBtn);
        });
    }

    // Mostra il popup usando flex per centrarlo
    popup.style.display = "flex";
};

window.OLD_apriPopupCambioTeam = function() {
    const popup = document.getElementById("teamSelectorPopup");
    const container = document.getElementById("team-selector-list");
    if (!popup || !container) return;

    // Svuota il contenitore
    container.innerHTML = "";

    // Recupera l'utente corrente per estrarre l'array dei suoi team generato dal server
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (!cachedUser) return;

    const userData = JSON.parse(cachedUser);
    const listaTeam = userData.teams || [];

    if (listaTeam.length === 0) {
        container.innerHTML = `<p style="color: #aaa; font-size: 1.4rem;">Nessuna squadra aggiuntiva associata.</p>`;
    } else {
        // Genera i bottoni per ogni squadra associata
        listaTeam.forEach(team => {
            const itemBtn = document.createElement("div");
            
            // Stile esistente...
            itemBtn.style.backgroundColor = "var(--card-color, #222)";
            itemBtn.style.color = "var(--text-color, white)";
            itemBtn.style.padding = "1.2rem";
            itemBtn.style.borderRadius = "8px";
            itemBtn.style.cursor = "pointer";
            itemBtn.style.fontSize = "1.4rem";
            itemBtn.style.fontWeight = "500";
            itemBtn.style.textAlign = "left";
            itemBtn.style.border = "1px solid rgba(255,255,255,0.1)";
            itemBtn.style.transition = "background-color 0.2s";

            // 🌟 AGGIUNTE SPECIFICHE PER SMARTPHONE (Risolve il problema del tap lento o mancato)
            itemBtn.style.touchAction = "manipulation";
            itemBtn.style.webkitTapHighlightColor = "transparent";

            // Nuova formattazione: ID - ANNO: CAMPIONATO DI RIFERIMENTO - SQUADRA
            itemBtn.innerText = `${team.id} - ${team.anno}: ${team.campionatoRiferimento} - ${team.squadra}`;

            // 🌟 AGGANCIO COMPLETO: sia per Mouse (click) che per Schermi Touch (touchend)
            const eseguiCambio = function(e) {
                e.preventDefault(); // Evita che l'evento venga eseguito due volte se il browser emula sia touch che click
                window.changeTeam(team.id);
            };

            itemBtn.onclick = eseguiCambio;
            itemBtn.ontouchend = eseguiCambio; // Assicura una risposta istantanea al rilascio del dito

            container.appendChild(itemBtn);
        });
    }

    // Mostra il popup usando flex per centrarlo
    popup.style.display = "flex";
};

window.chiudiPopupCambioTeam = function() {
    const popup = document.getElementById("teamSelectorPopup");
    if (popup) popup.style.display = "none";
};

window.OLDchangeTeam = function(teamId) {
    console.log("Cambio squadra richiesto per ID:", teamId);
    
    window.deleteLocalStorage();

    // 1. Recupera i dati utente per aggiornare l'ordine dell'array o il campo squadra principale
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (cachedUser) {
        const userData = JSON.parse(cachedUser);
        
        // Ricostruiamo la stringa posizionando il teamId selezionato come primo elemento della lista
        if (userData.squadra) {
            const clean = userData.squadra.replace(/[\[\]]/g, '');
            let ids = clean.split(',').map(id => id.trim());
            
            // Rimuove l'id se esiste già e lo rimette in prima posizione
            ids = ids.filter(id => id !== teamId);
            ids.unshift(teamId);
            
            userData.squadra = `[${ids.join(', ')}]`;
            window.setLocalStorage("userLoggedData", JSON.stringify(userData));
        }
    }

    // 2. Rimuove la vecchia configurazione del team per forzare il rinfresco dal server
    window.removeLocalStorage("teamConfigurationData");
    
    // 3. Chiude il popup e ricarica l'applicazione per scaricare la nuova squadra selezionata
    window.chiudiPopupCambioTeam();
    window.location.reload();
};
window.changeTeam = function(teamId) {
    console.log("Cambio squadra richiesto per ID:", teamId);
    
    // Mostra l'overlay di caricamento per bloccare tutti i clic
//    window.showLoadingOverlay("Configurazione squadra...");

    window.deleteLocalStorage();

    // 1. Recupera i dati utente per aggiornare l'ordine dell'array o il campo squadra principale
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (cachedUser) {
        const userData = JSON.parse(cachedUser);
        
        // Ricostruiamo la stringa posizionando il teamId selezionato come primo elemento della lista
        if (userData.squadra) {
            const clean = userData.squadra.replace(/[\[\]]/g, '');
            let ids = clean.split(',').map(id => id.trim());
            
            // Rimuove l'id se esiste già e lo rimette in prima posizione
            ids = ids.filter(id => id !== teamId);
            ids.unshift(teamId);
            
            userData.squadra = `[${ids.join(', ')}]`;
            window.setLocalStorage("userLoggedData", JSON.stringify(userData));
        }
    }

    // 2. Rimuove la vecchia configurazione del team per forzare il rinfresco dal server
    window.removeLocalStorage("teamConfigurationData");
    
    // 3. Chiude il popup e ricarica l'applicazione per scaricare la nuova squadra selezionata
    window.chiudiPopupCambioTeam();
    window.location.reload();
};

/**
 * Mostra l'overlay bloccante a schermo intero
 */
window.showLoadingOverlay = function(message) {
    if (document.getElementById('global-loading-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'global-loading-overlay';
    
    // Intercetta e blocca tutti gli eventi di click/touch
    overlay.addEventListener('click', function(e) {
        e.stopPropagation();
        e.preventDefault();
    }, true);

    const textEl = document.createElement('div');
    textEl.className = 'blinking-text';
    textEl.innerText = message || "Configurazione squadra...";

    overlay.appendChild(textEl);
    document.body.appendChild(overlay);
};

/**
 * Rimuove l'overlay dallo schermo
 */
window.hideLoadingOverlay = function() {
    const overlay = document.getElementById('global-loading-overlay');
    if (overlay) {
        overlay.remove();
    }
};


// 🔄 FUNZIONE DI SUPPORTO: Gestisce cosa mostrare sullo schermo in base al login
window.updateAppVisibility = updateAppVisibility;
function updateAppVisibility(isLogged) {
    const mainHeader = document.getElementById("main-header");
    const menuGrid = document.querySelector(".menu-grid");
    const loginContainer = document.getElementById("login-container");
    const btnLogout = document.getElementById("btn-logout");

    if (isLogged) {
        if (mainHeader) mainHeader.style.display = "flex"; // Ripristina l'header
        if (menuGrid) menuGrid.style.display = "grid";      // Ripristina la griglia dei bottoni
        if (loginContainer) loginContainer.style.display = "none";
        if (btnLogout) btnLogout.style.display = "block";   // Mostra il tasto Esci
    } else {
        if (mainHeader) mainHeader.style.display = "none";  // 🛑 Nasconde l'header
        if (menuGrid) menuGrid.style.display = "none";      // Nasconde la griglia dei bottoni
        if (loginContainer) loginContainer.style.display = "flex"; // Mostra solo il box di login
        if (btnLogout) btnLogout.style.display = "none";
    }
}

async function initApp() {
    // 1. Mostra subito l'overlay all'inizio dell'inizializzazione
    window.showLoadingOverlay("Configurazione squadra...");
    try {
        const appVersion = document.getElementById("appVersion");
        if (appVersion) appVersion.textContent = "Versione " + window.APP_VERSION;

        const loginAppVersion = document.getElementById("loginAppVersion");
        if (loginAppVersion) loginAppVersion.textContent = "Versione " + window.APP_VERSION;

        await window.signIn();

        const cachedUser = window.getLocalStorage("userLoggedData");
        const btnLogout = document.getElementById("btn-logout");
        
        if (cachedUser && btnLogout) {
            // Se l'utente è registrato in cache, mostra il bottone di disconnessione
            btnLogout.style.display = "block";
        }

        // Cambia il nome della squadra, il logo, e la versione del software
        const myTeamYear = document.getElementById("year");
        if (myTeamYear) myTeamYear.textContent = window.MY_TEAM_ANNO;

        const myTeamFullName = document.getElementById("myTeamFullName");
        if (myTeamFullName) myTeamFullName.textContent = window.MY_TEAM_FULLNAME;

        const logoAdmin = document.getElementById("logo-admin");
        if (logoAdmin) {

            const newLink = window.trasformaLinkDriveInThumbnail(window.MY_TEAM_LOGO_192, 192);

            // Fallback di sicurezza se la condivisione su Drive venisse disattivata
            logoAdmin.onerror = function(event) {
                // 1. Mostra l'errore dettagliato nella console degli sviluppatori (F12)
                console.error("FALLED_DRIVE_LOAD: Errore nel caricamento del logo da Google Drive.");
                console.dir(event); // Stampa l'oggetto evento con tutte le sue proprietà ispezionabili
                
                // 2. Se vuoi vedere l'URL esatto che ha fallito
                console.log("L'URL che ha generato l'errore era:", this.src);

                // 3. Applica il fallback locale per non lasciare l'immagine vuota
                this.src = "icon-192.png";
            };

            logoAdmin.src = newLink;

        }        

        // Prima di tutto carichiamo il tema salvato
        window.updateTheme();

        await window.registerUserId();

        const logo = document.getElementById("logo-admin");
        if (logo) {
            let lastTap = 0;
            logo.addEventListener('click', function () {
                const now = new Date().getTime();
                if (now - lastTap < 300 && now - lastTap > 0) Login();
                lastTap = now;
            });
        }
        createAI_Interface();
        checkLiveStatus(); 
        verificaNovitaAllenamenti();
        verificaNovitaFIP();
        setInterval(checkLiveStatus, 10000);
    } catch (error) { console.error(error); 

    } finally {
        // 2. Rimuovi l'overlay al termine di tutto (sia in caso di successo che di errore)
        window.hideLoadingOverlay();
    }
}

document.addEventListener("DOMContentLoaded", initApp);
window.onclick = (e) => { if (e.target == document.getElementById('customPopup')) chiudiPopup(); }

