let datiOriginaliPartite = [];
let statoOrdineMatch = { colonna: 'PTS', ascendente: false };

let myChart = null;
let currentGraphIdx = null;

// --- Helper per ricavare la Categoria Selezionata ---
function getCategoriaSelezionata(slideIndex) {
    const campionatiConfig = window.MY_TEAM_CAMPIONATO;
    if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
        return campionatiConfig[0];
    }
    const btnText = document.getElementById(`btnFilterCatText-${slideIndex}`);
    return btnText ? btnText.textContent.trim() : "Tutti";
}

// --- Helper Animazione Bottone ---
function animaBottoneFiltro(btnElement, textElement) {
    if (!btnElement) return;

    if (textElement) {
        textElement.classList.remove("animate-pop");
        void textElement.offsetWidth; // Force reflow
        textElement.classList.add("animate-pop");
    }

    const arrow = btnElement.querySelector(".btn-arrow");
    if (arrow) {
        arrow.classList.add("rotate");
        setTimeout(() => arrow.classList.remove("rotate"), 200);
    }
}

window.mostraGrafico = mostraGrafico;
function mostraGrafico(idx) {
    currentGraphIdx = idx;
    const modal = document.getElementById('modalGraph');
    modal.style.display = 'flex';

    setTimeout(() => {
        const filtroCorrente = getCategoriaSelezionata(idx);
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        const filterContainer = document.getElementById('modal-filters');

        let htmlCampionato = "";
        
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlCampionato = `<span id="modalCatText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlCampionato = `
                <button id="btnModalCat" type="button" class="cycle-filter-btn">
                    <span id="modalCatText">${filtroCorrente}</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }
        
        // Layout su singola riga con il bottone Tipo Grafico blu (#007bff)
        filterContainer.innerHTML = `
            <div class="modal-filters-wrapper">
                <div class="filter-group">
                    <strong>Campionato:</strong>
                    ${htmlCampionato}
                </div>
                <div class="filter-group">
                    <strong>Tipo Grafico:</strong>
                    <button id="btnModalTipoDato" type="button" class="cycle-filter-btn btn-tipo-grafico" data-value="partita">
                        <span id="modalTipoDatoText">Punti/Partita</span>
                        <span class="btn-arrow">▼</span>
                    </button>
                </div>
            </div>
        `;

        // Event listener per il bottone ciclico Campionato
        const btnModalCat = document.getElementById("btnModalCat");
        const modalCatText = document.getElementById("modalCatText");
        
        if (btnModalCat && modalCatText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = opzioniCat.indexOf(filtroCorrente);
            if (idxCat === -1) idxCat = 0;

            btnModalCat.addEventListener("click", () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                modalCatText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnModalCat, modalCatText);
                window.aggiornaGrafico();
            });
        }

        // Event listener per il bottone ciclico Tipo Grafico
        const btnModalTipoDato = document.getElementById("btnModalTipoDato");
        const modalTipoDatoText = document.getElementById("modalTipoDatoText");

        if (btnModalTipoDato && modalTipoDatoText) {
            btnModalTipoDato.addEventListener("click", () => {
                const eProgressivo = btnModalTipoDato.getAttribute("data-value") === "partita";
                
                if (eProgressivo) {
                    btnModalTipoDato.setAttribute("data-value", "progressivo");
                    modalTipoDatoText.textContent = "Progressivo";
                } else {
                    btnModalTipoDato.setAttribute("data-value", "partita");
                    modalTipoDatoText.textContent = "Punti/Partita";
                }

                if (typeof animaBottoneFiltro === "function") {
                    animaBottoneFiltro(btnModalTipoDato, modalTipoDatoText);
                }
                
                window.aggiornaGrafico();
            });
        }

        window.aggiornaGrafico();
    }, 100); 
}

function OLD4_mostraGrafico(idx) {
    currentGraphIdx = idx;
    const modal = document.getElementById('modalGraph');
    modal.style.display = 'flex';

    setTimeout(() => {
        const filtroCorrente = getCategoriaSelezionata(idx);
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        const filterContainer = document.getElementById('modal-filters');

        let htmlCampionato = "";
        
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlCampionato = `<span id="modalCatText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlCampionato = `
                <button id="btnModalCat" type="button" class="cycle-filter-btn">
                    <span id="modalCatText">${filtroCorrente}</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }
        
        // Layout flessibile: centrato di default, affiancato su una riga in landscape via CSS
        filterContainer.innerHTML = `
            <div class="modal-filters-wrapper">
                <div class="filter-group">
                    <strong>Campionato:</strong>
                    ${htmlCampionato}
                </div>
                <div class="filter-group">
                    <strong>Grafico:</strong>
                    <label><input type="radio" name="modalTipoDato" value="partita" checked onchange="window.aggiornaGrafico()"> Punti/Partita</label>
                    <label><input type="radio" name="modalTipoDato" value="progressivo" onchange="window.aggiornaGrafico()"> Progressivo</label>
                </div>
            </div>
        `;

        // Event listener per il bottone ciclico del modale grafico
        const btnModalCat = document.getElementById("btnModalCat");
        const modalCatText = document.getElementById("modalCatText");
        
        if (btnModalCat && modalCatText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = opzioniCat.indexOf(filtroCorrente);
            if (idxCat === -1) idxCat = 0;

            btnModalCat.addEventListener("click", () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                modalCatText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnModalCat, modalCatText);
                window.aggiornaGrafico();
            });
        }

        window.aggiornaGrafico();
    }, 100); 
}

function OLD3_mostraGrafico(idx) {
    currentGraphIdx = idx;
    const modal = document.getElementById('modalGraph');
    modal.style.display = 'flex';

    setTimeout(() => {
        const filtroCorrente = getCategoriaSelezionata(idx);
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        const filterContainer = document.getElementById('modal-filters');

        let htmlCampionato = "";
        
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlCampionato = `<span id="modalCatText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlCampionato = `
                <button id="btnModalCat" type="button" class="cycle-filter-btn">
                    <span id="modalCatText">${filtroCorrente}</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }
        
        // Layout compatto ed elastico per i filtri
        filterContainer.innerHTML = `
            <div class="modal-filters-wrapper">
                <div class="filter-group">
                    <strong>Campionato:</strong>
                    ${htmlCampionato}
                </div>
                <div class="filter-group">
                    <strong>Grafico:</strong>
                    <label><input type="radio" name="modalTipoDato" value="partita" checked onchange="window.aggiornaGrafico()"> Punti/Partita</label>
                    <label><input type="radio" name="modalTipoDato" value="progressivo" onchange="window.aggiornaGrafico()"> Progressivo</label>
                </div>
            </div>
        `;

        // Event listener per il bottone ciclico del modale grafico
        const btnModalCat = document.getElementById("btnModalCat");
        const modalCatText = document.getElementById("modalCatText");
        
        if (btnModalCat && modalCatText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = opzioniCat.indexOf(filtroCorrente);
            if (idxCat === -1) idxCat = 0;

            btnModalCat.addEventListener("click", () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                modalCatText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnModalCat, modalCatText);
                window.aggiornaGrafico();
            });
        }

        window.aggiornaGrafico();
    }, 100); 
}

function OLD2_mostraGrafico(idx) {
    currentGraphIdx = idx;
    const modal = document.getElementById('modalGraph');
    modal.style.display = 'flex';

    setTimeout(() => {
        const filtroCorrente = getCategoriaSelezionata(idx);
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        const filterContainer = document.getElementById('modal-filters');

        let htmlCampionato = "";
        
        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlCampionato = `<span id="modalCatText" class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            htmlCampionato = `
                <button id="btnModalCat" type="button" class="cycle-filter-btn">
                    <span id="modalCatText">${filtroCorrente}</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }
        
        filterContainer.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 12px; align-items: center; font-family: sans-serif;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <strong>Campionato:</strong>
                    ${htmlCampionato}
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <strong>Grafico:</strong>
                    <label><input type="radio" name="modalTipoDato" value="partita" checked onchange="window.aggiornaGrafico()"> Punti per partita</label>
                    <label style="margin-left:10px"><input type="radio" name="modalTipoDato" value="progressivo" onchange="window.aggiornaGrafico()"> Progressivo</label>
                </div>
            </div>
        `;

        // Event listener per il bottone ciclico del modale grafico (se presente)
        const btnModalCat = document.getElementById("btnModalCat");
        const modalCatText = document.getElementById("modalCatText");
        
        if (btnModalCat && modalCatText) {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            let idxCat = opzioniCat.indexOf(filtroCorrente);
            if (idxCat === -1) idxCat = 0;

            btnModalCat.addEventListener("click", () => {
                idxCat = (idxCat + 1) % opzioniCat.length;
                modalCatText.textContent = opzioniCat[idxCat];
                animaBottoneFiltro(btnModalCat, modalCatText);
                window.aggiornaGrafico();
            });
        }

        window.aggiornaGrafico();
    }, 100); 
}

function OLDmostraGrafico(idx) {
    currentGraphIdx = idx;
    const modal = document.getElementById('modalGraph');
    modal.style.display = 'flex'; // Prima mostriamo il modal...

    // ...e dopo un istante carichiamo il grafico e i filtri
    setTimeout(() => {
        const filtroCorrente = document.querySelector(`input[name="catFilter-${idx}"]:checked`).value;
        const filterContainer = document.getElementById('modal-filters');
        
        filterContainer.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 8px; font-family: sans-serif; font-size: 1.2rem;">
                <div>
                    <strong style="margin-right:10px">Campionato:</strong>
                    <label><input type="radio" name="modalFilter" value="U14" ${filtroCorrente === 'U14' ? 'checked' : ''} onchange="window.aggiornaGrafico()"> U14</label>
                    <label style="margin-left:10px"><input type="radio" name="modalFilter" value="U15" ${filtroCorrente === 'U15' ? 'checked' : ''} onchange="window.aggiornaGrafico()"> U15</label>
                    <label style="margin-left:10px"><input type="radio" name="modalFilter" value="Tutti" ${filtroCorrente === 'Tutti' ? 'checked' : ''} onchange="window.aggiornaGrafico()"> Tutti</label>
                </div>
                <div>
                    <strong style="margin-right:10px">Visualizzazione:</strong>
                    <label><input type="radio" name="modalTipoDato" value="partita" checked onchange="window.aggiornaGrafico()"> Punti per partita</label>
                    <label style="margin-left:10px"><input type="radio" name="modalTipoDato" value="progressivo" onchange="window.aggiornaGrafico()"> Progressivo</label>
                </div>
            </div>
        `;
        window.aggiornaGrafico();
    }, 100); 
}

window.aggiornaGrafico = aggiornaGrafico;
function aggiornaGrafico() {
    const canvas = document.getElementById('canvasGrafico');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    // Lettura valore dal testo del bottone o label nel modale
    const catSpan = document.getElementById('modalCatText');
    const cat = catSpan ? catSpan.textContent.trim() : "Tutti";
    //const tipoDato = document.querySelector('input[name="modalTipoDato"]:checked').value;
    const tipoDato = document.getElementById('btnModalTipoDato')?.getAttribute('data-value') || 'partita';
    
    let datiGrafico = datiOriginaliPartite[currentGraphIdx].filter(p => {
        if (String(p.matchIdFull).toLowerCase().includes("test") || String(p.matchName).toLowerCase().includes("test") || p.Data === "--/--" || p.MatchName === "Gara") return false;

        if (cat === "Tutti") return true;
        return p.matchIdFull.includes(cat);
    }).sort((a, b) => {
        const dA = a.Data.split('/').reverse().join('');
        const dB = b.Data.split('/').reverse().join('');
        return dA.localeCompare(dB);
    });

    if (datiGrafico.length === 0) return;

    let arrayDatiY = [];
    let arrayMedia = [];
    let mediaPunti = 0;
    let labelDataset = 'Punti';

    if (tipoDato === "progressivo") {
        labelDataset = 'Punti Progressivi';
        let sommaProgressiva = 0;
        arrayDatiY = datiGrafico.map(p => {
            sommaProgressiva += p.PTS;
            return sommaProgressiva;
        });
    } else {
        labelDataset = 'Punti';
        arrayDatiY = datiGrafico.map(p => p.PTS);
        
        const totalePunti = datiGrafico.reduce((acc, p) => acc + p.PTS, 0);
        mediaPunti = (totalePunti / datiGrafico.length).toFixed(1);
        arrayMedia = datiGrafico.map(() => mediaPunti);
    }

    if (myChart) myChart.destroy();

    const gradient = ctx.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(0, 86, 179, 0.3)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

    let datasets = [
        {
            label: labelDataset,
            data: arrayDatiY,
            opponents: datiGrafico.map(p => p.MatchName),
            borderColor: '#0056b3',
            backgroundColor: gradient,
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointRadius: tipoDato === "progressivo" ? 2 : 5, 
            pointHoverRadius: tipoDato === "progressivo" ? 4 : 7,
            pointBackgroundColor: '#fff',
            pointBorderWidth: tipoDato === "progressivo" ? 1 : 2
        }
    ];

    if (tipoDato === "partita") {
        datasets.push({
            label: `Media (${mediaPunti})`, 
            data: arrayMedia,
            borderColor: '#ff9800',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            pointRadius: 0,
            tension: 0
        });
    }

    myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: datiGrafico.map(p => p.Data.substring(0, 5)),
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true, 
                    position: 'top',
                    align: 'center',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        boxWidth: 6,
                        boxHeight: 6,
                        padding: 15,
                        font: { size: 11, weight: '500' }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    callbacks: {
                        label: (context) => {
                            if (context.dataset.borderDash) return `Media: ${context.parsed.y}`;
                            const pIndex = context.dataIndex;
                            const testoPunti = tipoDato === "progressivo" ? `Totale progressivo: ${context.parsed.y}` : `Punti fatti: ${context.parsed.y}`;
                            return [testoPunti, `Vs: ${context.dataset.opponents[pIndex]}`];
                        }
                    }
                }
            },
            scales: {
                y: { beginAtZero: true, grace: '15%' },
                x: { grid: { display: false } }
            }
        }
    });
}

function OLDaggiornaGrafico() {
    const canvas = document.getElementById('canvasGrafico');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const cat = document.querySelector('input[name="modalFilter"]:checked').value;
    const tipoDato = document.querySelector('input[name="modalTipoDato"]:checked').value; // 'partita' o 'progressivo'
    
    let datiGrafico = datiOriginaliPartite[currentGraphIdx].filter(p => {
        if (cat === "Tutti") return p.matchIdFull.includes("U14") || p.matchIdFull.includes("U15");
        return p.matchIdFull.includes(cat);
    }).sort((a, b) => {
        const dA = a.Data.split('/').reverse().join('');
        const dB = b.Data.split('/').reverse().join('');
        return dA.localeCompare(dB);
    });

    if (datiGrafico.length === 0) return;

    // --- LOGICA DI CALCOLO DATI ---
    let arrayDatiY = [];
    let arrayMedia = [];
    let mediaPunti = 0;
    let labelDataset = 'Punti';

    if (tipoDato === "progressivo") {
        labelDataset = 'Punti Progressivi';
        let sommaProgressiva = 0;
        arrayDatiY = datiGrafico.map(p => {
            sommaProgressiva += p.PTS;
            return sommaProgressiva;
        });
    } else {
        labelDataset = 'Punti';
        arrayDatiY = datiGrafico.map(p => p.PTS);
        
        const totalePunti = datiGrafico.reduce((acc, p) => acc + p.PTS, 0);
        mediaPunti = (totalePunti / datiGrafico.length).toFixed(1);
        arrayMedia = datiGrafico.map(() => mediaPunti);
    }

    if (myChart) myChart.destroy();

    const gradient = ctx.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(0, 86, 179, 0.3)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

    // Prepariamo i datasets dinamicamente
// Prepariamo i datasets dinamicamente
    let datasets = [
        {
            label: labelDataset,
            data: arrayDatiY,
            opponents: datiGrafico.map(p => p.MatchName),
            borderColor: '#0056b3',
            backgroundColor: gradient,
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            // --- MODIFICA: Rimpicciolisce i cerchi se il grafico è progressivo ---
            pointRadius: tipoDato === "progressivo" ? 2 : 5, 
            pointHoverRadius: tipoDato === "progressivo" ? 4 : 7,
            pointBackgroundColor: '#fff',
            pointBorderWidth: tipoDato === "progressivo" ? 1 : 2
        }
    ];

    // Aggiungiamo la linea della media solo se stiamo guardando i punti per partita singola
    if (tipoDato === "partita") {
        datasets.push({
            label: `Media (${mediaPunti})`, 
            data: arrayMedia,
            borderColor: '#ff9800',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            pointRadius: 0,
            tension: 0
        });
    }

    myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: datiGrafico.map(p => p.Data.substring(0, 5)),
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true, 
                    position: 'top',
                    align: 'center',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        boxWidth: 6,
                        boxHeight: 6,
                        padding: 15,
                        font: { 
                            size: 11,
                            weight: '500' 
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    callbacks: {
                        label: (context) => {
                            // Se è la linea della media
                            if (context.dataset.borderDash) return `Media: ${context.parsed.y}`;
                            
                            const pIndex = context.dataIndex;
                            const testoPunti = tipoDato === "progressivo" ? `Totale progressivo: ${context.parsed.y}` : `Punti fatti: ${context.parsed.y}`;
                            return [testoPunti, `Vs: ${context.dataset.opponents[pIndex]}`];
                        }
                    }
                }
            },
            scales: {
                y: { beginAtZero: true, grace: '15%' },
                x: { grid: { display: false } }
            }
        }
    });
}

window.chiudiGrafico = chiudiGrafico;
function chiudiGrafico() {
    document.getElementById('modalGraph').style.display = 'none';
}

function normalizeUrl(url) {
    if (!url) return "";
    if (!/^https?:\/\//i.test(url)) return "https://" + url;
    return url.trim();
}

function convertDriveLink(url) {
    if (!url) return "";
    // Caso: /d/FILE_ID/
    let match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
    return `https://drive.google.com/uc?id=${match[1]}`;
    }
    // Caso: id=FILE_ID
    match = url.match(/id=([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
    return `https://drive.google.com/uc?id=${match[1]}`;
    }
    return url; // fallback
}

function convertToThumbnailUrl(driveUrl, width = 200) {
    // Espressione regolare per catturare l'ID del file tra '/d/' e '/view'
    const match = driveUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
    
    if (match && match[1]) {
        const fileId = match[1];
        return `https://drive.google.com/thumbnail?id=${fileId}&sz=w${width}`;
    }
    
    // Ritorna null o un messaggio di errore se il link non è valido
    return null; 
}

window.applicaFiltriEGenera = applicaFiltriEGenera;
function applicaFiltriEGenera() {
    const slides = document.querySelectorAll('.swiper-slide');
    datiOriginaliPartite.forEach((partite, idx) => {
        const slide = slides[idx];
        if (!slide) return;
        
        const cat = getCategoriaSelezionata(idx);

        let filtrate = partite.filter(p => {
            if (String(p.matchIdFull).toLowerCase().includes("test") || String(p.matchName).toLowerCase().includes("test") || p.Data === "--/--" || p.MatchName === "Gara") return false;
            if (cat === "Tutti") return true;
            return p.matchIdFull.includes(cat);
        });
        renderizzaTabellaMatch(idx, filtrate);
    });
}

function OLDapplicaFiltriEGenera() {
    const slides = document.querySelectorAll('.swiper-slide');
    datiOriginaliPartite.forEach((partite, idx) => {
        const slide = slides[idx];
        if (!slide) return;
        const cat = slide.querySelector('input[name="catFilter-' + idx + '"]:checked').value;
        let filtrate = partite.filter(p => {
            if (String(p.matchIdFull).toLowerCase().includes("test") || String(p.matchName).toLowerCase().includes("test") || p.Data === "--/--" || p.MatchName === "Gara") return false;
            if (cat === "Tutti") return p.matchIdFull.includes("U14") || p.matchIdFull.includes("U15");
            return p.matchIdFull.includes(cat);
        });
        renderizzaTabellaMatch(idx, filtrate);
    });
}

window.gestisciOrdinamentoMatch = gestisciOrdinamentoMatch;
function gestisciOrdinamentoMatch(colonna, slideIndex) {
    if (statoOrdineMatch.colonna === colonna) {
    statoOrdineMatch.ascendente = !statoOrdineMatch.ascendente;
    } else {
    statoOrdineMatch.colonna = colonna;
    statoOrdineMatch.ascendente = false;
    }
    window.applicaFiltriEGenera();
}
function renderizzaTabellaMatch(slideIndex, dati) {
    const tbody = document.getElementById(`tbody-${slideIndex}`);
    const tfoot = document.getElementById(`tfoot-${slideIndex}`);
    const headers = document.querySelectorAll(`#table-${slideIndex} th`);
    if (!tbody) return;

    // 1. Ordinamento dei dati
    dati.sort((a, b) => {
        let vA = a[statoOrdineMatch.colonna], vB = b[statoOrdineMatch.colonna];
        if (statoOrdineMatch.colonna === 'Data') {
            const partsA = vA.split('/');
            const partsB = vB.split('/');
            const dateA = new Date(partsA[2], partsA[1] - 1, partsA[0]);
            const dateB = new Date(partsB[2], partsB[1] - 1, partsB[0]);
            return statoOrdineMatch.ascendente ? dateA - dateB : dateB - dateA;
        }
        if (statoOrdineMatch.colonna !== 'MatchName' && statoOrdineMatch.colonna !== 'Location' && statoOrdineMatch.colonna !== 'MatchIdDisplay') {
            vA = parseFloat(vA) || 0; vB = parseFloat(vB) || 0;
        }
        return statoOrdineMatch.ascendente ? (vA > vB ? 1 : -1) : (vA < vB ? 1 : -1);
    });

    // 2. Aggiornamento icone ordinamento negli header
    headers.forEach(th => {
        th.classList.remove('sort-asc', 'sort-desc');
        const onclickAttr = th.getAttribute('onclick');
        if (onclickAttr && onclickAttr.includes(`'${statoOrdineMatch.colonna}'`)) {
            th.classList.add(statoOrdineMatch.ascendente ? 'sort-asc' : 'sort-desc');
        }
    });

    // 3. Calcolo dei Totali
    let tPTS = 0, tTL = 0, tT2 = 0, tT3 = 0;
    dati.forEach(p => { 
        tPTS += p.PTS; 
        tTL += p.TL; 
        tT2 += p.T2; 
        tT3 += p.T3; 
    });

    // 4. Pulizia e Rendering
    tbody.innerHTML = "";
    if (tfoot) tfoot.innerHTML = ""; // Puliamo il footer originale

    // --- Inserimento riga TOTALE in alto ---
    const rowTotale = document.createElement("tr");
    rowTotale.style.backgroundColor = "#bdc3c7"; 
    rowTotale.style.color = "#2c3e50";
    rowTotale.style.fontWeight = "bold";
    rowTotale.style.borderBottom = "3px solid #7f8c8d";

    rowTotale.innerHTML = `
        <td></td>
        <td></td>
        <td></td>
        <td style="text-align:left; padding-left:0.5rem">TOTALE</td>
        <td class="pts-bold">${tPTS}</td>
        <td>${tTL}</td>
        <td>${tT2}</td>
        <td>${tT3}</td>
    `;
    tbody.appendChild(rowTotale);

    // --- Inserimento righe delle singole partite ---
    dati.forEach(p => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="date-col">${p.Data.substring(0, 6) + p.Data.slice(-2)}</td>
            <td class="id-col" style="line-height: 1.1;">${p.MatchIdDisplay.replace(' ', '<br>')}</td>
            <td class="loc-cell">${p.Location}</td>
            <td class="avversaria-cell">${p.MatchName}</td>
            <td class="pts-bold">${p.PTS}</td>
            <td>${p.TL}</td>
            <td>${p.T2}</td>
            <td>${p.T3}</td>
        `;
        tbody.appendChild(row);
    });
}

// --- LOGICA POPUP DETTAGLI ANAGRAFICA ---
window.mostraAnagrafica = mostraAnagrafica;
function mostraAnagrafica(playerJsonEncoded) {
    // Decodifichiamo l'oggetto player passato come stringa
    const player = JSON.parse(decodeURIComponent(playerJsonEncoded));
    
    // Controlliamo se la modale esiste già, altrimenti la creiamo nel body
    let modal = document.getElementById('modalPlayer');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modalPlayer';
        modal.className = 'modal-player';
        document.body.appendChild(modal);
    }

    // Costruiamo dinamicamente i dettagli. In futuro basterà aggiungere altri <p> qui
    modal.innerHTML = `
        <div class="modal-player-content">
            <img src="${player.Foto || ''}" class="modal-player-photo" onerror="this.src='https://via.placeholder.com/150'"/>
            <h3 style="font-size: 2rem; margin-bottom: 1.5rem; color: #2c3e50;">#${player["Numero Maglia"]} - ${player.Cognome} ${player.Nome}</h3>
            
            <div class="modal-player-details">
                <p><strong>Nome:</strong> ${player.Nome}</p>
                <p><strong>Cognome:</strong> ${player.Cognome}</p>
                <p><strong>Nick Name:</strong> ${player.NickName}</p>
                <p><strong>Numero Maglia:</strong> ${player["Numero Maglia"]}</p>
                </div>
            
            <button class="close-player" onclick="window.chiudiAnagrafica()">Chiudi</button>
        </div>
    `;
    
    modal.style.display = 'flex';
}

window.chiudiAnagrafica = chiudiAnagrafica;
function chiudiAnagrafica() {
    const modal = document.getElementById('modalPlayer');
    if (modal) modal.style.display = 'none';
}

async function caricaRoster() {
    const container = document.getElementById("roster-container");
    const roster = JSON.parse(window.getLocalStorage("datiRoster") || "[]");
    const stats = JSON.parse(window.getLocalStorage("datiTutteLeStats") || "{}").statisticheGiocatori || [];

    let partiteInfo = [];
    const cachePartite = window.getLocalStorage("cache_partite");

    if (cachePartite) {
    partiteInfo = JSON.parse(cachePartite);
    } else {
    try {
        const params = new URLSearchParams({
            sheet: "Partite",
            userId: userId,
            action: "Get Roster",
            details: JSON.stringify(getDeviceData)
        });

        const res = await fetch(`${url}?${params.toString()}`);
        const data = await res.json();
        partiteInfo = Array.isArray(data) ? data : data.data;
        window.setLocalStorage("cache_partite", JSON.stringify(partiteInfo));
    } catch (e) { console.error(e); }
    }

    
    roster.forEach((player, idx) => {

        const mData = stats.filter(s =>
            s.giocatore === player.Nome + " " + player.Cognome ||
            (s.numero == player["Numero Maglia"] && s.giocatore.includes(player.Cognome))
        ).map(p => {
            const d = JSON.parse(p.contatori || "{}");
            const idStr = String(p.matchId || "");

            // Gestione Prefisso (U14 o U15) + Numero
            const prefisso = idStr.includes("U14") ? "U14 " : (idStr.includes("U15") ? "U15 " : "");
            const matchIdNum = idStr.includes(" ") ? idStr.split(" ")[1] : idStr;
            const matchIdDisplay = prefisso + matchIdNum;

            const infoGara = partiteInfo.find(m => String(m.matchId) === idStr);
            let nomeGara = "Gara";
            let dataGara = "--/--";
            let loc = "";

            if (infoGara) {
            const isCasa = window.isMyTeam(infoGara.squadraA);
            loc = isCasa ? "🏠" : "🚌";
            nomeGara = isCasa ? infoGara.squadraB : infoGara.squadraA;
            dataGara = String(infoGara.data).replace("*", "") || "--/--";
            }
            return {
            matchIdFull: idStr,
            Data: dataGara,
            Location: loc,
            MatchName: nomeGara,
            MatchIdDisplay: matchIdDisplay,
            PTS: (parseInt(d["1"]) || 0) + (parseInt(d["2"]) || 0) * 2 + (parseInt(d["3"]) || 0) * 3,
            TL: parseInt(d["1"]) || 0, T2: parseInt(d["2"]) || 0, T3: parseInt(d["3"]) || 0
            };
        });

        datiOriginaliPartite[idx] = mData;

        const img = normalizeUrl(convertDriveLink((player.Foto || "").trim()));
        const playerString = encodeURIComponent(JSON.stringify(player));

        // Costruzione dinamica elemento filtro Campionato
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        let htmlFiltroCampionato = "";

        if (Array.isArray(campionatiConfig) && campionatiConfig.length === 1) {
            htmlFiltroCampionato = `<span class="label-single-camp">${campionatiConfig[0]}</span>`;
        } else {
            let opzioniCat = ["Tutti"];
            if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                opzioniCat = ["Tutti", ...campionatiConfig];
            }
            htmlFiltroCampionato = `
                <button id="btnFilterCat-${idx}" type="button" class="cycle-filter-btn">
                    <span id="btnFilterCatText-${idx}">${opzioniCat[0]}</span>
                    <span class="btn-arrow">▼</span>
                </button>
            `;
        }

        const slide = document.createElement("div");
        slide.classList.add("swiper-slide");
        slide.innerHTML = `
            <div class="player-header">
                <a href="roster.html" class="back-btn">‹</a>
                <div class="player-info">
                    <h2>#${player["Numero Maglia"]} - ${player.Cognome} ${player.Nome}</h2>
                </div>
                <img src="${player.Foto}" class="player-photo" onclick="window.mostraAnagrafica('${playerString}')" />
            </div>
            <div class="filters-container">
                <div class="filter-group">
                    <strong>Campionato:</strong>
                    ${htmlFiltroCampionato}
                    <button class="chart-btn" onclick="window.mostraGrafico(${idx})">📊</button>
                </div>
            </div>
            <table id="table-${idx}">
                <thead>
                    <tr>
                        <th onclick="window.gestisciOrdinamentoMatch('Data', ${idx})">Data</th>
                        <th onclick="window.gestisciOrdinamentoMatch('MatchIdDisplay', ${idx})">ID</th>
                        <th onclick="window.gestisciOrdinamentoMatch('Location', ${idx})">L</th>
                        <th onclick="window.gestisciOrdinamentoMatch('MatchName', ${idx})">Avversaria</th>
                        <th onclick="window.gestisciOrdinamentoMatch('PTS', ${idx})">PTS</th>
                        <th onclick="window.gestisciOrdinamentoMatch('TL', ${idx})">TL</th>
                        <th onclick="window.gestisciOrdinamentoMatch('T2', ${idx})">T2</th>
                        <th onclick="window.gestisciOrdinamentoMatch('T3', ${idx})">T3</th>
                    </tr>
                </thead>
                <tbody id="tbody-${idx}"></tbody>
                <tfoot id="tfoot-${idx}"></tfoot>
            </table>`;
        container.appendChild(slide);

        // Binding evento click se il bottone ciclico è presente nella slide
        setTimeout(() => {
            const btn = document.getElementById(`btnFilterCat-${idx}`);
            const btnText = document.getElementById(`btnFilterCatText-${idx}`);
            if (btn && btnText) {
                let opzioniCat = ["Tutti"];
                if (Array.isArray(campionatiConfig) && campionatiConfig.length > 1) {
                    opzioniCat = ["Tutti", ...campionatiConfig];
                }
                let idxCat = 0;

                btn.addEventListener("click", () => {
                    idxCat = (idxCat + 1) % opzioniCat.length;
                    btnText.textContent = opzioniCat[idxCat];
                    animaBottoneFiltro(btn, btnText);
                    window.applicaFiltriEGenera();
                });
            }
        }, 0);
    });

    window.applicaFiltriEGenera();
    new Swiper('.swiper', {
        initialSlide: parseInt(new URLSearchParams(window.location.search).get('player')) || 0,
        pagination: { el: '.swiper-pagination', clickable: true },
        keyboard: { enabled: true }
    });
}

async function OLDcaricaRoster() {
    const container = document.getElementById("roster-container");
    const roster = JSON.parse(window.getLocalStorage("datiRoster") || "[]");
    const stats = JSON.parse(window.getLocalStorage("datiTutteLeStats") || "{}").statisticheGiocatori || [];

    let partiteInfo = [];
    const cachePartite = window.getLocalStorage("cache_partite");

    if (cachePartite) {
    partiteInfo = JSON.parse(cachePartite);
    } else {
    try {
        const params = new URLSearchParams({
            sheet: "Partite",
            userId: userId,
            action: "Get Roster",
            details: JSON.stringify(getDeviceData)
        });

        const res = await fetch(`${url}?${params.toString()}`);
        const data = await res.json();
        partiteInfo = Array.isArray(data) ? data : data.data;
        window.setLocalStorage("cache_partite", JSON.stringify(partiteInfo));
    } catch (e) { console.error(e); }
    }

    roster.forEach((player, idx) => {
    const slide = document.createElement("div");
    slide.classList.add("swiper-slide");

    const mData = stats.filter(s =>
        s.giocatore === player.Nome + " " + player.Cognome ||
        (s.numero == player["Numero Maglia"] && s.giocatore.includes(player.Cognome))
    ).map(p => {
        const d = JSON.parse(p.contatori || "{}");
        const idStr = String(p.matchId || "");

        // Gestione Prefisso (U14 o U15) + Numero
        const prefisso = idStr.includes("U14") ? "U14 " : (idStr.includes("U15") ? "U15 " : "");
        const matchIdNum = idStr.includes(" ") ? idStr.split(" ")[1] : idStr;
        const matchIdDisplay = prefisso + matchIdNum;

        const infoGara = partiteInfo.find(m => String(m.matchId) === idStr);
        let nomeGara = "Gara";
        let dataGara = "--/--";
        let loc = "";

        if (infoGara) {
        const isCasa = window.isMyTeam(infoGara.squadraA);
        loc = isCasa ? "🏠" : "🚌";
        nomeGara = isCasa ? infoGara.squadraB : infoGara.squadraA;
        dataGara = String(infoGara.data).replace("*", "") || "--/--";
        }
        return {
        matchIdFull: idStr,
        Data: dataGara,
        Location: loc,
        MatchName: nomeGara,
        MatchIdDisplay: matchIdDisplay,
        PTS: (parseInt(d["1"]) || 0) + (parseInt(d["2"]) || 0) * 2 + (parseInt(d["3"]) || 0) * 3,
        TL: parseInt(d["1"]) || 0, T2: parseInt(d["2"]) || 0, T3: parseInt(d["3"]) || 0
        };
    });

    datiOriginaliPartite[idx] = mData;

    // Normalizza e converte il link della foto
    const img = normalizeUrl(convertDriveLink((player.Foto || "").trim()));

    // Serializzazione sicura dell'oggetto player corrente per passarlo alla funzione
    const playerString = encodeURIComponent(JSON.stringify(player));

    slide.innerHTML = `
        <div class="player-header">
        <a href="roster.html" class="back-btn">‹</a>
        <div class="player-info">
            <h2>#${player["Numero Maglia"]} - ${player.Cognome} ${player.Nome}</h2>
        </div>
        <img src="${player.Foto}" class="player-photo" onclick="window.mostraAnagrafica('${playerString}')" />
        </div>
        <div class="filters-container">
        <div class="filter-group">
            <strong>Campionato:</strong>
            <label><input type="radio" name="catFilter-${idx}" value="U14" onclick="window.applicaFiltriEGenera()"> U14</label>
            <label><input type="radio" name="catFilter-${idx}" value="U15" onclick="window.applicaFiltriEGenera()"> U15</label>
            <label><input type="radio" name="catFilter-${idx}" value="Tutti" checked onclick="window.applicaFiltriEGenera()"> Tutti</label>
            <button class="chart-btn" onclick="window.mostraGrafico(${idx})">📊</button>
        </div>
        </div>
        <table id="table-${idx}">
        <thead>
            <tr>
            <th onclick="window.gestisciOrdinamentoMatch('Data', ${idx})">Data</th>
            <th onclick="window.gestisciOrdinamentoMatch('MatchIdDisplay', ${idx})">ID</th>
            <th onclick="window.gestisciOrdinamentoMatch('Location', ${idx})">L</th>
            <th onclick="window.gestisciOrdinamentoMatch('MatchName', ${idx})">Avversaria</th>
            <th onclick="window.gestisciOrdinamentoMatch('PTS', ${idx})">PTS</th>
            <th onclick="window.gestisciOrdinamentoMatch('TL', ${idx})">TL</th>
            <th onclick="window.gestisciOrdinamentoMatch('T2', ${idx})">T2</th>
            <th onclick="window.gestisciOrdinamentoMatch('T3', ${idx})">T3</th>
            </tr>
        </thead>
        <tbody id="tbody-${idx}"></tbody>
        <tfoot id="tfoot-${idx}"></tfoot>
        </table>`;
    container.appendChild(slide);
    });

    window.applicaFiltriEGenera();
    new Swiper('.swiper', {
        initialSlide: parseInt(new URLSearchParams(window.location.search).get('player')) || 0,
        pagination: { el: '.swiper-pagination', clickable: true },
        keyboard: { enabled: true }
    });
}

caricaRoster();
