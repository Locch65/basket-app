//window.APP_VERSION = "1.5.0";
window.APP_VERSION = "2.1.8";

window.MY_TEAM_ID_V1  = "T-000";   // T-000 è quello della versione dell'app fino alla 1.4.x (dedicata esclusivamente alla Polismile)
window.MY_TEAM_ID     = "T-001";   // T-000 è quello della versione dell'app fino alla 1.4.x (dedicata esclusivamente alla Polismile)
window.MY_TEAM        = "Polismile A";
window.MY_TEAM_SHORTNAME = "Polismile";
window.MY_TEAM_FULLNAME  = ""; // serve per lo più nei titoli delle pagine
window.MY_TEAM_CAMPIONATO = ["U14", "U15"];

window.MY_TEAM_LOGO_192 = "https://drive.google.com/file/d/1wZcIpqESb43Zh3Jy6WtTYhLiVDveXrsB/view?usp=drive_link";       // Polismile
window.MY_TEAM_LOGO_512 = "https://drive.google.com/thumbnail?id=1URt85cQff8p8PnkA5zJWfuvCZDYfBGO3&sz=w512"; // Polismile


window.SCRIPT_URL_V1 = "https://script.google.com/macros/s/AKfycbxvL4JptQZ3KQz9qwZShbuQ73o9dlj23EpRuWLFruJ01_51WTklIHoIwf8Z503BCXS9TA/exec";
window.SCRIPT_URL_V2 = "https://script.google.com/macros/s/AKfycbw7pIuA4sU06bnVd-Un5gPSfPWi5CMErPJ6e2zIlt-AMjPi3WwzM10VU7CyJhC5HWw0/exec";
//"https://script.google.com/macros/s/AKfycby2ANsS897FFSYWulJPOCbkYBmGTT8gQXwyxSnObRT4OhzZYfK6SHl0JyAUjZNDh_Sv/exec";
//"https://script.google.com/macros/s/AKfycbwcRPwQncclriKEr4pF3PoycXYf-MCU0gHU5rG9zG1M1iljIP6KdFUbVcfFEw8m4EfS/exec";
//"https://script.google.com/macros/s/AKfycbzeUk1e2W-PoikfkXHxPQMDORZxBpXAmdKLywPFc9KNfYGTTA3u0IEX7OUHal5cKYmy/exec";
//"https://script.google.com/macros/s/AKfycbwA10OVesPSqL6Dz4whUPI7K2wpOuf6pTy_fjd-cm5-mGp90yPaIiFAWi0vc4BfrI7D/exec";
//"https://script.google.com/macros/s/AKfycbyaJl7nQSWUOchS4w6bi7xlmlRc7pBwFKVZSb0bCdTQNjZPRk10mQh_wsCr5zAmvMTB/exec";
//"https://script.google.com/macros/s/AKfycbx_z4wKUPciTQh6UmlkzgYWrENajSrgUrevwPRitcKi79A0KIfXpZiHLd5BzEtGzOgf/exec" // implementa SignIn
//"https://script.google.com/macros/s/AKfycbzEfmghDT-wfUsgEpTd1qoziszBplACd-FRdz6xcGd5v9YExEtEvQGhR6TTfwbyoSJ8/exec";

window.isMyTeam = isMyTeam;
function isMyTeam(teamName) {
  return teamName.toUpperCase() === window.MY_TEAM.toUpperCase();
}

window.getBackendUrl = getBackendUrl;
function getBackendUrl() {
  if (window.APP_VERSION.startsWith("1."))
    return window.SCRIPT_URL_V1;
  else
    return window.SCRIPT_URL_V2;
}

window.getTeamId = getTeamId;
function getTeamId() {
  if (window.APP_VERSION.startsWith("1."))
    return window.MY_TEAM_ID_V1;
  else
    return window.MY_TEAM_ID;
}


window.signOut = signOut;
function signOut() {
    window.userIsLogged = false;
    window.userId = null;

    // Rimuove sia i dati utente che la configurazione del team
    window.deleteLocalStorage();

    window.removeLocalStorage("userLoggedData");
    window.removeLocalStorage("teamConfigurationData");
    
    // Aggiorna subito l'interfaccia nascondendo i bottoni
    window.updateAppVisibility(false);
    
    // alert("Logout effettuato con successo. La pagina verrà ricaricata.");
    // window.location.reload();
}

window.signIn = signIn;
async function signIn() {
    const myMail = "mymail@gmail.com"; //"ciccio@bombo.it"; 
    
    // 1. CONTROLLO PREVENTIVO: L'utente è già memorizzato in cache?
    const cachedUser = window.getLocalStorage("userLoggedData");
    const cachedTeamConfig = window.getLocalStorage("teamConfigurationData");

    // CASO A: Abbiamo sia l'utente sia la squadra -> Tutto pronto localmente (Offline immediato)
    if (cachedUser && cachedTeamConfig) {
        try {
            const userData = JSON.parse(cachedUser);
            window.userIsLogged = true;
            window.userId = userData.id; 
            
            initializeTeamFromCache(JSON.parse(cachedTeamConfig));
            window.updateAppVisibility(true);
            
            if (typeof window.onAppReady === "function") window.onAppReady();
            return; 
        } catch (e) {
            window.deleteLocalStorage();

            window.removeLocalStorage("userLoggedData");
            window.removeLocalStorage("teamConfigurationData");
        }
    }

    // 🌟 CASO B (NUOVO): L'utente è loggato ma manca il Team Configuration (es. dopo changeTeam)
    // Saltiamo il fetch del SignIn e scarichiamo DIRETTAMENTE solo la squadra dal server
    if (cachedUser && !cachedTeamConfig) {
        try {
            const userData = JSON.parse(cachedUser);
            window.userIsLogged = true;
            window.userId = userData.id;

            // Mostriamo l'interfaccia principale ma attendiamo il download della configurazione
            window.updateAppVisibility(true); 
            
            // Richiede al server SOLO i dati della nuova squadra selezionata
            await readTeamConfiguration(); 
            
            if (typeof window.onAppReady === "function") window.onAppReady();
            return; // Fine del flusso per utente già loggato
        } catch (e) {
            console.error("Errore nel ripristino dell'utente loggato durante il cambio team:", e);
        
            window.deleteLocalStorage();

            window.removeLocalStorage("userLoggedData");
        }
    }

    // CASO C: Manca totalmente l'utente (Primo avvio assoluto o dopo un Logout)
    window.updateAppVisibility(false);
    window.setSignInButtonState(true);

    // 2. SE MANCA LA CACHE UTENTE, CHIAMIAMO IL BACKEND PER IL SIGNIN

    const params = new URLSearchParams({
        appVersion: window.APP_VERSION,
        userId: window.userId,
        action: "SignIn",
        mail: myMail,
        details: JSON.stringify(window.getDeviceData)
    });

    return fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => res.json())
        .then(async (data) => {
            if (data.status === "error" || data.status === "not_found") {

                window.deleteLocalStorage();

                window.removeLocalStorage("userLoggedData");
                window.removeLocalStorage("teamConfigurationData");
                window.userIsLogged = false;
                
                // 🛑 Errore: mantieni la griglia nascosta
                window.updateAppVisibility(false);
                // 🔄 RIPRISTINO IN CASO DI ERRORE CONTROLLATO
                window.setSignInButtonState(false);
                
                alert("Errore di Autenticazione: " + data.message);
                return; 
            }

            const utente = Array.isArray(data) ? data : data.data;

            if (utente && utente.id) {
                window.setLocalStorage("userLoggedData", JSON.stringify(utente));
                window.userIsLogged = true;
                window.userId = utente.id;

                await readTeamConfiguration();
                window.updateAppVisibility(true);
                
                // 🔄 RIPRISTINO (anche se scompare, lo azzeriamo per sicurezza futura)
                window.setSignInButtonState(false);
                
                if (typeof window.onAppReady === "function") window.onAppReady();
            } else {
                window.updateAppVisibility(false);
                window.setSignInButtonState(false);
                alert("Errore: Dati utente non validi ricevuti dal server.");
            }
        })
        .catch(err => {

            window.deleteLocalStorage();

            window.removeLocalStorage("userLoggedData");
            window.removeLocalStorage("teamConfigurationData");
            window.userIsLogged = false;
            window.updateAppVisibility(false);
            
            // 🔄 RIPRISTINO IN CASO DI ERRORE DI RETE
            window.setSignInButtonState(false);
            
            // alert("Errore di rete/connessione durante l'autenticazione: ");
        });
}

// 🛠️ NUOVA FUNZIONE DI SUPPORTO UNIFICATA
window.setSignInButtonState = setSignInButtonState;
function setSignInButtonState(isLoading) {
    // Recuperiamo il bottone dal DOM (se presente nella pagina corrente)
    const button = document.getElementById("btn-signin-central");
    
    if (!button) return;

    if (isLoading) {
        button.disabled = true;
        button.style.opacity = "0.6";
        button.style.cursor = "not-allowed";
        button.innerHTML = `<i class="fas fa-sync-alt fa-spin"></i> Connessione...`;
    } else {
        button.disabled = false;
        button.style.opacity = "1";
        button.style.cursor = "pointer";
        button.innerHTML = `<i class="fas fa-sign-in-alt"></i> Accedi`;
    }
}

function mostraErrorTeamConfigModal(messaggio) {
    let modal = document.getElementById('modalErrorTeamConfig');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modalErrorTeamConfig';
        modal.className = 'popup';
        modal.style.cssText = 'display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: var(--overlay); z-index: 2000; justify-content: center; align-items: center;';
        
        modal.innerHTML = `
            <div class="popup-content" style="max-width: 85%; width: 380px; text-align: center; padding: 20px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: #e74c3c; margin-bottom: 15px;"></i>
                <h3 style="color: white; margin-bottom: 10px;">Errore Configurazione</h3>
                <p id="errorTeamConfigText" style="color: #ddd; font-size: 1.3rem; margin-bottom: 20px;"></p>
                <div style="display: flex; gap: 10px; flex-direction: column;">
                    <button id="btnRetryTeamConfig" class="popup-btn" style="background-color: var(--primary); margin: 0;">
                        <i class="fas fa-sync-alt"></i> Riprova
                    </button>
                    <button id="btnLogoutTeamConfig" class="popup-btn" style="background-color: #c0392b; margin: 0;">
                        <i class="fas fa-sign-out-alt"></i> Disconnetti (Logout)
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('#btnRetryTeamConfig').onclick = async () => {
            modal.style.display = 'none';
            window.showLoadingOverlay("Riprova configurazione squadra...");
            try {
                await readTeamConfiguration();
                window.updateAppVisibility(true);
            } catch (e) {
                // Se fallisce ancora, il catch interno a readTeamConfiguration riaprirà il modal
            } finally {
                window.hideLoadingOverlay();
            }
        };

        modal.querySelector('#btnLogoutTeamConfig').onclick = () => {
            modal.style.display = 'none';
            window.signOut();
        };
    }

    document.getElementById('errorTeamConfigText').innerText = messaggio;
    modal.style.display = 'flex';
}

async function readTeamConfiguration() {
    let myTeamId = "T-000";
    
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (cachedUser) {
        try {
            const userData = JSON.parse(cachedUser);
            if (userData.squadra) { 
                const cleanSquadreString = userData.squadra.replace(/[\[\]]/g, '').trim();
                const listaSquadre = cleanSquadreString.split(',');
                if (listaSquadre.length > 0 && listaSquadre[0].trim() !== "") {
                    myTeamId = listaSquadre[0].trim();
                }
            }
        } catch (e) {
            console.error("Errore nel parsing dell'utente loggato per il teamId:", e);
        }
    }

    const params = new URLSearchParams({
        appVersion: window.APP_VERSION || "1",
        userId: window.userId || "Unknown",
        action: "GetTeam",
        teamId: myTeamId,
        details: JSON.stringify(window.getDeviceData || {})
    });

    // Implementazione Timeout tramite AbortController (es. 10 secondi)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
        const res = await fetch(`${window.getBackendUrl()}?${params.toString()}`, {
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!res.ok) throw new Error("Risposta del server non valida (HTTP " + res.status + ")");

        const teamData = await res.json();

        if (teamData.status === "error" || teamData.status === "not_found") {
            throw new Error(teamData.message || "Impossibile caricare la configurazione.");
        }

        const cleanedTeamData = teamData.data ? teamData.data : teamData;
        window.setLocalStorage("teamConfigurationData", JSON.stringify(cleanedTeamData));
        initializeTeamFromCache(cleanedTeamData);
        
    } catch (err) {
        clearTimeout(timeoutId);
        console.error("Errore durante il recupero della configurazione team:", err);
        
        // Se si verifica un timeout o un errore di rete
        const isTimeout = err.name === 'AbortError';
        const msg = isTimeout 
            ? "Richiesta scaduta (Timeout). Controlla la tua connessione." 
            : "Impossibile scaricare i dati della squadra (" + err.message + ")";

        // Mostra il popup personalizzato con bottone Riprova / Logout
        window.hideLoadingOverlay();
        mostraErrorTeamConfigModal(msg);
        
        // Propaga l'errore per bloccare i flussi successivi (es. in signIn)
        throw err; 
    }
}

function OLDreadTeamConfiguration() {
    // 1. Recuperiamo dinamicamente il teamId dell'utente loggato dal localStorage
    let myTeamId = "T-000"; // Fallback di default se qualcosa va storto
    
    const cachedUser = window.getLocalStorage("userLoggedData");
    if (cachedUser) {
        try {
            const userData = JSON.parse(cachedUser);
            if (userData.squadra) { 
                // 🧹 Pulizia della stringa "[T-001, T-002]"
                const cleanSquadreString = userData.squadra.replace(/[\[\]]/g, '').trim();
                const listaSquadre = cleanSquadreString.split(',');
                
                if (listaSquadre.length > 0 && listaSquadre[0].trim() !== "") {
                    myTeamId = listaSquadre[0].trim(); // Prende il primo elemento (es. "T-001")
                }
            }
        } catch (e) {
            console.error("Errore nel parsing dell'utente loggato per il teamId:", e);
        }
    }

    // 2. Prepariamo i parametri per la chiamata GET
    const params = new URLSearchParams({
        appVersion: window.APP_VERSION || "1",
        userId: window.userId || "Unknown",
        action: "GetTeam",
        teamId: myTeamId,
        details: JSON.stringify(window.getDeviceData || {})
    });

    // 🌟 Ritorniamo la Promise del fetch per far sì che signIn() possa sincronizzarsi con l'await
    return fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => {
            if (!res.ok) {
                throw new Error("Risposta del server non valida (HTTP " + res.status + ")");
            }
            return res.json();
        })
        .then(teamData => {
            if (teamData.status === "error" || teamData.status === "not_found") {
                console.error("Errore backend in GetTeam:", teamData.message);
                alert("Impossibile caricare la configurazione della squadra: " + teamData.message);
                return;
            }

            // 💾 SALVA LA CONFIGURAZIONE IN CACHE PER I PROSSIMI ACCESSI
            const cleanedTeamData = teamData.data ? teamData.data : teamData;
            window.setLocalStorage("teamConfigurationData", JSON.stringify(cleanedTeamData));
                    
            // Inizializza le variabili globali dell'interfaccia
            initializeTeamFromCache(cleanedTeamData);  
        })
        .catch(err => {
            console.error("Errore di rete durante il recupero della configurazione team:", err);
            alert("Errore di connessione: impossibile scaricare i dati della squadra.");
        });
}

window.initializeTeamFromCache = initializeTeamFromCache;
function initializeTeamFromCache(teamData) {
    // 📝 MAPPATURA DI TUTTI I CAMPI DELLO SHEET TEAMS SU "WINDOW"
    window.MY_TEAM_ID             = teamData.id;    
    window.MY_TEAM_ANNO           = teamData.anno;
    window.MY_TEAM                = teamData.squadra;
    window.MY_TEAM_SHORTNAME      = teamData.squadraShortName;
    if (!teamData.campionatoAltro || teamData.campionatoAltro === "") { // un solo campionato
        window.MY_TEAM_CAMPIONATO     = [teamData.campionatoRiferimento];
    }
    else {
        window.MY_TEAM_CAMPIONATO     = [teamData.campionatoRiferimento, teamData.campionatoAltro];
    }
    window.MY_TEAM_ALLENATORE     = teamData.allenatore;
    window.MY_TEAM_VICEALLENATORE = teamData.viceAllenatore;
    window.MY_TEAM_FILE_DB_NAME   = teamData.fileDbName;
    window.MY_TEAM_FILE_DB_ID     = teamData.fileDbId;
    window.MY_TEAM_LOGO_192       = teamData.logo192;
    window.MY_TEAM_LOGO_512       = teamData.logo512;
    window.MY_TEAM_YT_NOME        = teamData.canaleYoutubeNome;
    window.MY_TEAM_YT_ID          = teamData.canaleYoutubeId;
    window.MY_TEAM_CUSTOM_BTN     = teamData.customBtn;
    window.MY_TEAM_LINK_FIP_MAIN_1= teamData.linkFIP_main_1;
    window.MY_TEAM_LINK_FIP_DETT_1= teamData.linkFIP_dett_1;
    window.MY_TEAM_LINK_FIP_MAIN_2= teamData.linkFIP_main_2;
    window.MY_TEAM_LINK_FIP_DETT_2= teamData.linkFIP_dett_2;

    window.MY_TEAM_FULLNAME = window.MY_TEAM.toUpperCase() + (window.MY_TEAM_CAMPIONATO[0] ? " - " + window.MY_TEAM_CAMPIONATO[0] : "");

    // 🚫 GESTIONE DISABILITAZIONE BOTTONE CLASSIFICHE FIP
    const btnClassifiche = document.getElementById("btn-classifiche-fip");
    if (btnClassifiche) {
        const link1Vuoto = !window.MY_TEAM_LINK_FIP_MAIN_1 || window.MY_TEAM_LINK_FIP_MAIN_1.trim() === "";
        const link2Vuoto = !window.MY_TEAM_LINK_FIP_MAIN_2 || window.MY_TEAM_LINK_FIP_MAIN_2.trim() === "";

        if (link1Vuoto && link2Vuoto) {
            btnClassifiche.classList.add("disabled");
            btnClassifiche.style.opacity = "0.4";
            btnClassifiche.style.cursor = "not-allowed";
            btnClassifiche.style.pointerEvents = "none";
            btnClassifiche.removeAttribute("href");
        } else {
            btnClassifiche.classList.remove("disabled");
            btnClassifiche.style.opacity = "1";
            btnClassifiche.style.cursor = "pointer";
            btnClassifiche.style.pointerEvents = "auto";
            btnClassifiche.setAttribute("href", "classifica.html");
        }
    }

    // 🏆 GESTIONE DINAMICA BOTTONE CUSTOM ("Finali Nazionali")
    const btnCustom = document.getElementById("btn-custom") || document.querySelector('a[href="U14_FN.html"]');
    if (btnCustom) {
        let customConfig = window.MY_TEAM_CUSTOM_BTN;

        // Se arriva come stringa JSON (es. da localStorage/Google Sheets), eseguiamo il parse
        if (typeof customConfig === "string" && customConfig.trim() !== "") {
            try {
                customConfig = JSON.parse(customConfig);
            } catch (e) {
                console.warn("Formato MY_TEAM_CUSTOM_BTN non valido:", customConfig);
            }
        }

        // Verifica se l'array è valido e contiene i due elementi [titolo, pagina]
        if (Array.isArray(customConfig) && customConfig.length >= 2 && customConfig[0] && customConfig[1]) {
            const [titolo, pagina] = customConfig;
            
            btnCustom.style.display = "flex";
            btnCustom.setAttribute("href", pagina);
            
            const spanText = btnCustom.querySelector("span");
            if (spanText) {
                spanText.textContent = titolo;
            }
        } else {
            // Se è vuoto, nullo o non valido -> nascondi il bottone
            btnCustom.style.display = "none";
            btnCustom.removeAttribute("href");
        }
    }

    console.log("Configurazione Team caricata correttamente ed esportata globalmente:", teamData);
}

function OLDinitializeTeamFromCache(teamData) {
    // 📝 MAPPATURA DI TUTTI I CAMPI DELLO SHEET TEAMS SU "WINDOW"
    window.MY_TEAM_ID             = teamData.id;    
    window.MY_TEAM_ANNO           = teamData.anno;
    window.MY_TEAM                = teamData.squadra;
    window.MY_TEAM_SHORTNAME      = teamData.squadraShortName;
    if (!teamData.campionatoAltro || teamData.campionatoAltro === "") { // un solo campionato
        window.MY_TEAM_CAMPIONATO     = [teamData.campionatoRiferimento];
    }
    else {
        window.MY_TEAM_CAMPIONATO     = [teamData.campionatoRiferimento, teamData.campionatoAltro];
    }
    window.MY_TEAM_ALLENATORE     = teamData.allenatore;
    window.MY_TEAM_VICEALLENATORE = teamData.viceAllenatore;
    window.MY_TEAM_FILE_DB_NAME   = teamData.fileDbName;
    window.MY_TEAM_FILE_DB_ID     = teamData.fileDbId;
    window.MY_TEAM_LOGO_192       = teamData.logo192;
    window.MY_TEAM_LOGO_512       = teamData.logo512;
    window.MY_TEAM_YT_NOME        = teamData.canaleYoutubeNome;
    window.MY_TEAM_YT_ID          = teamData.canaleYoutubeId;
    window.MY_TEAM_CUSTOM_BTN     = teamData.customBtn;
    window.MY_TEAM_LINK_FIP_MAIN_1= teamData.linkFIP_main_1;
    window.MY_TEAM_LINK_FIP_DETT_1= teamData.linkFIP_dett_1;
    window.MY_TEAM_LINK_FIP_MAIN_2= teamData.linkFIP_main_2;
    window.MY_TEAM_LINK_FIP_DETT_2= teamData.linkFIP_dett_2;

    window.MY_TEAM_FULLNAME = window.MY_TEAM.toUpperCase() + (window.MY_TEAM_CAMPIONATO[0] ? " - " + window.MY_TEAM_CAMPIONATO[0] : "");

    // 🚫 GESTIONE DISABILITAZIONE BOTTONE CLASSIFICHE FIP
    const btnClassifiche = document.getElementById("btn-classifiche-fip");
    if (btnClassifiche) {
        const link1Vuoto = !window.MY_TEAM_LINK_FIP_MAIN_1 || window.MY_TEAM_LINK_FIP_MAIN_1.trim() === "";
        const link2Vuoto = !window.MY_TEAM_LINK_FIP_MAIN_2 || window.MY_TEAM_LINK_FIP_MAIN_2.trim() === "";

        if (link1Vuoto && link2Vuoto) {
            btnClassifiche.classList.add("disabled");
            btnClassifiche.style.opacity = "0.4";
            btnClassifiche.style.cursor = "not-allowed";
            btnClassifiche.style.pointerEvents = "none";
            btnClassifiche.removeAttribute("href");
        } else {
            btnClassifiche.classList.remove("disabled");
            btnClassifiche.style.opacity = "1";
            btnClassifiche.style.cursor = "pointer";
            btnClassifiche.style.pointerEvents = "auto";
            btnClassifiche.setAttribute("href", "classifica.html");
        }
    }

    console.log("Configurazione Team caricata correttamente ed esportata globalmente:", teamData);
}

function init() {
        // ATTENZIONE: migliorare
        const cachedTeamConfig = window.getLocalStorage("teamConfigurationData");
        if (cachedTeamConfig) {
        window.initializeTeamFromCache(JSON.parse(cachedTeamConfig));
        }

}

init();