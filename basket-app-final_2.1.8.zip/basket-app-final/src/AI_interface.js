
const API_KEY = "AIzaSyAcmfcTcWRjW6M9wqQdXJO_owHKASRAhfY"; 
const statusDiv = document.getElementById('status');
const responseDiv = document.getElementById('response-text');
const micBtn = document.getElementById('micBtn');
const debugDiv = document.getElementById('debug');
const textInput = document.getElementById('textInput');
const sendBtn = document.getElementById('sendBtn');

let SpeechRecognition;
let recognition;
let isListening = false;

let ultimaDomanda = "";

const dictNicknames = {
    "A.D. USAC Rivarolo BK 2009": "Rivarolo",
    "Area Pro 2020": "Area Pro",
    "ASD Basket Nole": "Nole",
    "Basket Club G BORSI": "Ceva",
    "Basket Venaria": "Venaria",
    "BCC Derthona": "Derthona",
    "BEA Chieri SSDRL": "Chieri",
    "BONPRIX Biellese": "Biella",
    "College Basketball": "Borgomanero",
    "Cuneo": "Cuneo",
    "Don Bosco Crocetta": "Crocetta",
    "EBE Pancalieri": "Pancalieri",
    "Eteila Basket": "Aosta",
    "Gators Basketball": "Savigliano",
    "Granda College": "Cuneo",
    "Lib. Moncalieri": "Moncalieri",
    "Lib. Moncalieri Blu": "Moncalieri Blu",
    "Livorno Ferraris": "Livorno Ferraris",
    "Pink Magic Shark Oleggio": "Oleggio",
    "Polismile B": "Polismile B",
    "Polismile U15": "Polismile U15",
    "Polisp. Reba": "Reba",
    "San Mauro": "San Mauro"
};

// Dizionario per correggere la pronuncia del sintetizzatore vocale
const dictPronuncia = {
    "Polismile": "Poli smail",
    "U15": "Under 15",
    "U17": "Under 17",
    "U19": "Under 19",
    "BK": "Basket",
    "vs": "contro",
    "IST.": "Istituto",
    "ASD": "A S D" // Utile per evitare che lo legga come una parola unica
    // Aggiungi qui altre sostituzioni: "ParolaScritta": "ParolaFonetica"
};

function logDebug(msg) {
    debugDiv.innerHTML += "<br>> " + msg;
    debugDiv.scrollTop = debugDiv.scrollHeight;
    console.log(msg);
}

function normalizzaRoster() {
    const rawRoster = window.getLocalStorage("datiRoster");
    if (!rawRoster) return { lista: "Roster non disponibile", mappa: {} };

    try {
        const giocatori = JSON.parse(rawRoster);
        const mappaMaglie = {};
        
        const rosterFiltrato = giocatori.map(g => {
            const numero = g["Numero Maglia"] || g.NumeroMaglia; 
            const nomeCompleto = `${g.Nome} ${g.Cognome}`;
            if (numero) {
                mappaMaglie[numero] = nomeCompleto;
            }
            return {
                Nome: g.Nome,
                Cognome: g.Cognome,
                "Numero Maglia": numero,
                NickName: g.NickName
            };
        });
        return {
            lista: JSON.stringify(rosterFiltrato),
            mappa: mappaMaglie
        };
    } catch (e) {
        logDebug("Errore normalizzaRoster: " + e.message);
        return { lista: "Errore dati roster", mappa: {} };
    }
}

function normalizzaPartite() {
    const rawData = window.getLocalStorage("cache_partite");
    if (!rawData) return "Nessun dato disponibile";

    const datiRoster = normalizzaRoster();
    const mappaMaglie = datiRoster.mappa;

    try {
        let partite = JSON.parse(rawData);
        const partiteFiltrate = partite
            .filter(p => {
                const id = String(p.matchId || "").toLowerCase();
                return !id.includes("test");
            })
            .map(p => {
                const getNick = (nome) => dictNicknames[nome] || nome;
                let convocatiNomi = p.convocazioni;
                if (p.convocazioni && typeof p.convocazioni === "string") {
                    let pulita = p.convocazioni.replace(/[\[\]]/g, "");
                    convocatiNomi = pulita.split(',')
                        .map(num => {
                            const n = num.trim();
                            if (n === "") return null;
                            return mappaMaglie[n] || n;
                        })
                        .filter(n => n !== null)
                        .join(', ');
                }

                return {
                    matchId: p.matchId,
                    data: p.data,
                    orario: p.orario,
                    squadraA: getNick(p.squadraA),
                    squadraB: getNick(p.squadraB),
                    luogo: p.luogo,
                    casaTrasferta: p.casaTrasferta,
                    punteggioA: p.punteggioA,
                    punteggioB: p.punteggioB,
                    convocazioni: convocatiNomi,
                    statoPartita: p.statoPartita
                };
            });

        return {
            partite: JSON.stringify(partiteFiltrate),
            roster: datiRoster.lista
        };

    } catch (e) {
        logDebug("Errore normalizzaPartite: " + e.message);
        return { partite: "Errore dati", roster: "" };
    }
}

async function chiediAGemini(domanda) {
    const loadingSpinner = document.getElementById('loading-spinner');
    
    // Mostra lo spinner e pulisci la risposta precedente
    loadingSpinner.style.display = "block";
    //responseDiv.textContent = "";

    const today = new Date().toLocaleDateString('it-IT', { 
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    });            
    
    const cache_allenamenti = window.getLocalStorage("cache_allenamenti") || "[]";
    const datiNormalizzati = normalizzaPartite();
    const mappaLuoghi = window.getLocalStorage("mappaLuoghi") || "[]";
    const statsIA = window.getLocalStorage("dati_stats_ia") || "[]";
    
//            const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${API_KEY}`;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite-preview:generateContent?key=${API_KEY}`;
    
    const promptIA = `Oggi è ${today}. 
                        Sei l'assistente della squadra ${window.MY_TEAM_SHORTNAME}. 
                        ROSTER GIOCATORI: ${datiNormalizzati.roster}.
                        STATISTICHE DETTAGLIATE PUNTI: ${statsIA}.
                        PARTITE E CONVOCATI: ${datiNormalizzati.partite}. 
                        ALLENAMENTI SETTIMANALI: ${cache_allenamenti}.
                        LUOGHI: ${mappaLuoghi}.
                        Rispondi brevemente a: ${domanda}`;

    const maxRetries = 3;
    let attesaTraRetry = 2000; // 2 secondi

    for (let i = 0; i < maxRetries; i++) {
        try {
            logDebug(`Chiamata Gemini (Tentativo ${i + 1})...`);
            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents: [{ parts: [{ text: promptIA }] }] })
            });

            // Se il server risponde che è occupato (429 o 503)
            if (res.status === 429 || res.status === 503) {
                throw new Error("SERVER_BUSY");
            }

            const data = await res.json();
            if (data.error) throw new Error(data.error.message);

            loadingSpinner.style.display = "none";

            const risposta = data.candidates[0].content.parts[0].text;
            // Converte il grassetto di Gemini (**) in tag HTML (<b>)
            const rispostaFormattata = risposta.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');

            // Usa innerHTML per interpretare i tag <b>
            responseDiv.innerHTML = rispostaFormattata;

            const rispostaPulita = risposta.replace(/[\*\#]/g, "");
            parla(rispostaPulita);
            textInput.value = ""; 
            return; // Esci dalla funzione con successo

        } catch (err) {
            logDebug(`Errore al tentativo ${i + 1}: ${err.message}`);
            
            // Se non è un errore di server occupato o abbiamo esaurito i tentativi, esce dal ciclo
            if (err.message !== "SERVER_BUSY" && !err.message.includes("quota")) {
                loadingSpinner.style.display = "none";
                break; 
            }

            if (i < maxRetries - 1) {
                logDebug(`Server occupato, riprovo tra ${attesaTraRetry/1000}s...`);
                await new Promise(resolve => setTimeout(resolve, attesaTraRetry));
                attesaTraRetry *= 2; // Raddoppia il tempo di attesa ogni volta
            }
        }
    }

    // Se arriviamo qui, tutti i tentativi sono falliti
    // 'ultimaDomanda' deve essere definita globalmente o passata, altrimenti usa 'domanda'
    textInput.value = domanda; 
    responseDiv.textContent = "Errore IA: il server è occupato, riprova tra poco.";
}

function parla(testo) {
    const synth = window.speechSynthesis;
    
    // Cancella eventuali code precedenti
    synth.cancel();

    // Applica le sostituzioni dal dizionario fonetico
    let testoFonetico = testo;
    for (const [scritto, fonetico] of Object.entries(dictPronuncia)) {
        // Usiamo una Regular Expression per sostituire tutte le occorrenze (case-insensitive)
        const regex = new RegExp(scritto, "gi");
        testoFonetico = testoFonetico.replace(regex, fonetico);
    }

    const utter = new SpeechSynthesisUtterance(testoFonetico);
    utter.lang = 'it-IT';

    // Gestione stato bottone altoparlante
    utter.onstart = () => {
        if (typeof stopVoiceBtn !== 'undefined') stopVoiceBtn.disabled = false;
    };

    utter.onend = () => {
        if (typeof stopVoiceBtn !== 'undefined') stopVoiceBtn.disabled = true;
    };

    utter.onerror = () => {
        if (typeof stopVoiceBtn !== 'undefined') stopVoiceBtn.disabled = true;
    };

    synth.speak(utter);
}

function init()
{

    // 1. Controllo: siamo nella pagina AI?
    const container = document.getElementById('ai-container');
    if (!container) return;


    const script = document.createElement('script');
    script.src = "//cdn.jsdelivr.net/npm/eruda"; 
    document.head.appendChild(script);
    script.onload = function () {
        eruda.init();
        console.log("Eruda inizializzato con successo");
    };
    if (!SpeechRecognition) {
        SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    }


    if (SpeechRecognition) {
        recognition = new SpeechRecognition();
        recognition.lang = 'it-IT';
        recognition.interimResults = false; 
        recognition.maxAlternatives = 1;

        recognition.onstart = () => {
            logDebug("Microfono attivo...");
            isListening = true;
            micBtn.classList.add('listening');
            statusDiv.textContent = "Ti ascolto (clicca per fermare)...";
        };

        recognition.onerror = (event) => {
            logDebug("Errore: " + event.error);
            isListening = false;
            micBtn.classList.remove('listening');
            statusDiv.textContent = "Errore: " + event.error;
        };

        recognition.onend = () => {
            logDebug("Fine ascolto.");
            isListening = false; 
            micBtn.classList.remove('listening');
            if(statusDiv.textContent === "Ti ascolto (clicca per fermare)...") {
                statusDiv.textContent = "Tocca per parlare";
            }
        };

        recognition.onresult = (event) => {
            const trascrizione = event.results[0][0].transcript;
            logDebug("Hai detto: " + trascrizione);
            responseDiv.textContent = "Domanda: " + trascrizione;
            chiediAGemini(trascrizione);
        };
    }

    micBtn.onclick = () => {
        if (isListening) {
            logDebug("Interruzione manuale dell'ascolto.");
            recognition.stop(); // Ferma l'ascolto
        } else {
            try {
                recognition.start();
            } catch (e) {
                logDebug("Errore start: " + e.message);
            }
        }
    };

    // Gestione invio testo
    sendBtn.onclick = () => {
        ultimaDomanda = textInput.value;
        textInput.value = ""; 

        if (ultimaDomanda.trim() !== "") {
            responseDiv.textContent = "Domanda: " + ultimaDomanda;
            chiediAGemini(ultimaDomanda);
        }
    };
    textInput.onkeypress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { // Invia con Enter, vai a capo con Shift+Enter
            e.preventDefault(); 
            sendBtn.click();
        }
    };

    const stopVoiceBtn = document.getElementById('stopVoiceBtn');

    // Funzione per fermare la voce manualmente
    stopVoiceBtn.onclick = () => {
        window.speechSynthesis.cancel();
        stopVoiceBtn.disabled = true;
        logDebug("Voce interrotta manualmente.");
    };

}

init();