/**
 * Converte una stringa "HH:MM:SS" in un oggetto Date basato sulla giornata di oggi.
 * @param {string} stringaOra - Orario nel formato "HH:MM:SS" (es. "15:30:45")
 * @returns {Date} Oggetto Date con l'orario configurato
 */
function creaDataDaOrario(stringaOra) {
  // 1. Dividiamo la stringa nei tre componenti
  const parti = stringaOra.split(":"); // Risultato: ["HH", "MM", "SS"]

  // 2. Creiamo un nuovo oggetto Date con la data e l'ora attuali
  const dataRisultato = new Date();

  // 3. Estraiamo i valori convertendoli in numeri interi (base 10)
  const ore = parseInt(parti[0], 10);
  const minuti = parseInt(parti[1], 10);
  const secondi = parseInt(parti[2] || "0", 10); // Default a 0 se i secondi mancano o sono malformati

  // 4. Configuriamo l'orario specifico sulla data di oggi
  dataRisultato.setHours(ore);
  dataRisultato.setMinutes(minuti);
  dataRisultato.setSeconds(secondi);
  dataRisultato.setMilliseconds(0); // Azzera i millisecondi per evitare sfasamenti nei confronti

  return dataRisultato;
}

const getOraArrotondata = (usaOraAttuale = true) => {
    let oraOggetto = new Date(); // Parte sempre dalla data/ora corrente

    if (window.RECORD_EVENTS_A_POSTERIORI)
        oraOggetto = creaDataDaOrario(window.orarioVisualizzatoFormattato); // PER CREARE GLI EVENTI A POSTERIORI IN BASE AL TEMPO DEL VIDEO YOUTUBE

    if (usaOraAttuale) {
        // CASO VERO: Prendi ora attuale e aggiungi un minuto
        oraOggetto.setMinutes(oraOggetto.getMinutes() + 1);
    } else {
        // CASO FALSO: Mantieni data odierna, ma usa l'ora da orarioVisualizzatoFormattato
        const oraStringa = window.orarioVisualizzatoFormattato.substring(0, 5);
        const [ore, minuti] = oraStringa.split(':').map(Number);
        
        // Sovrascrive l'orario nell'oggetto Date
        oraOggetto.setHours(ore, minuti, 0, 0);
    }

    return oraOggetto.toLocaleTimeString('it-IT', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
};

window.gestisciGoLive = gestisciGoLive;
function gestisciGoLive() {
    const overlay = document.createElement('div');
    overlay.id = 'goLivePopup';
    overlay.className = 'popup';

    // 1. CARICAMENTO DATI ESISTENTI
    let tempiGara = {};
    try { 
        tempiGara = (typeof window.dettagliGara.note === 'string') 
            ? JSON.parse(window.dettagliGara.note) 
            : (window.dettagliGara.note || {});
    } catch(e) { tempiGara = {}; }

    const fasi = [
        { id: 'I0', label: 'Intervallo Iniziale (Go Live)', tipo: 'int' },
        { id: 'Q1', label: 'QUARTO 1', tipo: 'q' },
        { id: 'I1', label: 'Intervallo 1', tipo: 'int' },
        { id: 'Q2', label: 'QUARTO 2', tipo: 'q' },
        { id: 'I2', label: 'Intervallo 2', tipo: 'int' },
        { id: 'Q3', label: 'QUARTO 3', tipo: 'q' },
        { id: 'I3', label: 'Intervallo 3', tipo: 'int' },
        { id: 'Q4', label: 'QUARTO 4', tipo: 'q' },
        { id: 'I4', label: 'Intervallo 4', tipo: 'int' },
        { id: 'OT1', label: 'Overtime 1', tipo: 'ot' },
        { id: 'I5', label: 'Intervallo 5', tipo: 'int' },
        { id: 'OT2', label: 'Overtime 2', tipo: 'ot' },
        { id: 'Terminata', label: 'TERMINATA', tipo: 'end' }
    ];

    // Funzione interna per gestire il toggle dell'editing
    const toggleEditingState = (btn, forceState = null) => {
        let isEditing = forceState !== null ? forceState : btn.dataset.editing === "false";
        
        if (isEditing) {
            btn.dataset.editing = "true";
            btn.style.background = "#f39c12"; // Arancione
            btn.style.color = "white";
            btn.innerHTML = '<i class="fas fa-lock-open"></i> EDITING ATTIVO';
        } else {
            btn.dataset.editing = "false";
            btn.style.background = "white";
            btn.style.color = "#f39c12";
            btn.innerHTML = '<i class="fas fa-edit"></i> ATTIVA EDITING';
        }
    };

    const aggiornaStatoBottoni = (container) => {
        const buttons = container.querySelectorAll('.btn-fase');
        const checkHighlights = container.querySelector('#checkHighlights');
        const labelHighlights = container.querySelector('#labelHighlights');
        const containerEditing = container.querySelector('#containerEditing');
        const btnEditing = container.querySelector('#btnEditingMode');
        
        buttons.forEach((btn, i) => {
            const idFase = btn.dataset.fase;
            const fasePrecedenteId = i > 0 ? fasi[i-1].id : null;
            const fasePrecedenteIniziata = fasePrecedenteId 
                ? (tempiGara[fasePrecedenteId]?.inizio && tempiGara[fasePrecedenteId]?.inizio !== "--:--") 
                : true;

            if (i === 0 || fasePrecedenteIniziata) {
                btn.disabled = false;
                btn.style.opacity = "1";
            } else {
                const q4Iniziato = tempiGara['Q4']?.inizio && tempiGara['Q4']?.inizio !== "--:--";
                if (idFase === "Terminata" && q4Iniziato) {
                    btn.disabled = false;
                    btn.style.opacity = "1";
                } else {
                    btn.disabled = true;
                    btn.style.opacity = "0.4";
                }
            }
        });

        // Logica visibilità Editing e Highlights
        const btnTerminata = container.querySelector('.btn-fase[data-fase="Terminata"]');
        if (btnTerminata && btnTerminata.classList.contains('active')) {
            containerEditing.style.display = "block";
            checkHighlights.disabled = false;
            labelHighlights.style.opacity = "1";
        } else {
            containerEditing.style.display = "none";
            checkHighlights.disabled = true;
            labelHighlights.style.opacity = "0.4";
            if(btnEditing) toggleEditingState(btnEditing, false);
        }
    };

    const content = document.createElement('div');
    content.className = 'popup-content';
    content.style.cssText = 'max-width: 380px; max-height: 90vh; overflow-y: auto; padding: 20px;';

    let htmlFasi = fasi.map(fase => {
        const orari = tempiGara[fase.id] || { inizio: '--:--', fine: '--:--' };
        const isSmall = (fase.tipo === 'int' || fase.tipo === 'ot');
        const padding = isSmall ? '8px 10px' : '12px'; 
        const fontSize = isSmall ? '0.9rem' : '1.1rem';
        let bgColor = (fase.tipo === 'int') ? '#f8f9fa' : 'white';
        let borderColor = (fase.tipo === 'int') ? '#bdc3c7' : '#3498db';
        let textColor = (fase.tipo === 'int') ? '#7f8c8d' : '#3498db';

        return `
            <div class="fase-row" style="display: flex; align-items: center; gap: 12px; margin-bottom: 6px;">
                <button class="btn-fase" data-fase="${fase.id}" data-tipo="${fase.tipo}"
                    style="flex: 1; text-align: center; padding: ${padding}; font-size: ${fontSize}; 
                           border: 2px solid ${borderColor}; border-radius: 8px; background: ${bgColor}; 
                           color: ${textColor}; font-weight: bold; cursor: pointer; text-transform: uppercase;">
                    ${fase.label}
                </button>
                <div class="fase-times" style="display: flex; flex-direction: column; font-family: monospace; font-size: 1rem; min-width: 45px; color: #666; line-height: 1.1; text-align: center;">
                    <span id="start-${fase.id}">${orari.inizio}</span>
                    ${fase.tipo !== 'end' ? `<span id="end-${fase.id}" style="font-size: 0.9rem; color: #999;">${orari.fine}</span>` : ''}
                </div>
            </div>`;
    }).join('');

    content.innerHTML = `
        <h2 style="margin-bottom: 12px; text-align:center; font-size: 1.4rem;">Cronologia Partita</h2>
        <div id="fasiContainer" style="margin-bottom: 10px;">${htmlFasi}</div>
        
        <div id="containerEditing" style="margin-bottom: 15px; text-align: center; display: none;">
            <button id="btnEditingMode" data-editing="false" 
                style="width: 100%; padding: 10px; border-radius: 8px; border: 2px solid #f39c12; 
                       background: white; color: #f39c12; font-weight: bold; cursor: pointer; transition: all 0.3s;">
                <i class="fas fa-edit"></i> ATTIVA EDITING
            </button>
        </div>

        <div id="labelHighlights" style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 20px; opacity: 0.4;">
            <input type="checkbox" id="checkHighlights" disabled style="transform: scale(1.3); cursor: pointer;">
            <label for="checkHighlights" style="font-weight: bold; color: #333; cursor: pointer;">Abilita highlights</label>
        </div>

        <div style="display: flex; justify-content: center; gap: 20px; padding-bottom: 10px;">
            <button id="liveSaveBtn" class="convocazioniPopup-confirmBtn">Salva</button>
            <button id="liveCancelBtn" class="convocazioniPopup-closeBtn">Annulla</button>
        </div>
        <style>
            .btn-fase.active[data-tipo="q"], .btn-fase.active[data-tipo="ot"] { background-color: #dc3545 !important; color: white !important; border-color: #a71d2a !important; }
            .btn-fase.active[data-tipo="int"] { background-color: #6c757d !important; color: white !important; border-color: #495057 !important; }
            .btn-fase.active[data-tipo="end"] { background-color: #0056b3 !important; color: white !important; border-color: #004085 !important; }
            .btn-fase:disabled { filter: grayscale(1); cursor: not-allowed; }
        </style>`;

    overlay.appendChild(content);
    document.body.appendChild(overlay);

    const bottoniFase = content.querySelectorAll('.btn-fase');
    const btnEditingMode = content.querySelector('#btnEditingMode');
    const checkHighlights = content.querySelector('#checkHighlights');
    let faseSelezionata = window.statoPartita || "I0";
    
    if (tempiGara.highlights === true) checkHighlights.checked = true;
    if (window.isEditingMode === true) toggleEditingState(btnEditingMode, true);

    bottoniFase.forEach(btn => { if (btn.dataset.fase === faseSelezionata) btn.classList.add('active'); });
    aggiornaStatoBottoni(content);

    btnEditingMode.onclick = () => toggleEditingState(btnEditingMode);

    bottoniFase.forEach((btn, index) => {
        btn.onclick = () => {
            if (btn.disabled) return;
            const idFaseAttuale = btn.dataset.fase;
            let ora = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
            if (window.RECORD_EVENTS_A_POSTERIORI)
                ora = window.orarioVisualizzatoFormattato.substring(0,5); // PER CREARE GLI EVENTI A POSTERIORI IN BASE AL TEMPO DEL VIDEO YOUTUBE

            const oraAttuale = (idFaseAttuale.startsWith("Q") || idFaseAttuale === "I0") 
                ? ora
                : getOraArrotondata(true);

            bottoniFase.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            faseSelezionata = idFaseAttuale;

            document.getElementById(`start-${idFaseAttuale}`).innerText = oraAttuale;
            if (!tempiGara[idFaseAttuale]) tempiGara[idFaseAttuale] = {};
            tempiGara[idFaseAttuale].inizio = oraAttuale;

            if (idFaseAttuale === "Terminata") {
                // Logica chiusura fase precedente
                let ultimaFaseValidaId = null;
                for (let i = index - 1; i >= 0; i--) {
                    if (tempiGara[fasi[i].id]?.inizio && tempiGara[fasi[i].id]?.inizio !== "--:--") {
                        ultimaFaseValidaId = fasi[i].id;
                        break; 
                    }
                }
                if (ultimaFaseValidaId) {
                    const oraFine = getOraArrotondata(true);
                    document.getElementById(`end-${ultimaFaseValidaId}`).innerText = oraFine;
                    tempiGara[ultimaFaseValidaId].fine = oraFine;
                }
            } else if (index > 0) {
                const idPrev = fasi[index - 1].id;
                const oraFinePrev = idFaseAttuale.startsWith("I") ? getOraArrotondata(true) : oraAttuale;
                document.getElementById(`end-${idPrev}`).innerText = oraFinePrev;
                tempiGara[idPrev].fine = oraFinePrev;
            }
            aggiornaStatoBottoni(content);
        };
    });

    document.getElementById('liveCancelBtn').onclick = () => document.body.removeChild(overlay);

    document.getElementById('liveSaveBtn').onclick = () => {
        const isTerminata = (faseSelezionata === "Terminata");
        tempiGara.highlights = checkHighlights.checked;
        window.isEditingMode = btnEditingMode.dataset.editing === "true";

        const dati = {
            goLive: !isTerminata,
            quarto: faseSelezionata,
            terminata: isTerminata,
            noteTempi: JSON.stringify(tempiGara),
            editing: window.isEditingMode
        };

        if (typeof window.salvaStatoLive === "function") {
            window.salvaStatoLive(dati);
            if (typeof window.renderPlayerListLive === "function") window.renderPlayerListLive();
            if (typeof window.updateScoreboard === "function") window.updateScoreboard(!isTerminata);
        }
        document.body.removeChild(overlay);
    };
}

function toggleEditingState(btn, forceState = null) {
    let isEditing = forceState !== null ? forceState : btn.dataset.editing === "true";
    
    // Invertiamo lo stato se non forzato
    if (forceState === null) isEditing = !isEditing;

    if (isEditing) {
        btn.dataset.editing = "true";
        btn.style.background = "#f39c12"; // Arancione
        btn.style.color = "white";
        btn.innerHTML = '<i class="fas fa-lock-open"></i> EDITING ATTIVO';
        window.isEditingMode = true; // Variabile globale per la tua app
    } else {
        btn.dataset.editing = "false";
        btn.style.background = "white";
        btn.style.color = "#f39c12";
        btn.innerHTML = '<i class="fas fa-edit"></i> ATTIVA EDITING';
        window.isEditingMode = false;
    }
}

window.gestisciDirettaYoutube = gestisciDirettaYoutube;
function gestisciDirettaYoutube() {
  const overlay = document.createElement('div');
  overlay.id = 'youtubePopup';
  overlay.className = 'popup';

  const content = document.createElement('div');
  content.className = 'popup-content';
  content.style.textAlign = 'left';

  const urlIniziale = (typeof videoURL !== 'undefined') ? videoURL : "";
  const apiKeyCorrente = window.googleApiKey || "";
  const oraSalvatatYt = window.oraInizioDiretta;

  content.innerHTML = `
        <h2 style="margin-bottom: 20px; text-align:center;">Diretta Youtube</h2>
        
        <label style="display:block; font-size:1.6rem; margin-bottom: 5px;">URL:</label>
        <div style="display: flex; gap: 10px; margin-bottom: 15px;">
            <input type="text" id="ytUrl" style="flex: 1; padding:10px; font-size:1.4rem;" 
                   placeholder="https://www.youtube.com/watch?v=..." value="${urlIniziale}">
            <button id="ytSearchBtn" style="padding: 10px; font-size: 1.6rem; cursor: pointer; background-color: #3498db; color: white; border: none; border-radius: 5px;">
                Cerca
            </button>
        </div>

        <label style="display:block; font-size:1.6rem; margin-bottom: 5px;">Ora inizio Diretta (HH:mm:ss):</label>
        <div style="display: flex; gap: 10px; margin-bottom: 15px;">
            <input type="time" id="ytOraInizio" step="1" style="flex: 1; padding:10px; font-size:1.4rem;" value="${oraSalvatatYt}">
            <button id="ytCalcolaBtn" disabled style="padding: 10px; font-size: 1.6rem; cursor: not-allowed; opacity: 0.5; background-color: #3498db; color: white; border: none; border-radius: 5px;">
                Calcola
            </button>
        </div>

        <label style="display:block; font-size:1.6rem; margin-bottom: 5px;">Offset Inizio Partita (secondi):</label>
        <input type="number" id="ytOffset" style="width:100%; padding:10px; margin-bottom:15px; font-size:1.4rem;" 
               placeholder="Esempio: 30" value="${matchStartTime || ""}">

        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <input type="checkbox" id="ytRecordPosteriori" style="width: 20px; height: 20px; cursor: pointer;" 
                   ${window.RECORD_EVENTS_A_POSTERIORI ? 'checked' : ''}>
            <label for="ytRecordPosteriori" style="font-size: 1.4rem; cursor: pointer; user-select: none;">
                Usa tempo Youtube come TimeStamp eventi
            </label>
        </div>

        <label style="display:block; font-size:1.6rem; margin-bottom: 5px;">API Key:</label>
        <input type="text" id="ytApiKey" style="width:100%; padding:10px; margin-bottom:25px; font-size:1.4rem;" 
               placeholder="Inserisci la tua Google API Key" value="${apiKeyCorrente}">

        <div style="display: flex; justify-content: center; gap: 20px;">
            <button id="ytSaveBtn" class="convocazioniPopup-confirmBtn">Salva</button>
            <button id="ytCancelBtn" class="convocazioniPopup-closeBtn">Annulla</button>
        </div>
    `;
    
  overlay.appendChild(content);
  document.body.appendChild(overlay);

  const urlInput = document.getElementById('ytUrl');
  const calcolaBtn = document.getElementById('ytCalcolaBtn');
  const searchBtn = document.getElementById('ytSearchBtn');

  const validaUrl = (valore) => {
    const isValid = valore.startsWith('http://') || valore.startsWith('https://');
    calcolaBtn.disabled = !isValid;
    calcolaBtn.style.cursor = isValid ? 'pointer' : 'not-allowed';
    calcolaBtn.style.opacity = isValid ? '1' : '0.5';
  };

  validaUrl(urlInput.value.trim());
  urlInput.addEventListener('input', () => validaUrl(urlInput.value.trim()));

  // Collegamento funzioni ai bottoni
  calcolaBtn.onclick = () => calcolaOraInizioDirettaYoutube();
  searchBtn.onclick = () => searchYoutubeLive(); // Funzione richiesta

  document.getElementById('ytCancelBtn').onclick = () => {
    document.body.removeChild(overlay);
  };

  document.getElementById('ytSaveBtn').onclick = () => {
    // ... (resto del codice di salvataggio invariato)
    let finalUrl = urlInput.value.trim();
    const offsetValue = document.getElementById('ytOffset').value;
    const oraInizioValue = document.getElementById('ytOraInizio').value;
    const apiKeyValue = document.getElementById('ytApiKey').value.trim();

    if (offsetValue && parseInt(offsetValue) >= 0) {
      try {
        let urlObj = new URL(finalUrl);
        urlObj.searchParams.set("t", offsetValue + "s");
        urlObj.searchParams.delete("start");
        finalUrl = urlObj.toString();
      } catch (e) {
        if (!finalUrl.includes('t=') && !finalUrl.includes('start=')) {
          const separator = finalUrl.includes('?') ? '&' : '?';
          if (finalUrl !== "") finalUrl = `${finalUrl}${separator}t=${offsetValue}s`;
        } else {
          finalUrl = finalUrl.replace(/([?&])(t|start)=[^&]*/, `$1t=${offsetValue}s`);
        }
      }
    }

    videoURL = finalUrl;
    window.matchStartTime = offsetValue;
    window.googleApiKey = apiKeyValue;
    window.oraInizioDiretta = oraInizioValue;

    window.setLocalStorage("googleApiKey", apiKeyValue);
    window.setLocalStorage("matchStartTime", offsetValue);
    window.setLocalStorage("videoURL", finalUrl);
    window.setLocalStorage("oraInizioDiretta", window.oraInizioDiretta);

    window.dettagliGara.oraInizioDiretta = window.oraInizioDiretta;
    window.dettagliGara.videoURL = finalUrl;
    
    window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara);
    window.saveToServerMatchData();

    document.body.removeChild(overlay);
  };
}

async function searchYoutubeLive() {
    console.log("Ricerca YouTube Live avviata...");
    
    const apiKeyInserita = document.getElementById("ytApiKey").value.trim();
    
    if (!apiKeyInserita) {
        alert("Inserisci prima l'API Key per effettuare la ricerca.");
        return;
    }

    try {
        // Attendiamo il risultato della funzione asincrona
        const videoId = await window.getCurrentLiveIdByChannel(apiKeyInserita);
        
        // Costruiamo l'URL completo
        const liveVideoURL = `https://www.youtube.com/watch?v=${videoId}`;
        
        const messaggio = `Trovato Video Live: ${liveVideoURL}\nVuoi usare questo video?`;
        
        if (confirm(messaggio)) {
            const urlInput = document.getElementById('ytUrl');
            if (urlInput) {
                // Aggiorniamo il campo URL
                urlInput.value = liveVideoURL;

                // Trigger manuale dell'evento input per validare il tasto "Calcola"
                urlInput.dispatchEvent(new Event('input'));
                
                console.log("URL aggiornato con il video trovato:", liveVideoURL);
            }
        }
    } catch (error) {
        // Se getCurrentLiveIdByChannel lancia un errore (es. "canale non in live")
        console.error("Errore durante la ricerca:", error.message);
        alert(error.message);
    }
}

function calcolaOraInizioDirettaYoutube() {

  console.log("Eseguo il calcolo dell'ora dall'URL inserito...");

  // 1. Recuperiamo i valori aggiornati dai campi del popup
  const urlInserito = document.getElementById("ytUrl").value.trim();
  const apiKeyInserita = document.getElementById("ytApiKey").value.trim();
  const inputOraInizio = document.getElementById("ytOraInizio");

  // 2. Estraiamo il videoId dall'URL usando la funzione che abbiamo in common.js
  const videoId = window.extractVideoId(urlInserito);

  if (!videoId) {
    alert("URL YouTube non valido. Impossibile estrarre l'ID.");
    return;
  }

  if (!apiKeyInserita) {
    alert("Inserisci l'API Key per procedere al calcolo.");
    return;
  }

  // Cambiamo temporaneamente il testo del bottone per feedback all'utente
  const btn = document.getElementById("ytCalcolaBtn");
  const testoOriginale = btn.textContent;
  btn.textContent = "Attendere...";
  btn.disabled = true;

  // 3. Chiamiamo la funzione che interroga YouTube
  window.CheckYoutubeAndASave(videoId, apiKeyInserita).then(orario => {
    console.log("Orario inizio partita ricevuto:", orario);

    // 4. Inseriamo il risultato nell'input di tipo "time" del popup
    // orario è già in formato "HH:MM:SS" grazie alla modifica precedente
    inputOraInizio.value = orario;

    // Ripristiniamo il bottone
    btn.textContent = testoOriginale;
    btn.disabled = false;
  }).catch(err => {
    //console.error("Errore nel calcolo:", err);
    alert(err);
    //inputOraInizio.value = "00:00:00";
    btn.textContent = testoOriginale;
    btn.disabled = false;
  });
}

window.gestisciConvocazioni = gestisciConvocazioni;
function gestisciConvocazioni() {
  const giocatori = giocatoriA;
  const numeri = window.numeriMaglia;

  const existingPopup = document.getElementById("convocazioniPopup");
  if (existingPopup) existingPopup.remove();

  const popup = document.createElement("div");
  popup.id = "convocazioniPopup";
  popup.className = "convocazioniPopup-overlay";

  const content = document.createElement("div");
  content.className = "convocazioniPopup-content";

  const title = document.createElement("h2");
  title.textContent = "Convocazioni";
  content.appendChild(title);

  const list = document.createElement("ul");
  list.id = "convocazioniList"; // ID per recuperarlo facilmente
  list.className = "convocazioniPopup-list";
  list.style.maxHeight = "600px";
  list.style.overflowY = "auto";
  list.style.overflowX = "hidden";
  list.style.paddingRight = "10px";
  list.style.listStyle = "none";

  // 1. Mappatura iniziale
  let datiGiocatori = giocatori.map((nomeCompleto, index) => {
    const parts = nomeCompleto.trim().split(" ");
    const nome = parts[0];
    const cognome = parts.slice(1).join(" ");
    return {
      index: index,
      nome: nome,
      cognome: cognome,
      visuale: `${cognome} ${nome}`,
      numeroMaglia: numeri[index],
      selezionato: false // Stato iniziale
    };
  })
  // FILTRO: Escludi la Squadra B dalla lista delle convocazioni
  .filter(g => g.numeroMaglia !== ""); // SQUADRA B

  // 2. Recupero convocati salvati per impostare lo stato 'selezionato' iniziale
  let convocatiNum = [];
  if (typeof window.convocazioni !== 'undefined' && window.convocazioni.trim() !== "") {
    try {
      const parsed = JSON.parse(window.convocazioni);
      convocatiNum = Array.isArray(parsed) ? parsed.map(n => Number(n)) : [];
    } catch (e) { console.error("Errore parse convocazioni", e); }
  }
  
  datiGiocatori.forEach(g => {
    if (convocatiNum.includes(Number(g.numeroMaglia))) g.selezionato = true;
  });

  // 3. Funzione per renderizzare la lista ordinata
  const renderList = () => {
    list.innerHTML = ""; // Svuota la lista

    // Ordinamento: Prima i selezionati, poi alfabetico per cognome
    datiGiocatori.sort((a, b) => {
      if (a.selezionato === b.selezionato) {
        return a.cognome.localeCompare(b.cognome);
      }
      return a.selezionato ? -1 : 1;
    });

    datiGiocatori.forEach((item) => {
      const li = document.createElement("li");
      li.className = "convocazioniPopup-item";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.id = `conv_${item.index}`;
      checkbox.checked = item.selezionato;

      // Al cambio, aggiorna lo stato nel database locale 'datiGiocatori' e ri-renderizza
      checkbox.onchange = () => {
        item.selezionato = checkbox.checked;
        renderList(); 
      };

      const label = document.createElement("label");
      label.htmlFor = `conv_${item.index}`;
      label.innerHTML = `
        <span class="conv-num">${item.numeroMaglia}</span>
        <span class="conv-name">${item.visuale}</span>
      `;

      li.appendChild(checkbox);
      li.appendChild(label);
      list.appendChild(li);
    });
  };

  // Esegui il primo render
  renderList();
  content.appendChild(list);

  // Bottoni Azione
  const buttonsContainer = document.createElement("div");
  buttonsContainer.className = "convocazioniPopup-buttons";

  const confirmBtn = document.createElement("button");
  confirmBtn.textContent = "Salva";
  confirmBtn.className = "convocazioniPopup-confirmBtn";
  confirmBtn.onclick = () => {
    // Filtra solo quelli che risultano selezionati nell'array datiGiocatori
    const selezionati = datiGiocatori
      .filter(g => g.selezionato)
      .map(g => Number(g.numeroMaglia));

    // 2. ORDINA l'array dei numeri in modo ascendente prima del salvataggio
    selezionati.sort((a, b) => a - b);      
    
    window.convocazioni = JSON.stringify(selezionati);
    window.setLocalStorage("convocazioni", window.convocazioni);

    window.dettagliGara.convocazioni = window.convocazioni;
    window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara); 

    window.saveToServerMatchData();
    popup.remove();
    setTimeout(() => location.reload(), 2000);
  };

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "Annulla";
  closeBtn.className = "convocazioniPopup-closeBtn";
  closeBtn.onclick = () => popup.remove();

  buttonsContainer.append(confirmBtn, closeBtn);
  content.appendChild(buttonsContainer);
  popup.appendChild(content);
  document.body.appendChild(popup);
}

