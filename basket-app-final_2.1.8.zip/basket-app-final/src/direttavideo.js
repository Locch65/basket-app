window.RECORD_EVENTS_A_POSTERIORI = false; // se true serve per CREARE GLI EVENTI A POSTERIORI IN BASE AL TEMPO DEL VIDEO YOUTUBE. E' modificabile dal popup "Diretta Youtube"

window.NEW_PLAYER_INTERFACE = true; // visualizza il poster al posto del video e pretende il "Play" esplicito

//#region VARIABILI GLOBALI
// @ts-check
window.REFRESH_TIME = 300;
let ACCEPTABLE_DELAY_FOR_TOAST = 2; // secondi di ritardo accettabili per visualizzare il toast del punto realizzato

window.player;
window.timelineInterval;
let punteggioA = 0;
let punteggioB = 0;
let lastScoreStr = "";
let isUserLive = true;

window.orarioVisualizzatoFormattato = null;
window.systemClockVisualizzato = null;
window.fullMatchHistory = []; // Qui salviamo tutto il liveData ricevuto
window.videoId = null;
window.videoURL = "";
window.dettagliGara = null;
window.livePipData = [];
window.matchStartTime = 0;
let matchIsLive = false;
window.isReviewMode = false;
window.isEditingMode = false;
let wasPaused = false;
let pauseStartTime = null;
let tickCounter = 0;
let SYNC_TIME = null;
window.highlightsAvailable = false; // Di default la sezione è nascosta
let isFetching = false; // Impedisce chiamate sovrapposte
let hudPositionIndex = 1; // Partiamo dal 50% (centro)
let timePositionIndex = 0; // in alto a sinistra
let isFirstLoad = true; 
let isToastRunning = false; // Variabile di controllo per la durata del flash
let isSyncPending = false; // Indica se c'è un evento SYNC già visualizzato ma non ancora gestito
let adminSortMode = 'cognome'; // Valori: 'numero', 'cognome', 'punti'
window.convocazioni = "";
let puntiSquadraA = 0;
let puntiSquadraB = 0;
let puntiSquadraA_NelTempo = 0;
let puntiSquadraA_N0 = 0;
let puntiSquadraA_N1 = 0;
let puntiSquadraA_N2 = 0;
let puntiSquadraA_N3 = 0;
let puntiSquadraB_NelTempo = 0;
let historyB = [];
let contatoriB = { 0: 0, 1: 0, 2: 0, 3: 0 }; // Aggiunto 0
let statsQuintetti = []; // Array globale per statistiche quintetti
let ultimoOrdinamento = "numero";
let score = 0;
let scoreB = 0;
let listaGiocatoriCorrente = []; // per ricaricare la lista dopo login
window.matchId = null;
window.teamA = "";
window.teamB = "";
let squadraAvversaria = "";
let isLive = false;
window.oraInizioDiretta = "";
window.statoPartita = "";
let lastScoreState = "";
let lastQuartoState = "";
window.quartoAttuale = ""; // Variabile globale per il quarto attuale
window.googleApiKey = "";

let refreshTimer = null; // variabile globale per l'ID del timer

let chartEvoluzione = null; // serve per la gestione del grafico

const hudLabel = document.getElementById("hud-label");
const urlParams = new URLSearchParams(window.location.search);

window.matchId = urlParams.get("matchId");

window.giocatoriObj = [];

window.giocatoriObj = giocatoriA.map((nomeCompleto, index) => {
  const [nome, cognome] = nomeCompleto.split(" ");
  return {
    id: `${cognome}_${nome}`,
    numero: window.numeriMaglia[index],
    nome,
    cognome,
    displayName: `${cognome} ${nome}`,
    punti: 0,
    contatori: { 0: 0, 1: 0, 2: 0, 3: 0 }, // Aggiunto 0 qui
    history: [], // Qui verranno inseriti oggetti {punti: X, ora: "HH:mm:ss"}
    stato: "Out"
  };
});

//#endregion

function registerToFirebaseEvents() {
  if (!window.USE_FIREBASE) return;

  console.log("Connessione alla partita in corso...");

  // Ci mettiamo in ascolto sul percorso 'partite/matchId'
  let newPath = window.APP_VERSION.startsWith("1.") ? 'partite/' : window.getTeamId() + "/" + 'partite/';

//  window.db.ref('partite/' + window.matchId).on('value', (snapshot) => {
  window.db.ref(newPath + window.matchId).on('value', (snapshot) => {
    const data = snapshot.val();

    let videoURLChanged = false;
    if (window.dettagliGara !== null) {
      videoURLChanged = (window.dettagliGara?.videoURL ?? "") !== (data?.videoURL ?? "");    

    }

    if (data) {
      window.dettagliGara = data;
      window.quartoAttuale = window.dettagliGara.statoPartita.replace("*","");
      window.dettagliGara.statoPartita = window.dettagliGara.statoPartita.replace("*","");
      window.isEditingMode = window.dettagliGara.statoPartita.includes("*");

      window.videoId =  window.extractVideoId(window.dettagliGara.videoURL); //?? ATTENZIONE AGGIUNTA 11/06

      console.log("Dati ricevuti da Firebase:", data);
    } else {
      window.dettagliGara = null;
      console.warn("Nessun dettaglio trovato per questa partita.");
    }

    const struct = {
      statisticheGiocatori: window.giocatoriObj,
      dettagliGara: window.dettagliGara,
      liveData: window.fullMatchHistory,
      livePIP: window.livePipData // Includiamo i dati PIP attuali
    }

    updateDatiPartita("match", struct)

    // se è cambiato il videoURL (ad es. perchè prima era vuoto e adesso è definito), fai il reload dell'interfaccia
    if (videoURLChanged && matchIsLive)
    {
      location.reload();
    }

  }, (error) => {
    console.error("Errore di lettura:", error);
  });

  newPath = window.APP_VERSION.startsWith("1.") ? 'statistiche/' : window.getTeamId() + "/" + 'statistiche/';
//  window.db.ref('statistiche/' + window.matchId).on('value', (snapshot) => {
  window.db.ref(newPath + window.matchId).on('value', (snapshot) => {
    const data = snapshot.val();

    if (data) {
      window.giocatoriObj = data;
      console.log("Dati ricevuti:", data);
    } else {
      window.giocatoriObj = [];
      console.warn("Nessuna statistica trovata per questa partita.");
    }

    const struct = {
      statisticheGiocatori: window.giocatoriObj,
      dettagliGara: window.dettagliGara,
      liveData: window.fullMatchHistory
    }

    updateDatiPartita("stats", struct)

  }, (error) => {
    console.error("Errore di lettura:", error);
  });

  newPath = window.APP_VERSION.startsWith("1.") ? 'events/' : window.getTeamId() + "/" + 'events/';
//  window.db.ref('events/' + window.matchId).on('value', (snapshot) => {
  window.db.ref(newPath + window.matchId).on('value', (snapshot) => {
    const data = snapshot.val();

    if (data) {
      window.fullMatchHistory = data;
      console.log("Dati ricevuti:", data);
    } else {
      window.fullMatchHistory = [];
      console.warn("Nessun evento live trovato per questa partita.");
    }

    const struct = {
      statisticheGiocatori: window.giocatoriObj,
      dettagliGara: window.dettagliGara,
      liveData: window.fullMatchHistory
    }

    updateDatiPartita("events", struct)

  }, (error) => {
    console.error("Errore di lettura:", error);
  });

  // --- NUOVO ASCOLTATORE: livePIPs ---
  newPath = window.APP_VERSION.startsWith("1.") ? 'livePIPs/' : window.getTeamId() + "/" + 'livePIPs/';
//  window.db.ref('livePIPs/' + window.matchId).on('value', (snapshot) => {
  window.db.ref(newPath + window.matchId).on('value', (snapshot) => {
    const data = snapshot.val();
    
    if (data) {
      // Firebase restituisce un oggetto o un array. Lo convertiamo in array se necessario.
      let rawList = Array.isArray(data) ? data : Object.values(data);
      
      // Aggiorniamo la variabile globale ordinandola per timestamp (HH:mm:ss)
      window.livePipData = rawList.sort((a, b) => {
        if (a.timestamp < b.timestamp) return -1;
        if (a.timestamp > b.timestamp) return 1;
        return 0;
      });
      
      console.log("📍 livePipData aggiornato da Firebase:", window.livePipData);
    } else {
      window.livePipData = [];
      console.warn("Nessuna configurazione PiP trovata su Firebase.");
    }

    // Notifichiamo il sistema del cambiamento (opzionale, se updateDatiPartita deve reagire)
    const struct = {
      statisticheGiocatori: window.giocatoriObj,
      dettagliGara: window.dettagliGara,
      liveData: window.fullMatchHistory,
      livePIP: window.livePipData
    };
    
    // Possiamo usare "match" o un flag custom per rinfrescare la logica PiP
    updateDatiPartita("match", struct);

  }, (error) => {
    console.error("Errore lettura livePIPs:", error);
  });

}


function aggiornaPunteggio(target, valore) {
  const isNumeric = !isNaN(parseFloat(valore)) && isFinite(valore);
  let oraCorrente = new Date().toLocaleTimeString('it-IT'); 
    
  if (window.RECORD_EVENTS_A_POSTERIORI)
    oraCorrente = window.orarioVisualizzatoFormattato; // PER CREARE GLI EVENTI A POSTERIORI IN BASE AL TEMPO DEL VIDEO YOUTUBE

  // --- COSTRUZIONE DEL JSON PER IL CAMPO NOTE ---
  const noteObj = {
    quintetto: window.getNumeriGiocatoriIn(), // I numeri dei giocatori attualmente in campo
    quarto: window.quartoAttuale        
  };
  
  // Trasformiamo l'oggetto in una stringa JSON
  const noteJSON = JSON.stringify(noteObj);

  if (isNumeric) {
    const punti = parseInt(valore);
    target.punti += punti;

    // Gestione contatori (solo per i punti)
    if (target.contatori[punti] === undefined) target.contatori[punti] = 0;
    target.contatori[punti]++;

    target.history.push({ punti: punti, ora: oraCorrente, type: "punto", note: noteJSON });
  } else if (valore === "Fallo") {
    // Calcola quanti falli ha già commesso il giocatore e aggiunge 1
    const falliAttuali = target.history.filter(ev => ev.type === "Fallo").length;
    const falliTotali = falliAttuali + 1;
    target.falliTotaliCorrenti = falliTotali;

    // Registra l'evento Fallo con il nuovo campo falliTotali
    target.history.push({ stato: valore, ora: oraCorrente, type: "Fallo", falliTotali: falliTotali, note: noteJSON });
  } else {
    // Gestione eventi In / Out
    target.history.push({ stato: valore, ora: oraCorrente, type: "InOut", note: noteJSON });
  }
}

function AddPuntiGiocatore(id, valore) {
  const g = window.giocatoriObj.find(x => x.id === id);
  aggiornaPunteggio(g, valore);

  const ultimaAzione = g.history[g.history.length - 1];
  const timestampReale = ultimaAzione.ora;

  // Il valore salvato sarà il numero o la stringa specifica (In/Out/Fallo)
  const datoDaSalvare = (ultimaAzione.type === "punto") ? valore : ultimaAzione.stato;

  window.saveToServerEventoLive(g.numero, datoDaSalvare, timestampReale, window.getTeamName(g.numero), "save");

  console.log(`Evento ${ultimaAzione.type} registrato per ${g.cognome}:`, datoDaSalvare);
}

function undoEvent(target, eventToRemove) {
  if (!eventToRemove || target.history.length === 0) return;


  let index = -1;
  // Cerchiamo l'indice dell'evento specifico basandoci sull'oggetto passato
  // (che solitamente contiene l'ora e il tipo di evento per essere identificato)
  if (eventToRemove.type === "Fallo") {
    index = target.history.findIndex(ev => 
      ev.ora === eventToRemove.ora && 
      ev.type === eventToRemove.type);
  }
  else if (eventToRemove.type === "punto") {
    index = target.history.findIndex(ev => 
      ev.ora === eventToRemove.ora && 
      ev.type === eventToRemove.type &&
      ev.punti === eventToRemove.punti);
  }
  else if (eventToRemove.type === "InOut") {
    index = target.history.findIndex(ev => 
      ev.ora === eventToRemove.ora && 
      ev.type === eventToRemove.type &&
      ev.stato === eventToRemove.stato);
  }

  if (index !== -1) {
    const removedEvent = target.history.splice(index, 1)[0];

    // Se l'evento rimosso era un "punto", dobbiamo scalare il punteggio totale e il contatore
    if (removedEvent.type === "punto") {
      const punti = removedEvent.punti;
      if (target.punti > 0) target.punti -= punti;
      if (target.contatori[punti] > 0) {
        target.contatori[punti]--;
      }
    } else if (removedEvent.type === "Fallo") {
      target.falliTotaliCorrenti--;
    }
    
    return true; // Indica che la rimozione è avvenuta con successo
  }
  
  return false;
}

function undoPuntiGiocatore(id, evento) {
  const g = window.giocatoriObj.find(x => x.id === id);
  if (!g || g.history.length <= 0) return 0;

  // Se l'evento non è passato, prendiamo l'ultimo dalla history del giocatore
  const azioneDaAnnullare = (evento !== undefined) ? evento : g.history[g.history.length - 1];
  const timestampReale = azioneDaAnnullare.ora;
  
  let valorePerServer;

  // Gestione dinamica del valore in base al nuovo campo "type"
  if (azioneDaAnnullare.type === "punto") {
      // Per i punti, inviamo il valore negativo per sottrarli sul server
      valorePerServer = -azioneDaAnnullare.punti;
  } else if (azioneDaAnnullare.type === "Fallo" || azioneDaAnnullare.type === "InOut" || azioneDaAnnullare.type === "stato") {
      // Per i falli e gli stati, inviamo la stringa originale (es. "Fallo", "In", "Out")
      // Il server gestirà l'eliminazione basandosi sulla stringa e sul timestamp
      valorePerServer = azioneDaAnnullare.stato || azioneDaAnnullare.punti; 
  }

  // Chiamata alla logica locale per decrementare i contatori (inclusi i falli nel contatore [0])
  undoEvent(g, azioneDaAnnullare); 
  
  // Sincronizzazione con il server
  window.saveToServerEventoLive(g.numero, valorePerServer, timestampReale, window.getTeamName(g.numero), "undo");

  console.log(`Annullato evento ${azioneDaAnnullare.type} per ${g.cognome}`);

  return azioneDaAnnullare.type === "punto" ? azioneDaAnnullare.punti : 0;
}

function AddPuntiSquadraB(valore, memorizzaOrario) {
  const isNumeric = !isNaN(parseFloat(valore)) && isFinite(valore);
  let oraCorrente = memorizzaOrario ? new Date().toLocaleTimeString('it-IT') : "??";

  if (window.RECORD_EVENTS_A_POSTERIORI)
    oraCorrente = window.orarioVisualizzatoFormattato; // PER CREARE GLI EVENTI A POSTERIORI IN BASE AL TEMPO DEL VIDEO YOUTUBE
  
  let tipoEvento = "punto";
  if (!isNumeric) {
    if (valore === "Fallo") tipoEvento = "Fallo";
    else if (valore === "In" || valore === "Out") tipoEvento = "InOut";
    else tipoEvento = "stato";
  }

  if (tipoEvento === "punto") {
    const punti = parseInt(valore);
    puntiSquadraB += punti;
    if (contatoriB[punti] !== undefined) contatoriB[punti]++;
    
    historyB.push({ punti: punti, ora: oraCorrente, type: "punto" });
  } else {
    // Gestione Fallo, InOut o altri stati
    historyB.push({ punti: valore, ora: oraCorrente, type: tipoEvento });
  }
}

function undoPuntiSquadraB(eventToRemove) {
  if (historyB.length === 0) return;

  const azioneDaAnnullare = (eventToRemove !== undefined) ? eventToRemove : historyB[historyB.length - 1];
  
  const index = historyB.findIndex(ev => 
    ev.ora === azioneDaAnnullare.ora && ev.punti === azioneDaAnnullare.punti && ev.type === azioneDaAnnullare.type
  );

  if (index !== -1) {
    const removedEntry = historyB.splice(index, 1)[0];

    if (removedEntry.type === "punto") {
      const puntiDaTogliere = parseInt(removedEntry.punti);
      if (puntiSquadraB > 0) puntiSquadraB -= puntiDaTogliere;
      if (contatoriB[puntiDaTogliere] !== undefined && contatoriB[puntiDaTogliere] > 0) contatoriB[puntiDaTogliere]--;

    }
    console.log(`Rimosso evento ${removedEntry.type} Squadra B`);
  }
}

//#region GESTIONE DATABASE & HISTORY
window.mostraPopupQuintetti = mostraPopupQuintetti;
function mostraPopupQuintetti() {
    const vecchioPopup = document.getElementById('popupStatsQuintetti');
    if (vecchioPopup) vecchioPopup.remove();

    calcolaStatisticheQuintetti();

    // 1. Estraiamo i numeri univoci dai quintetti
    const numeriInCampo = [...new Set(
        statsQuintetti.flatMap(q => q.quintetto.replace(/[\[\]\s]/g, '').split(','))
    )].sort((a, b) => a - b);

    // 2. Creiamo le opzioni della tendina con Numero + Cognome
    const opzioniGiocatori = numeriInCampo.map(num => {
        const g = window.giocatoriObj.find(player => String(player.numero) === String(num));
        const cognome = g ? g.cognome : "N.D.";
        return `<option value="${num}">#${num} - ${cognome}</option>`;
    }).join('');

    const overlay = document.createElement('div');
    overlay.id = 'popupStatsQuintetti';
    overlay.style.cssText = `
        position: fixed; top: 0px; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.92); z-index: 200000;
        display: flex; justify-content: center; align-items: center;
        backdrop-filter: blur(3px);
    `;

    const container = document.createElement('div');
    container.style.cssText = `
        background: #1e1e1e; border: 2px solid #27ae60; border-radius: 15px;
        width: 95%; max-width: 600px; max-height: 85vh; overflow: hidden;
        display: flex; flex-direction: column; color: white; font-family: sans-serif;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    `;

    container.innerHTML = `
        <div style="padding: 15px; border-bottom: 1px solid #333; text-align: center;">
            <h3 style="margin: 0; color: #27ae60; text-transform: uppercase; font-size: 1.8rem;">Analisi Quintetti</h3>
            
            <div style="margin-top: 15px; display: flex; flex-direction: column; align-items: center; gap: 10px;">
                <div style="display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 10px;">
                    
                    <select id="selectFiltroGiocatore" 
                        style="background: #333; border: 2px solid #27ae60; color: white; padding: 12px; border-radius: 8px; font-size: 1.1rem; flex: 1; min-width: 0;"
                        onchange="filtraTabellaPerGiocatore(this.value)">
                        <option value="">-- Giocatore --</option>
                        ${opzioniGiocatori}
                    </select>

                    <div id="displayMinutiGiocatore" style="background: #27ae60; color: white; padding: 8px 12px; border-radius: 8px; text-align: center; min-width: 80px; display: none;">
                        <small style="font-size: 0.6rem; display: block; text-transform: uppercase; line-height: 1;">Minuti</small>
                        <b id="valoreMinuti" style="font-size: 1.3rem;">0:00</b>
                    </div>

                    <div id="displayPerfGiocatore" style="background: #2980b9; color: white; padding: 8px 12px; border-radius: 8px; text-align: center; min-width: 80px; display: none; margin-left: 5px;">
                        <small style="font-size: 0.6rem; display: block; text-transform: uppercase; line-height: 1;">Perf Ind.</small>
                        <b id="valorePerfInd" style="font-size: 1.3rem;">0.0</b>
                    </div>

                    <button onclick="document.getElementById('selectFiltroGiocatore').value=''; filtraTabellaPerGiocatore('')" 
                        style="background: #e74c3c; color: white; border: none; padding: 12px 15px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 1.2rem;">
                        <i class="fas fa-undo"></i>
                    </button>
                </div>
            </div>
        </div>

        <div style="flex: 1; overflow-y: auto; padding: 5px;">
            <table id="tableQuintetti" style="width: 100%; border-collapse: collapse; font-size: 1.2rem;">
                <thead>
                    <tr style="background: #2c3e50; color: #27ae60; cursor: pointer;">
                        <th onclick="sortTabellaQuintetti(0)" style="padding: 10px 5px; border: 1px solid #333;">ID</th>
                        <th onclick="sortTabellaQuintetti(1)" style="padding: 10px 2px; border: 1px solid #333;">Min</th>
                        <th onclick="sortTabellaQuintetti(2)" style="padding: 10px 2px; border: 1px solid #333;">F</th>
                        <th onclick="sortTabellaQuintetti(3)" style="padding: 10px 2px; border: 1px solid #333;">S</th>
                        <th onclick="sortTabellaQuintetti(4)" style="padding: 10px 2px; border: 1px solid #333;">+/-</th>
                        <th onclick="sortTabellaQuintetti(5)" style="padding: 10px 2px; border: 1px solid #333;">Perf</th>
                    </tr>
                </thead>
                <tbody id="bodyQuintetti">
                    ${generaRigheTabella(statsQuintetti)}
                </tbody>
            </table>
        </div>

        <div id="dettaglioGiocatoriQuintetto" style="padding: 12px; background: #151515; border-top: 2px solid #27ae60; min-height: 80px; text-align: center;">
            <div style="color: #666; font-size: 1.2rem; font-style: italic;">Seleziona una riga per vedere i nomi</div>
        </div>

        <div style="padding: 15px; text-align: center; border-top: 1px solid #333;">
            <button onclick="document.getElementById('popupStatsQuintetti').remove()" 
                style="justify-content: center; background: #27ae60; color: white; border: none; padding: 15px 60px; 
                border-radius: 8px; font-weight: bold; cursor: pointer; text-transform: uppercase; font-size: 1.1rem;">
                CHIUDI
            </button>
        </div>
    `;

    overlay.appendChild(container);
    document.body.appendChild(overlay);
}

window.filtraTabellaPerGiocatore = filtraTabellaPerGiocatore;
function filtraTabellaPerGiocatore(numero) {
    const rows = document.querySelectorAll("#bodyQuintetti tr");
    const numCercato = numero.trim();
    const areaDettaglio = document.getElementById('dettaglioGiocatoriQuintetto');
    const displayMinuti = document.getElementById('displayMinutiGiocatore');
    const valoreMinuti = document.getElementById('valoreMinuti');
    
    let secondiTotaliGiocatore = 0;

    // Reset area nomi
    if (areaDettaglio) {
        areaDettaglio.innerHTML = `<div style="color: #666; font-size: 1.2rem; font-style: italic;">Seleziona una riga per vedere i nomi</div>`;
    }

    rows.forEach(row => {
        const quintettoStr = row.cells[0].innerText;
        const numeriInQuintetto = quintettoStr.replace(/[\[\]\s]/g, '').split(',');
        const secondiQuintetto = parseInt(row.cells[6].innerText) || 0;

        row.style.background = "transparent";
        row.style.borderLeft = "none";

        if (numCercato !== "" && numeriInQuintetto.includes(numCercato)) {
            row.style.background = "rgba(39, 174, 96, 0.35)"; 
            row.style.borderLeft = "5px solid #27ae60"; 
            secondiTotaliGiocatore += secondiQuintetto;
        }
    });

    // Gestione del box minuti in alto
    if (numCercato !== "" && secondiTotaliGiocatore > 0) {
        const min = Math.floor(secondiTotaliGiocatore / 60);
        const sec = secondiTotaliGiocatore % 60;
        valoreMinuti.innerText = `${min}:${sec < 10 ? '0' : ''}${sec}`;
        displayMinuti.style.display = "block"; // Mostra il box
    } else {
        displayMinuti.style.display = "none"; // Nasconde se non c'è selezione
    }
}

window.mostraNomiGiocatori = mostraNomiGiocatori;
function mostraNomiGiocatori(quintettoString) {
    const areaDettaglio = document.getElementById('dettaglioGiocatoriQuintetto');
    const numeri = quintettoString.replace(/[\[\]\s]/g, '').split(',');
    
    let htmlNomi = `
        <div style="font-size: 1rem; color: #27ae60; margin-bottom: 6px; text-transform: uppercase; font-weight: bold; letter-spacing: 1px;">
            Giocatori in campo:
        </div>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 4px;">`;
    
    numeri.forEach(num => {
        const g = window.giocatoriObj.find(player => String(player.numero) === String(num));
        const cognome = g ? g.cognome : "---";
        
        htmlNomi += `
            <div style="background: rgba(39, 174, 96, 0.1); border: 1px solid #27ae60; padding: 3px 5px; border-radius: 4px; width: 70px; flex-shrink: 0;">
                <div style="color: #27ae60; font-weight: bold; font-size: 1rem;">#${num}</div>
                <div style="font-size: 1.2rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    ${cognome}
                </div>
            </div>
        `;
    });
    
    htmlNomi += `</div>`;
    areaDettaglio.innerHTML = htmlNomi;
}

function generaRigheTabella(data) {
    return data.map(q => {
        const coloreDiff = q.differenza > 0 ? '#27ae60' : (q.differenza < 0 ? '#e74c3c' : '#fff');
        // Usiamo l'attributo onclick sulla riga
        return `
            <tr onclick="mostraNomiGiocatori('${q.quintetto}')" 
                style="border-bottom: 1px solid #333; text-align: center; cursor: pointer; transition: background 0.2s;"
                onmouseover="this.style.background='#2c3e50'" onmouseout="this.style.background='transparent'">
                <td style="padding: 10px 5px; color: #ffffff; font-size: 1.4rem; ">${q.quintetto}</td>
                <td>${q.tempoGara}</td>
                <td>${q.puntiFatti}</td>
                <td>${q.puntiSubiti}</td>
                <td style="font-weight: bold; color: ${coloreDiff}">${q.differenza > 0 ? '+' : ''}${q.differenza}</td>
                <td style="color: #f1c40f;">${q.performance.toFixed(2)}</td>
                <td style="display:none;">${q.secondiTotali}</td>
            </tr>
        `;
    }).join('');
}

// Funzione di ordinamento universale per la tabella
let sortDirection = 1; 
window.sortTabellaQuintetti = sortTabellaQuintetti;
function sortTabellaQuintetti(colIndex) {
    sortDirection *= -1;
    const table = document.getElementById("tableQuintetti");
    const tbody = document.getElementById("bodyQuintetti");
    const rows = Array.from(tbody.rows);

    rows.sort((a, b) => {
        let valA = a.cells[colIndex].innerText;
        let valB = b.cells[colIndex].innerText;

        // Se ordiniamo per Tempo (Colonna 1), usiamo i secondi totali (cella nascosta col 6)
        if (colIndex === 1) {
            valA = parseInt(a.cells[6].innerText);
            valB = parseInt(b.cells[6].innerText);
        } else if (colIndex > 1) {
            // Per le altre colonne numeriche
            valA = parseFloat(valA);
            valB = parseFloat(valB);
        }

        if (valA < valB) return -1 * sortDirection;
        if (valA > valB) return 1 * sortDirection;
        return 0;
    });

    tbody.innerHTML = "";
    rows.forEach(row => tbody.appendChild(row));
}

function calcolaStatisticheQuintetti() {
    const mappaQuintetti = {};
    const tempiGara = JSON.parse(window.dettagliGara?.note || '{}');

    const toSeconds = (str) => {
        if (!str || str === "--:--") return 0;
        const p = str.split(':');
        return (+p[0]) * 3600 + (+p[1]) * 60 + (+p[2] || 0);
    };

    // Mappatura per gestire gli intervalli
    const mappaQuarti = {
        "I1": "Q2",
        "I2": "Q3",
        "I3": "Q4",
        "I4": "OT1" // Nel caso di supplementari
    };

    let ultimoQuintettoKey = null;
    let ultimoQuartoVisto = "Q1";
    let timestampInizioSessione = tempiGara["Q1"]?.inizio ? toSeconds(tempiGara["Q1"].inizio) : 0;

    if (timestampInizioSessione === 0 && window.fullMatchHistory.length > 0) {
        timestampInizioSessione = toSeconds(window.fullMatchHistory[0].timestampReale);
    }

    window.fullMatchHistory.forEach((evento, index) => {
        let quintettoKey = "Sconosciuto";
        let quartoGrezzo = "Q1";

        try {
            if (evento.note) {
                const noteObj = typeof evento.note === 'string' ? JSON.parse(evento.note) : evento.note;
                if (noteObj.quintetto) quintettoKey = noteObj.quintetto.replace(/\s/g, "");
                if (noteObj.quarto) quartoGrezzo = noteObj.quarto;
            }
        } catch (e) { console.warn("Errore parsing note:", e); }

        // --- LOGICA CORREZIONE INTERVALLI ---
        // Se il quarto è un intervallo (I1, I2, ecc.), lo mappiamo al quarto successivo
        let quartoAttuale = mappaQuarti[quartoGrezzo] || quartoGrezzo;

        const tsEvento = toSeconds(evento.timestampReale);

        if (quintettoKey !== "Sconosciuto" && quintettoKey !== "[]") {
            if (!mappaQuintetti[quintettoKey]) {
                mappaQuintetti[quintettoKey] = { quintetto: quintettoKey, puntiFatti: 0, puntiSubiti: 0, secondiGiocati: 0 };
            }
        }

        // --- GESTIONE TEMPORALE ---
        
        // Cambio Quarto (Intervallo -> Nuovo Quarto)
        if (quartoAttuale !== ultimoQuartoVisto) {
            // Chiudiamo il tempo del vecchio quintetto alla fine del quarto precedente reale
            if (ultimoQuintettoKey && mappaQuintetti[ultimoQuintettoKey] && tempiGara[ultimoQuartoVisto]?.fine) {
                const tsFineQuartoPrecedente = toSeconds(tempiGara[ultimoQuartoVisto].fine);
                const durataFinoAFine = tsFineQuartoPrecedente - timestampInizioSessione;
                if (durataFinoAFine > 0) mappaQuintetti[ultimoQuintettoKey].secondiGiocati += durataFinoAFine;

            }

            // IMPORTANTE: Se siamo in un intervallo, il tempo di gioco non deve scorrere.
            // La nuova sessione partirà dall'inizio ufficiale del nuovo quarto.
            if (tempiGara[quartoAttuale]?.inizio) {
                timestampInizioSessione = toSeconds(tempiGara[quartoAttuale].inizio);
            } else {
                timestampInizioSessione = tsEvento;
            }

            ultimoQuartoVisto = quartoAttuale;
            ultimoQuintettoKey = quintettoKey; 
        }

        // Cambio Quintetto (solo se siamo dentro un quarto attivo)
        if (quintettoKey !== ultimoQuintettoKey) {
            if (ultimoQuintettoKey && mappaQuintetti[ultimoQuintettoKey]) {
                // Calcoliamo la durata solo se l'evento attuale non è "precedente" all'inizio del quarto
                // (Evita di contare tempo se un cambio avviene durante l'intervallo)
                const durata = tsEvento - timestampInizioSessione;
                if (durata > 0) mappaQuintetti[ultimoQuintettoKey].secondiGiocati += durata;

            }
            ultimoQuintettoKey = quintettoKey;
            timestampInizioSessione = Math.max(tsEvento, timestampInizioSessione);
        }


        // AGGIORNAMENTO PUNTI
        if (evento.eventType === "punto" && quintettoKey !== "Sconosciuto") {
            const puntiEvento = !isNaN(parseInt(evento.puntiRealizzati)) ? parseInt(evento.puntiRealizzati) : 0;
            if (puntiEvento > 0) {
                if (evento.squadra === 'Squadra B') {
                    mappaQuintetti[quintettoKey].puntiSubiti += puntiEvento;
                } else {
                    mappaQuintetti[quintettoKey].puntiFatti += puntiEvento;
                }
            }
        }

        // CHIUSURA FINALE
        if (index === window.fullMatchHistory.length - 1 && ultimoQuintettoKey && mappaQuintetti[ultimoQuintettoKey]) {
            const orarioFinePartita = tempiGara[quartoAttuale]?.fine ? toSeconds(tempiGara[quartoAttuale].fine) : tsEvento;
            const durataFinale = orarioFinePartita - timestampInizioSessione;
            if (durataFinale > 0) mappaQuintetti[ultimoQuintettoKey].secondiGiocati += durataFinale;
        }
    });

    // TRASFORMAZIONE E CALCOLO PERFORMANCE
    statsQuintetti = Object.values(mappaQuintetti)
        .filter(q => q.quintetto !== "Sconosciuto")
        .map(q => {
            const min = Math.floor(q.secondiGiocati / 60);
            const sec = q.secondiGiocati % 60;
            const diff = q.puntiFatti - q.puntiSubiti;
            let perf = q.secondiGiocati > 0 ? (diff / (q.secondiGiocati / 60)).toFixed(2) : 0;

            return {
                quintetto: q.quintetto,
                puntiFatti: q.puntiFatti,
                puntiSubiti: q.puntiSubiti,
                differenza: diff,
                tempoGara: `${min}:${sec.toString().padStart(2, '0')}`,
                performance: parseFloat(perf),
                secondiTotali: q.secondiGiocati
            };
        });

    statsQuintetti.sort((a, b) => b.performance - a.performance);
    console.log("Statistiche Quintetti (Correzione Intervalli):", statsQuintetti);
}

function generaHistory(liveDataDalBackend) {
  let scoreA = 0;
  let scoreB = 0;

  // Reset strutture locali
  historyB = [];
  contatoriB = { 0: 0, 1: 0, 2: 0, 3: 0 };
  window.giocatoriObj.forEach(g => { 
    g.history = []; 
    g.falliTotaliCorrenti = 0; // Supporto temporaneo per il calcolo progressivo
  });
  let falliSquadraBProgressivi = 0;

  if (!liveDataDalBackend || liveDataDalBackend.length === 0) {
    window.fullMatchHistory = window.giocatoriObj
      .filter(g => g.id !== "Squadra_B")
      .map(g => ({
        idGiocatore: g.numero,
        puntiRealizzati: 0,
        falliTotali: 0,       // Nuovo campo inizializzato a 0
        eventType: "punto",   // Default per inizializzazione
        squadra: window.MY_TEAM, 
        timestampReale: "00:00:00",
        secondiReali: 0,
        punteggioA: 0,
        punteggioB: 0
    }));
    window.highlightsAvailable = false;
    return;
  }

  window.fullMatchHistory = liveDataDalBackend
    .filter(evento => evento.squadra !== "SYNC")
    .map(evento => {
      const valRaw = evento.puntiRealizzati;
      const isNumeric = !isNaN(parseFloat(valRaw)) && isFinite(valRaw);
      
      // NUOVA LOGICA DI DETERMINAZIONE TIPO
      let type = "InOut";
      if (isNumeric) {
        type = "punto";
      } else if (valRaw === "Fallo") {
        type = "Fallo";
      }

      const punti = isNumeric ? parseInt(valRaw) : 0;
      let falliTotaliEvento = 0;

      if (evento.squadra === 'Squadra B') {
        scoreB += punti;
        if (type === "punto") {
          historyB.push({ punti: punti, ora: evento.timestampReale, type: "punto" });
          if (contatoriB[punti] !== undefined) contatoriB[punti]++;
        } else if (type === "Fallo") {
          falliSquadraBProgressivi++;
          falliTotaliEvento = falliSquadraBProgressivi;
          historyB.push({ stato: valRaw, ora: evento.timestampReale, type: "Fallo", falliTotali: falliTotaliEvento });
        } else {
          historyB.push({ stato: valRaw, ora: evento.timestampReale, type: "InOut" });
        }

        const giocatore = window.giocatoriObj.find(g => g.id === "Squadra_B");
        if (giocatore) {
          if (type === "punto") {
            giocatore.history.push({ punti: punti, ora: evento.timestampReale, type: "punto", note: evento.note });
          } else if (type === "Fallo") {
            giocatore.falliTotaliCorrenti++;
            falliTotaliEvento = giocatore.falliTotaliCorrenti;
            giocatore.history.push({ stato: valRaw, ora: evento.timestampReale, type: "Fallo", falliTotali: falliTotaliEvento, note: evento.note });
          } else {
            giocatore.history.push({ stato: valRaw, ora: evento.timestampReale, type: "InOut", note: evento.note });
          }
        }

      } else {
        scoreA += punti;
        const giocatore = window.giocatoriObj.find(g => g.id !== "Squadra_B" && String(g.numero) === String(evento.idGiocatore));
        if (giocatore) {
          if (type === "punto") {
            giocatore.history.push({ punti: punti, ora: evento.timestampReale, type: "punto", note: evento.note });
          } else if (type === "Fallo") {
            giocatore.falliTotaliCorrenti++;
            falliTotaliEvento = giocatore.falliTotaliCorrenti;
            giocatore.history.push({ stato: valRaw, ora: evento.timestampReale, type: "Fallo", falliTotali: falliTotaliEvento, note: evento.note });
          } else {
            giocatore.history.push({ stato: valRaw, ora: evento.timestampReale, type: "InOut", note: evento.note });
          }
        }
      }

      return {
        ...evento,
        eventType: type,
        puntiRealizzati: valRaw,
        falliTotali: falliTotaliEvento > 0 ? falliTotaliEvento : 0,
        secondiReali: hmsToSeconds(evento.timestampReale.replace("*", "")),
        punteggioA: scoreA,
        punteggioB: scoreB
      };
    });

  // 1. Trasformiamo la stringa in oggetto (se note è null, usa '{}')
  const config = JSON.parse(window.dettagliGara?.note || '{}');

  // 2. Verifichiamo se esiste la chiave e se è "true"
  if (config["highlights"] !== undefined) {
      // Usiamo String() per gestire sia il booleano true che la stringa "true"
      window.highlightsAvailable = String(config["highlights"]).toLowerCase() === "true";
  } else {
      window.highlightsAvailable = false;
  }
  if (window.statoPartita !== "Terminata") window.highlightsAvailable = true; // ATTENZIONE: test

}

function modifyHistory() {
  let allEvents = [];
  let tempFalliGiocatori = {}; // Per ricalcolare i progressivi durante l'unione
  let falliB = 0;

  // 1. Raccogli eventi della Squadra A
  window.giocatoriObj.forEach(g => {
    if (!tempFalliGiocatori[g.numero]) tempFalliGiocatori[g.numero] = 0;
    
    if (g.history && g.history.length > 0) {
      g.history.forEach(ev => {
        let ft = 0;
        if (ev.type === "Fallo") {
          tempFalliGiocatori[g.numero]++;
          ft = tempFalliGiocatori[g.numero];
        }

        allEvents.push({
          idGiocatore: g.numero,
          puntiRealizzati: ev.type === "punto" ? ev.punti : ev.stato,
          eventType: ev.type,
          falliTotali: ft > 0 ? ft : 0,
          squadra: g.id === "Squadra_B" ? "Squadra B" : window.MY_TEAM,
          timestampReale: ev.ora,
          secondiReali: hmsToSeconds(ev.ora.replace("*", "")),
          note: ev.note
        });
      });
    }
  });

  // 2. Raccogli eventi della Squadra B
  // if (false && typeof historyB !== 'undefined' && historyB.length > 0) { // ATTENZIONE??: disabilitato perchè usiamo giocatoriObj
  //   historyB.forEach(ev => {
  //     let ft = 0;
  //     if (ev.type === "Fallo") {
  //       falliB++;
  //       ft = falliB;
  //     }

  //     allEvents.push({
  //       idGiocatore: "Squadra B",
  //       puntiRealizzati: ev.type === "punto" ? ev.punti : ev.type,
  //       eventType: ev.type,
  //       falliTotali: ft > 0 ? ft : 0,
  //       squadra: 'Squadra B',
  //       timestampReale: ev.ora,
  //       secondiReali: hmsToSeconds(ev.ora.replace("*", "")),
  //       note: ev.note
  //     });
  //   });
  // }

  // 3. Ordina per tempo
  allEvents.sort((a, b) => a.secondiReali - b.secondiReali);

  // 4. Ricalcola i punteggi progressivi
  let runningScoreA = 0;
  let runningScoreB = 0;

  window.fullMatchHistory = allEvents.map(evento => {
    if (evento.eventType === "punto") {
      const p = parseInt(evento.puntiRealizzati) || 0;
      if (evento.squadra === 'Squadra B') runningScoreB += p;
      else runningScoreA += p;
    }

    return {
      ...evento,
      punteggioA: runningScoreA,
      punteggioB: runningScoreB
    };
  });

  punteggioA = runningScoreA;
  punteggioB = runningScoreB;

  if (matchIsLive) {
    // aggiorna anche i dettagliGara cosi' su Firebase finisce il risultato in realtime (e lo possiamo usare nel Calendario)
    if (window.isMyTeam(window.teamA)) {
      window.dettagliGara.punteggioA = punteggioA;
      window.dettagliGara.punteggioB = punteggioB;
    }
    else {
      window.dettagliGara.punteggioA = punteggioB;
      window.dettagliGara.punteggioB = punteggioA;
    }
  }

  console.log("History rigenerata. Eventi totali:", window.fullMatchHistory.length);
  window.highlightsAvailable = window.fullMatchHistory.length > 0;
}

function updateDatiPartita(what, data) {

  if (what === "all" || what === "match") {
      // 1. Estrazione dati
      window.dettagliGara = data.dettagliGara || {}
      matchIsLive = window.dettagliGara.isLive;
      window.oraInizioDiretta = window.dettagliGara.oraInizioDiretta;
      const config = JSON.parse(window.dettagliGara.note || '{}');

      // --- Caricamento e ordinamento LivePIP ---
      if (data.livePIP && Array.isArray(data.livePIP)) {
          // Creiamo una copia per non mutare l'originale e ordiniamo per timestamp crescente
          window.livePipData = [...data.livePIP].sort((a, b) => {
              if (a.timestamp < b.timestamp) return -1;
              if (a.timestamp > b.timestamp) return 1;
              return 0;
          });
          console.log("✅ livePipData caricato e ordinato:", window.livePipData);
      } else {
          window.livePipData = [];
      }

      // 2. Lettura posizioni HUD (Score e Clock)
      if (config['hud-score'] !== undefined) {
          window.changeHUDLayout('hud-score', parseInt(config['hud-score']));
      }
      
      if (config['hud-clock'] !== undefined) {
          window.changeHUDLayout('hud-time', parseInt(config['hud-clock']));
      }      

      isUserLive = matchIsLive;
      // GESTIONE QUARTO/PERIODO
      window.quartoAttuale = window.dettagliGara?.statoPartita;
      window.setLocalStorage("statoPartita", window.quartoAttuale);

      if (window.dettagliGara.convocazioni !== window.convocazioni) {
        window.convocazioni = window.dettagliGara.convocazioni;
        window.setLocalStorage("convocazioni", window.convocazioni);
        setTimeout(() => {
          const SWIPED_SLIDE = window.getLocalStorage("SWIPED_SLIDE") === "true";

          if (!SWIPED_SLIDE) 
            console.log("DettagliGara: " + dettagliGara); // ATTENZIONE: aggiunto 11/06
            //??location.reload() 
        } , 1000);
          
      }
  }

  if (what === "all" || what === "events") {
      generaHistory(data.liveData);

      if (window.isAdmin && matchIsLive) { // Solo se l'utente è admin e i bottoni esistono
        mostraControlliSquadraB();
      }

      window.controllaDisponibilitaHighlights();
  }

  if (what === "all" || what === "stats") {
   // 2. Aggiornamento giocatori
      const rows = data.statisticheGiocatori || [];
      rows.forEach(function (r) {
        const g = window.giocatoriObj.find(function (x) {
          return String(x.numero) === String(r.numero);
        });
        if (g) {
          const nuoviPunti = parseInt(r.punti, 10) || 0;
          g.punti = nuoviPunti;
          g.stato = (r.stato ?? r.statoGiocatore) === "In" ? "In" : "Out";

          try {
            // 1. Controllo: se è già un oggetto/array, lo usiamo direttamente. 
            // Altrimenti, proviamo il parse della stringa o usiamo il default.
            if (r.contatori && typeof r.contatori === 'object') {
              g.contatori = r.contatori;
            } else {
              g.contatori = JSON.parse(r.contatori || '{"0":0,"1":0,"2":0,"3":0}');
            }

            // 2. Garantiamo che la chiave "0" esista (es. per il cronometro o falli)
            if (g.contatori["0"] === undefined) {
              g.contatori["0"] = 0;
            }
            
          } catch (e) { 
            console.error("Errore nel parsing dei contatori, reset al default:", e);
            g.contatori = {"0":0,"1":0,"2":0,"3":0};
          }

          // try {
          //   g.contatori = JSON.parse(r.contatori || '{"0":0,"1":0,"2":0,"3":0}');
          //   // Se il JSON esiste ma non ha il tasto "0", lo aggiungiamo
          //   if (g.contatori["0"] === undefined) {
          //     g.contatori["0"] = 0;
          //   }
          // } catch (e) { 
          //   g.contatori = {"0":0,"1":0,"2":0,"3":0};
          // }

        } else if (r.giocatore === "Squadra B" && !matchIsLive && !window.isReviewMode) { // in ReviewMode il punteggio e' calcolato in base al tempo visualizzato
          punteggioB = parseInt(r.punti, 10) || 0;
          contatoriB = JSON.parse(r.contatori || '{"0":0,"1":0,"2":0,"3":0}');
          const g = window.giocatoriObj.find(x => x.id === "Squadra_B"); // aggiorno i contatori 
          if (g) g.contatori = contatoriB;
        }
      });

      // allinea il db Firebase cosi' gli spettatori ce l'hanno sempre aggiornato
      if (window.isAdmin) window.saveToFirebaseHistory('statistiche/' + window.matchId, window.giocatoriObj);

  }

  if (matchIsLive || window.isReviewMode) {
    window.renderPlayerListLive();
    if (window.isAdmin || isFirstLoad) {
      modifyHistory();
      window.saveToFirebaseAll();
    }
  } else {
    if (what === "all" || what === "stats")
      renderPlayerList();
  }

  window.updateScoreboard(matchIsLive || window.isReviewMode);
  isFirstLoad = false;

  // IMPORTANTE: Reset del flag alla fine del successo
  isFetching = false;

}

function caricaDatiPartita(mId) {
  if (!mId) return;

  // Se una chiamata è già in corso, esci subito
  if (isFetching) {
    //console.log("Caricamento in corso... salto questo tick.");
    return;
  }

  isFetching = true;

  // 1. Facciamo partire il cronometro
  const startTime = performance.now();

  const params = new URLSearchParams({
    appVersion: window.APP_VERSION,
    teamId: window.getTeamId(),
    sheet: "Statistiche",
    userId: userId,
    action: "Carica Partita (" + mId + ")",
    details: JSON.stringify(getDeviceData),
    matchId: mId // Aggiungilo direttamente qui
  });

  fetch(`${window.getBackendUrl()}?${params.toString()}`)
    .then(function (response) {
      if (!response.ok) throw new Error("Errore network");
      return response.json();
    })
    .then(function (data) {

      // 2. Calcoliamo la fine e stampiamo in console
      const endTime = performance.now();
      updateDebugFooter(Math.round(endTime - startTime));
      console.log("CaricaDatiPartita() " + Math.round(endTime - startTime) + " ms");

      updateDatiPartita("all", data);
      if (window.fullMatchHistory.length > 0) window.saveToFirebaseHistory('events/' + window.matchId, window.fullMatchHistory); // ATTENZIONE??: refresh per allineare Firebase. da fare solo questa volta

    })
    .catch(function (err) {
      document.getElementById("players-grid").innerHTML = "Errore: " + err;
      console.error("Errore nel caricamento dati partita:", err);
      // IMPORTANTE: Reset del flag anche in caso di errore
      isFetching = false;
    });
}

function caricaAnagraficaSingolaPartita(targetMatchId) {
  if (!targetMatchId) return;

  if (!isAdmin && window.dettagliGara !== null) {
    // restituisce quello che è stato già ricevuto da Firebase, altrimenti interroga il Google Sheet
    return window.dettagliGara;
  }

  console.log("Caricamento dati per il match:", targetMatchId);

  const params = new URLSearchParams({
    appVersion: window.APP_VERSION,
    teamId: window.getTeamId(),
    sheet: "Partite",
    userId: userId,
    action: "Get Singola Partita",
    details: JSON.stringify(getDeviceData)
  });

  return fetch(`${window.getBackendUrl()}?${params.toString()}`)
    .then(res => {
      // 1. Controllo HTTP: la fetch va a buon fine anche con errori 404 o 500

      if (!res.ok) {
        throw new Error(`Errore di rete: ${res.status} ${res.statusText}`);
      }
      return res.json();
    })
    .then(data => {
      // 2. Controllo Dati: Verifichiamo che data non sia nullo o contenga errori espliciti dal backend
      if (!data || data.error || data.status === "error") {
        throw new Error(data?.message || "Il server ha restituito un formato dati non valido");
      }

      // Gestione flessibile dell'array
      const partite = Array.isArray(data) ? data : (data.data || []);
      
      if (partite.length === 0) {
        throw new Error("Nessuna partita disponibile nel database");
      }

      // Cerchiamo il match specifico tramite matchId
      const partita = partite.find(p => String(p.matchId) === String(targetMatchId));

      if (!partita) {
        throw new Error(`Partita con ID ${targetMatchId} non trovata`);
      }

      // allinea il db Firebase cosi' gli spettatori ce l'hanno sempre aggiornato
      if (window.isAdmin) window.saveToFirebaseHistory('partite/' + partita.matchId, partita); 

      // --- ESTRAZIONE E SALVATAGGIO DATI ---
      // Ripetiamo la logica di pulizia e salvataggio che avevi nel click

      const datiPartita = {
        matchId: partita.matchId,
        teamA: partita.squadraA,
        teamB: partita.squadraB,
        puntiSquadraA: partita.punteggioA === "" ? 0 : partita.punteggioA,
        puntiSquadraB: partita.punteggioB === "" ? 0 : partita.punteggioB,
        convocazioni: partita.convocazioni,
        videoURL: partita.videoURL,
        videoId: window.extractVideoId(partita.videoURL),
        matchStartTime: window.extractYoutubeTime(partita.videoURL),
        isLive: partita.isLive
      };

      // Salvataggio sicuro nel localStorage
      Object.keys(datiPartita).forEach(key => {
        window.setLocalStorage(key, datiPartita[key]);
      });

      window.videoId =  datiPartita.videoId; //?? ATTENZIONE AGGIUNTA 11/06
      console.log("Dati partita caricati con successo:", datiPartita);
      return datiPartita;
    })
    .catch(err => {
      // 4. Gestione centralizzata dell'errore
      console.error("Errore critico nel recupero della partita:", err.message);
      alert("Errore critico nel recupero della partita: " + err.message);
      // Opzionale: potresti voler restituire null o un oggetto di errore per la UI
      return null; 
    });
}

//#endregion

function processEventBuffer() {
  if (!window.orarioVisualizzatoFormattato) return;

  // Convertiamo l'orario che l'utente sta vedendo nel video in secondi
  const secondiVisualizzati = hmsToSeconds(window.orarioVisualizzatoFormattato);

  // Cerchiamo l'ultimo evento accaduto prima o in quel momento
  const eventoCorrente = window.fullMatchHistory.findLast(e => e.secondiReali <= secondiVisualizzati);

  if (!(matchIsLive || window.isReviewMode)) return;

  window.renderPlayerListLive();

  if (eventoCorrente) {
    // Aggiorna l'HUD con i dati dell'evento trovato
    punteggioA = eventoCorrente.punteggioA;
    punteggioB = eventoCorrente.punteggioB;
    window.updateScoreboard(matchIsLive || window.isReviewMode);
    if ((isUserLive || window.isReviewMode) && (eventoCorrente.secondiReali !== 0) && (secondiVisualizzati - eventoCorrente.secondiReali < ACCEPTABLE_DELAY_FOR_TOAST) &&
        eventoCorrente.puntiRealizzati > 0) {
      const tmpId = window.GetCognome(eventoCorrente.idGiocatore);
      showBasketToast(tmpId, eventoCorrente.puntiRealizzati);
    }
  }
  else {
    // se non ci sono eventi da visualizzare è perchè siamo ancora "0 - 0"
    punteggioA = 0; 
    punteggioB = 0;
    window.updateScoreboard(matchIsLive || window.isReviewMode);
  }
}

window.tickTimeline = tickTimeline;
async function tickTimeline() {
  // Se c'è il player, gestiamo la parte video
  if (window.player && typeof window.AppPlayer.getCurrentTime === "function") {
    window.checkLiveStatus();

    // AGGIUNTA: Se l'utente sta guardando gli highlight, 
    // allinea l'indice alla posizione del video
    if (window.isReviewMode) {
      window.sincronizzaIndiceHighlightColVideo();
    }
  } else {
    // Logica di fallback se non c'è il video: 
    // usiamo l'orario reale del computer per far scorrere gli eventi live
    const oraAttuale = new Date();
    const vHH = String(oraAttuale.getHours()).padStart(2, '0');
    const vMM = String(oraAttuale.getMinutes()).padStart(2, '0');
    const vSS = String(oraAttuale.getSeconds()).padStart(2, '0');
    window.orarioVisualizzatoFormattato = `${vHH}:${vMM}:${vSS}`;
  }


  // Carica i dati dal server ogni 7 tick (circa 2.1 secondi)
  if (tickCounter % 7 === 0) {
    if (!window.USE_FIREBASE) {
      // vecchia implementazione
      if (!window.isAdmin || tickCounter === 0) { // la prima volta aggiorna i dati anche per admin
          caricaDatiPartita(window.matchId);
      }
    }
    else {
      // in questo caso solo admin usa caricaDatiPartita, gli altri aspettano gli eventi Firebase
      if (tickCounter === 0){ // la prima volta aggiorna i dati anche per admin
          if (window.isAdmin) {
            caricaDatiPartita(window.matchId); // gli spettatori non caricano i dati da Google SHeet ma da Firebase
          }
      }
    }
  }
  tickCounter++;

  if (true || !window.isAdmin) {//?? ATTENZIONE ripristinare
    processEventBuffer(); // Gestisce la visualizzazione dei punti nel tempo
  }

  window.syncPipWithTimestamp(window.orarioVisualizzatoFormattato);
}

function avviaTickSenzaVideo() {
  if (window.timelineInterval) clearInterval(window.timelineInterval);
  // Avviamo subito il primo tick per non aspettare 300ms
  window.tickTimeline();
  window.timelineInterval = setInterval(window.tickTimeline, window.REFRESH_TIME);
}

function initTeamNames() {
  window.teamA = window.getLocalStorage("teamA");
  window.teamB = window.getLocalStorage("teamB");
  squadraAvversaria = window.isMyTeam(window.teamA) ? window.teamB : window.teamA

  const elA = document.getElementById("label-team-A");
  const elB = document.getElementById("label-team-B");
  if (elA) elA.textContent = window.teamA;
  if (elB) elB.textContent = window.teamB;

  const opponent = document.getElementById("opponent");
  if (opponent) opponent.textContent = squadraAvversaria;
}

window.gestisciHud = gestisciHud;
function gestisciHud() {
  const pop = document.getElementById('popup-hud-opts');
  if (pop) {
    // Forza lo spostamento alla fine del body per evitare che i padri lo nascondano
    document.body.appendChild(pop); 
    
    pop.classList.remove('hidden');
  }
}

window.chiudiPopupHud = chiudiPopupHud;
function chiudiPopupHud() {
  const pop = document.getElementById('popup-hud-opts');
  if (pop) pop.classList.add('hidden');
  document.body.style.overflow = '';

  // 1. Recuperiamo i dati esistenti in modo sicuro
  let configEsistente = {};
  try {
    // Se dettagliGara.note è già un oggetto lo usiamo, altrimenti facciamo il parse
    configEsistente = (typeof window.dettagliGara.note === 'string') 
      ? JSON.parse(window.dettagliGara.note) 
      : (window.dettagliGara.note || {});
  } catch (e) {
    console.error("Errore nel parsing di dettagliGara.note:", e);
    configEsistente = {};
  }

  // 2. Creiamo il nuovo oggetto unendo i dati esistenti con quelli nuovi
  // Usiamo lo spread operator (...) per copiare tutto il contenuto precedente
  const nuovaConfig = {
    ...configEsistente,
    "hud-score": hudPositionIndex,
    "hud-clock": timePositionIndex
    // Non sovrascriviamo "stats" e "highlights" se non li stiamo cambiando,
    // o semplicemente li manteniamo come erano nell'oggetto esistente.
  };

  // 3. Trasformiamo l'oggetto aggiornato in stringa JSON
  window.dettagliGara.note = JSON.stringify(nuovaConfig);

  // 4. Salvataggio
  if (window.isAdmin) {
    window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara); 
    window.saveToServerMatchData();
  }
}

window.changeHUDLayout = changeHUDLayout;
function changeHUDLayout(elementId, newPos) {
  /**
   * Sposta ciclicamente la posizione degli elementi HUD
   * @param {string} elementId - L'ID dell'elemento ('hud-score' o 'time-container')
   */
   window.vibrate(100);

  const elem = document.getElementById(elementId);
  if (!elem) return;

  // Definiamo i 6 stati possibili (gli stessi per entrambi)
  const states = [
    { top: '0px', bottom: 'auto', left: '1%',  transform: 'none' },               // 0: Alto Sinistra
    { top: '0px', bottom: 'auto', left: '50%', transform: 'translateX(-50%)' },    // 1: Alto Centro
    { top: '0px', bottom: 'auto', left: '99%', transform: 'translateX(-100%)' },   // 2: Alto Destra
    { top: 'auto', bottom: '0px', left: '99%', transform: 'translateX(-100%)' },   // 3: Basso Destra
    { top: 'auto', bottom: '0px', left: '50%', transform: 'translateX(-50%)' },    // 4: Basso Centro
    { top: 'auto', bottom: '0px', left: '1%',  transform: 'none' }                // 5: Basso Sinistra
  ];

  // Identifichiamo quale indice incrementare
  if (elementId === 'hud-score') {
    if (newPos === undefined)
      hudPositionIndex = (hudPositionIndex + 1) % states.length;
    else
      hudPositionIndex = newPos;

    // sposta il periodo alla sinistra dello score per evitare che esca fuori dallo schermo
    if (hudPositionIndex === 2 || hudPositionIndex === 3) {
      elem.classList.add('anchor-right');
    } else {
      elem.classList.remove('anchor-right');
    }

    const nextPos = states[hudPositionIndex];
    applicaStilePosizione(elem, nextPos);
    // Se lo score finisce in basso, sposta i messaggi Toast in alto
    if (typeof gestisciToast === "function") gestisciToast(nextPos.bottom !== 'auto');
    
  } else if (elementId === 'hud-time') {
    if (newPos === undefined)
      timePositionIndex = (timePositionIndex + 1) % states.length;
    else
      timePositionIndex = newPos;

    const nextPos = states[timePositionIndex];
    applicaStilePosizione(elem, nextPos);
  }
}

function applicaStilePosizione(elem, pos) {
  Object.assign(elem.style, {
    position: 'absolute',
    top: pos.top,
    bottom: pos.bottom,
    left: pos.left,
    transform: pos.transform,
    zIndex: '1000' // Assicuriamoci che stia sopra il video
  });
}

function gestisciToast(isHudAtBottom) {
  const basketToast = document.querySelector('.toast');
  if (!basketToast) return;

  if (isHudAtBottom) {
    basketToast.style.top = '10px';
    basketToast.style.bottom = 'auto';
  } else {
    basketToast.style.top = 'auto';
    basketToast.style.bottom = '10px';
  }
}

function showBasketToast(name, points) {
  const toast = document.getElementById("basket-toast");
  if (!toast) return;

  isToastRunning = true;
  toast.classList.remove("hidden");
  void toast.offsetWidth; // Reset dell'animazione nel DOM

  // Genera i palloni in base ai punti (1, 2 o 3)
  const balls = "🏀".repeat(Math.min(Math.max(points, 1), 3));

  // NUOVO ORDINE: Palloni prima del nome
  toast.textContent = `${balls} ${name}`;

  // Rimuove lo stato di blocco dopo 2 secondi
  setTimeout(() => {
    //toast.classList.remove("toast-active");
    toast.classList.add("hidden");
    isToastRunning = false;
    if (points === 0) {
      isSyncPending = false;
      SYNC_TIME = null;
      console.log("SYNC scaduto e rimosso");
    }
  }, points === 0 ? 30000 : 2000); // mostralo per più tempo se è un messaggio di SYNC (in tal caso points==0)
}

function aggiornaFalliSquadra(inizioQuartoStr) {
  // // 1. Recuperiamo il tempo corrente del video in secondi
  const secondiCorrentiVideo = hmsToSeconds(window.orarioVisualizzatoFormattato);

  // Conversione in secondi
  const secondiInizioQuarto = hmsToSeconds(inizioQuartoStr);

  // 4. Filtriamo la fullMatchHistory
  const eventiFinoAdOra = window.fullMatchHistory.filter(evento => {
    // Il fallo deve essere:
    // - Un evento di tipo "Fallo"
    // - Avvenuto dopo l'inizio del quarto attuale
    // - Avvenuto prima o uguale al secondo corrente del video
    return (
      evento.eventType === "Fallo" && 
      evento.secondiReali >= secondiInizioQuarto && 
      (evento.secondiReali <= secondiCorrentiVideo || window.isAdmin || !matchIsLive) // se isAdmin deve mostrare il fallo indipendentemente da dove è arrivato il video youtube
    );
  });

  // 5. Calcolo Falli Squadra A e B
  const totalFoulsA = eventiFinoAdOra.filter(ev => window.isMyTeam(ev.squadra)).length;
  const totalFoulsB = eventiFinoAdOra.filter(ev => ev.squadra === 'Squadra B').length;

  // 6. Aggiornamento DOM
  const elA = document.getElementById("team-fouls-A");
  const elB = document.getElementById("team-fouls-B");
  
  if (window.quartoAttuale !== "") {
    if (window.isMyTeam(window.teamA)) {
      if (elA) elA.textContent = totalFoulsA;
      if (elB) elB.textContent = totalFoulsB;
    } else {
      if (elA) elA.textContent = totalFoulsB;
      if (elB) elB.textContent = totalFoulsA;
    }
  }
}

function getCurrentPeriod(timeStr, data) {
    if (!timeStr || timeStr === "00:00:00") return "-";

    const currentTime = timeStr.substring(0, 5);

    // 1. Controllo fine match (priorità assoluta)
    if (data.Terminata?.inizio !== "--:--" && currentTime >= data.Terminata?.inizio) {
        return "Terminata";
    }

    // 2. Sequenza cronologica
    const sequence = ["I0", "Q1", "I1", "Q2", "I2", "Q3", "I3", "Q4", "I4", "OT1", "I5", "OT2"];

    // 3. Ricerca inversa: partiamo dall'ultima fase iniziata
    for (let i = sequence.length - 1; i >= 0; i--) {
        const key = sequence[i];
        const period = data[key];

        if (!period || period.inizio === "--:--") continue;

        // Se l'orario attuale è >= inizio, siamo in questo periodo (o non è ancora finito)
        if (currentTime >= period.inizio) {
            // Se esiste una fine definita e l'abbiamo superata, passiamo alla fase successiva 
            // (ma la ricerca inversa ha già trovato la fase più recente iniziata)
            if (period.fine && period.fine !== "--:--" && currentTime >= period.fine) {
                continue; 
            }
            return key;
        }
    }

    return "-";
}

window.updateScoreboard = updateScoreboard;
function updateScoreboard(matchIsLive) {
  const scoreEl = document.getElementById("game-score");
  const scoreTextHUD = document.getElementById("score-text");
  const detailsAEl = document.getElementById("team-details-A");
  const detailsBEl = document.getElementById("team-details-B");
  const secondiCorrentiVideo = hmsToSeconds(window.orarioVisualizzatoFormattato);

  const isPortrait = window.innerWidth < window.innerHeight;

  const isAdminInPortrait = window.isAdmin && isPortrait;

  // --- Helper: Calcolo dai contatori dei giocatori ---
  const getTotalsFromObj = (condition) => {
    return window.giocatoriObj.reduce((acc, g) => {
      if (condition(g)) {
        [0, 1, 2, 3].forEach(i => acc[i] += (g.contatori?.[i] || 0));
      }
      return acc;
    }, { 0: 0, 1: 0, 2: 0, 3: 0 });
  };

  // --- Helper: Calcolo dalla cronologia eventi ---
  const getTotalsFromHistory = (filterFn) => {
    return window.fullMatchHistory
      .filter(ev => ev.eventType === "punto" && (ev.secondiReali <= secondiCorrentiVideo || !matchIsLive) && filterFn(ev))
      .reduce((acc, ev) => {
        const p = parseInt(ev.puntiRealizzati);
        if (acc.hasOwnProperty(p)) acc[p]++;
        return acc;
      }, { 0: 0, 1: 0, 2: 0, 3: 0 });
  };

  // --- 1. Calcolo Squadra A ---
  let totalA;
  if (isAdminInPortrait || !matchIsLive) {
    totalA = getTotalsFromObj(g => g.id !== "Squadra_B");
  } else if (matchIsLive) {
    totalA = { 0: puntiSquadraA_N0, 1: puntiSquadraA_N1, 2: puntiSquadraA_N2, 3: puntiSquadraA_N3 };
  } else {
    totalA = window.highlightsAvailable 
      ? getTotalsFromHistory(ev => window.isMyTeam(ev.squadra))
      : getTotalsFromObj(g => g.id !== "Squadra_B");
  }

  // --- 2. Calcolo Squadra B ---
  let totalB = (window.highlightsAvailable && !isAdminInPortrait)
    ? getTotalsFromHistory(ev => ev.idGiocatore !== window.MY_TEAM && ev.squadra !== window.MY_TEAM)
    : getTotalsFromObj(g => g.id === "Squadra_B");

  // --- 3. Generazione Stringhe ---
  const genDettaglio = (tot) => {
    const { 0: t0, 1: t1, 2: t2, 3: t3 } = tot;
    const tlStr = t0 !== 0 ? `${t1}/${t0 + t1}` : t1;
    return `[TL:${tlStr}, T2:${t2}, T3:${t3}]`;
  };

  let strA = genDettaglio(totalA);
  let strB = genDettaglio(totalB);

  if (!window.isMyTeam(window.teamA)) [strA, strB] = [strB, strA];

  if (detailsAEl) detailsAEl.textContent = strA;
  if (detailsBEl) detailsBEl.textContent = strB;

  // --- 4. Gestione Punteggio Principale ---
  if (!scoreEl) return;

  let currentScore = "";
  if (matchIsLive || window.isEditingMode) {
    if (window.isMyTeam(window.teamA)) {
      currentScore = `${puntiSquadraA_NelTempo} - ${puntiSquadraB_NelTempo}`;
    } else {
      currentScore = `${puntiSquadraB_NelTempo} - ${puntiSquadraA_NelTempo}`;
    }
  } else {
    // Fallback per modalità non-live (es. caricamento pagina)
    const pA = window.getLocalStorage("puntiSquadraA") || 0;
    const pB = window.getLocalStorage("puntiSquadraB") || 0;
    currentScore = `${pA} - ${pB}`;
  }

  // Aggiornamento DOM e Animazioni
  if (currentScore !== lastScoreStr) {
    window.vibrate(100);
    if (scoreTextHUD) scoreTextHUD.textContent = currentScore;
    scoreEl.textContent = currentScore;
    scoreEl.classList.remove("pulse-animation");
    void scoreEl.offsetWidth; // Reflow
    scoreEl.classList.add("pulse-animation");
    lastScoreStr = currentScore;
  }

  // 2. Recuperiamo gli orari di inizio dei quarti dalle note
  let tempiQuarti;
  // Verifichiamo che note esista e non sia una stringa vuota prima di procedere
  if (!window.dettagliGara.note || window.dettagliGara.note === "") {
      tempiQuarti = {}; // O un valore di default appropriato
  } else {
      try {
          tempiQuarti = (typeof window.dettagliGara.note === 'string') ? JSON.parse(window.dettagliGara.note) : window.dettagliGara.note;
      } catch (e) {
          console.error("Errore nel parsing delle note:", e);
          return;
      }
  }

  // 3. Determiniamo l'inizio del quarto attuale
  // Verifichiamo che tempiQuarti esista e che contenga la fase attuale
  let inizioQuartoStr = "00:00:00";
  let quartoAlTempo = "";

  window.quartoAlTempoVisualizzato = (isAdminInPortrait || ! matchIsLive) ? window.quartoAttuale : getCurrentPeriod(window.orarioVisualizzatoFormattato, tempiQuarti)
  
  if (window.quartoAlTempoVisualizzato !== "Terminata" && tempiQuarti && tempiQuarti[window.quartoAlTempoVisualizzato]) {
    // Ora accediamo alla proprietà .inizio dell'oggetto recuperato
    const faseData = tempiQuarti[window.quartoAlTempoVisualizzato];
    inizioQuartoStr = faseData.inizio || "00:00:00";
  }

  // --- 5. Aggiornamento Periodo e Falli ---
  [document.getElementById("hud-period"), document.getElementById("game-period")].forEach(el => {
    if (el && window.window.quartoAlTempoVisualizzato) {
      const isIntervallo = window.quartoAlTempoVisualizzato.includes("I");
      el.textContent = isIntervallo ? "Intervallo" : window.quartoAlTempoVisualizzato;
      el.classList.remove("hidden");
      
      isIntervallo ? el.classList.add("lampeggiante") : el.classList.remove("lampeggiante");

      const isTerminata = window.quartoAlTempoVisualizzato.toLowerCase().includes("terminata");
      el.style.backgroundColor = isTerminata ? "#666" : "#ff0000";
      el.style.borderColor = isTerminata ? "#999" : "#ff4d4d";
    }
  });

  aggiornaFalliSquadra(inizioQuartoStr);
}

function renderPlayerList() {
  const container = document.getElementById("players-grid");
  if (!container) return;

  // ORDINAMENTO: 1. Stato (In > Out), 2. Punteggio (Decrescente)
  const sorted = [...window.giocatoriObj]
    .filter(g => g.id !== 'Squadra_B')
    .sort((a, b) => {
      if (a.stato === 'In' && b.stato !== 'In') return -1;
      if (a.stato !== 'In' && b.stato === 'In') return 1;
      return b.punti - a.punti;
  });

  const note = JSON.parse(dettagliGara.note) || {};
  let TLstatsNotAvailable = !note.highlights || note.statsNoTL; // se note è undefined, il not restituisce true (che va bene)

  container.innerHTML = sorted.map(g => {
    const c = g.contatori;
    /// CALCOLO FRAZIONE TIRI LIBERI (es. 4/5)
    // I tentativi totali sono la somma di quelli segnati (n1) e quelli sbagliati (n0)
    // per le vecchie partite non erano segnati i tiri liberi sbagliati
    const tentativiTL = c[0] + c[1];
    const frazioneTL = (TLstatsNotAvailable || (c[0] === 0 && c[1] === 0)) ? `${c[1]}` : `${c[1]}/${tentativiTL}`;

    const stats = `[TL:${frazioneTL}, T2:${c[2]}, T3:${c[3]}]`;

    // Verifica se attivare il flash (punteggio aumentato)
    const hasChanged = g.punti !== g.lastPunteggio;
    const flashClass = hasChanged ? 'flash-update' : '';

    return `
      <div class="player-item ${g.stato === 'In' ? 'is-in' : 'is-out'}" data-player-num="${g.numero}">
        <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
          <div>
            <span class="player-num">#${g.numero}</span>
            <span class="player-name">${g.cognome}</span>
          </div>
          <div class="player-stats" style="display: flex; align-items: center; gap: 10px;">
            <span class="stats-text">${stats}</span>
            
            <span class="player-fouls-display" style="color: #ff4444; font-weight: bold; min-width: 10px; text-align: center;">
              ${g.falliTotaliCorrenti > 0 ? g.falliTotaliCorrenti : ''}
            </span>

            <span class="player-points">${g.punti}</span>
          </div>
        </div>
      </div>
    `;

  }).join('');
}

function syncGiocatoreUI(g) {
  if (!g || !g.numero) return;

  // 1. Trova il contenitore del giocatore nella griglia usando il numero di maglia
  const allPlayers = document.querySelectorAll('.player-item');
  let playerRow = null;
  
  allPlayers.forEach(item => {
    const numSpan = item.querySelector('.player-num');
    if (numSpan && numSpan.textContent === `#${g.numero}`) {
      playerRow = item;
    }
  });

  if (!playerRow) return;

  // 2. Aggiorna lo span del punteggio totale
  const scoreSpan = playerRow.querySelector('.player-points');
  if (scoreSpan) {
    // Se il punteggio è effettivamente cambiato, avvia l'animazione sulla riga
    if (parseInt(scoreSpan.textContent) !== g.punti) {
      scoreSpan.textContent = g.punti;

      // ANIMAZIONE SULLA RIGA
      playerRow.classList.remove("row-highlight-flash");
      void playerRow.offsetWidth; // Trigger reflow per riavviare l'animazione CSS
      playerRow.classList.add("row-highlight-flash");
    }
  }
}

window.ShowPlayerPopup = ShowPlayerPopup;
function ShowPlayerPopup(giocatore) {
  const existingOverlay = document.querySelector('.player-popup-overlay');
  if (existingOverlay) existingOverlay.remove();
  document.body.style.overflow = 'hidden';

  const isSquadraB = (giocatore === undefined || giocatore === null);
  
  const info = {
    titolo: isSquadraB ? squadraAvversaria : `#${giocatore.numero} - ${giocatore.displayName}`,
    contatori: isSquadraB ? contatoriB : giocatore.contatori,
    history: isSquadraB ? historyB : giocatore.history,
    objOriginale: giocatore 
  };

  const overlay = document.createElement('div');
  overlay.className = 'player-popup-overlay';
  
  const applyFeedback = (el) => {
    el.classList.add('btn-feedback-active');
    if (typeof window.vibrate === 'function') window.vibrate(100);
    setTimeout(() => el.classList.remove('btn-feedback-active'), 150);
  };

  const closePopup = () => {
    document.body.style.overflow = '';
    overlay.remove();
    window.renderPlayerListLive(); 
  };

  overlay.onclick = (e) => { if(e.target === overlay) closePopup(); };

  const content = document.createElement('div');
  content.className = 'player-popup-content dark-theme';

  // --- AGGIORNAMENTO UI POPUP ---
  const refreshPopupUI = () => {
    // Calcolo basato sui contatori (1, 2, 3 punti)
    const nuovoTotale = (info.contatori[1] * 1) + (info.contatori[2] * 2) + (info.contatori[3] * 3);
    totalDisplay.innerHTML = `Totale Punti: <strong>${nuovoTotale}</strong>`;
    
    const labels = content.querySelectorAll('.stat-value strong');
    if (labels.length >= 4) {
        labels[0].innerText = info.contatori[0] || 0;
        labels[1].innerText = info.contatori[1] || 0;
        labels[2].innerText = info.contatori[2] || 0;
        labels[3].innerText = info.contatori[3] || 0;
    }

    // Conteggio Falli basato sul campo "type"
    const numFalli = info.history.filter(ev => ev.type === "Fallo").length;
    
    const foulDisplay = content.querySelector('.foul-count-badge');
    if (foulDisplay) {
      foulDisplay.innerText = numFalli;
      // Alert visivo: rosso se 5 falli
      foulDisplay.style.backgroundColor = numFalli >= 5 ? "#ff0000" : "#444";
    }

    updateEventList();
  };

  const title = document.createElement('h2');
  title.innerText = info.titolo;
  content.appendChild(title);

  const totalDisplay = document.createElement('div');
  totalDisplay.className = 'player-total-points';
  content.appendChild(totalDisplay);

  const gridContainer = document.createElement('div');
  gridContainer.className = 'player-stats-grid';

  // Configurazione coerente con i bottoni +0, +1, +2, +3
  const statsConfig = [
    { label: 'TL Sbagliati', val: info.contatori[0], pts: 0, extraClass: 'btn-tl-miss' },
    { label: 'TL Segnati',   val: info.contatori[1], pts: 1 },
    { label: '2pt Realizzati', val: info.contatori[2], pts: 2 },
    { label: '3pt Realizzati', val: info.contatori[3], pts: 3 }
  ];

  const groupTL = document.createElement('div');
  groupTL.className = 'group-tl-inline';
  gridContainer.appendChild(groupTL);

  statsConfig.forEach((item, index) => {
    const col = document.createElement('div');
    col.className = 'grid-column';
    col.innerHTML = `<div class="stat-value"><span>${item.label}</span><strong>${item.val || 0}</strong></div>`;
    
    const btn = document.createElement('button');
    btn.className = 'btn-pts-action' + (item.extraClass ? ' ' + item.extraClass : '');
    btn.innerText = `+${item.pts}`;
    
    btn.onclick = () => {
      applyFeedback(btn);
      if (isSquadraB) {
        gestisciPuntiAvversari(item.pts);
      } else {
        AddPuntiGiocatore(info.objOriginale.id, item.pts);
      }
      modifyHistory();
      refreshPopupUI(); 
      window.updateScoreboard(matchIsLive || window.isReviewMode); 
      window.saveToFirebaseAll();
    };
    col.appendChild(btn);

    if (index < 2) groupTL.appendChild(col);
    else gridContainer.appendChild(col);
  });
  content.appendChild(gridContainer);

  // --- SEZIONE FALLI UNIVERSALE (Ora anche per Squadra B) ---
  const foulRow = document.createElement('div');
  foulRow.style.display = 'flex';
  foulRow.style.alignItems = 'center';
  foulRow.style.gap = '15px';
  foulRow.style.marginTop = '15px';
  foulRow.style.padding = '10px';
  foulRow.style.backgroundColor = 'rgba(255,255,255,0.05)';
  foulRow.style.borderRadius = '8px';

  const falloBtn = document.createElement('button');
  falloBtn.className = 'btn-pts-action btn-fallo-action';
  falloBtn.style.flex = "1";
  falloBtn.style.margin = "0";
  falloBtn.style.height = "40px";
  falloBtn.style.fontSize = "14px";
  falloBtn.style.backgroundColor = "#dc3545";
  falloBtn.innerText = "FALLO";
  falloBtn.onclick = () => {
      applyFeedback(falloBtn);
      if (isSquadraB) {
          gestisciPuntiAvversari("Fallo");
      } else {
          AddPuntiGiocatore(info.objOriginale.id, "Fallo");
      }
      modifyHistory();
      refreshPopupUI();
      window.saveToFirebaseAll();
  };

  const foulLabel = document.createElement('div');
  foulLabel.style.textAlign = 'center';
  foulLabel.innerHTML = `<span style="display:block; font-size:10px; color:#aaa; text-transform:uppercase;">Tot Falli</span>
                         <span class="foul-count-badge" style="display:inline-block; min-width:30px; padding:4px 8px; background:#444; color:#fff; border-radius:4px; font-weight:bold; font-size:18px;">0</span>`;

  foulRow.appendChild(falloBtn);
  foulRow.appendChild(foulLabel);
  content.appendChild(foulRow);

  // --- LISTA EVENTI (Migliorata per distinguere Punto vs Fallo) ---
  let eventoSelezionato = null;
  const historyRow = document.createElement('div');
  historyRow.className = 'history-row-container';
  const list = document.createElement('div');
  list.className = 'events-scroll-list';
  
  const updateEventList = () => {
    list.innerHTML = '';
    [...info.history].reverse().forEach(ev => {
      const row = document.createElement('div');
      row.className = 'event-list-item';
      
      let labelEvento = "";
      let colorEvento = "#fff";

      if (ev.type === "Fallo") {
        labelEvento = `FALLO`;
        colorEvento = "#ffc107";
      } else if (ev.type === "punto") {
        labelEvento = `${ev.punti} pt`;
        colorEvento = ev.punti === 3 ? "#00d1b2" : "#fff";
      } else {
        labelEvento = ev.stato || "Evento";
      }

      row.innerHTML = `<span>${ev.ora}</span><strong style="color:${colorEvento}">${labelEvento}</strong>`;
      
      row.onclick = () => {
        content.querySelectorAll('.event-list-item').forEach(el => el.classList.remove('selected'));
        row.classList.add('selected');
        eventoSelezionato = ev;
      };
      list.appendChild(row);
    });
  };
  
  historyRow.appendChild(list);

  const undoBtn = document.createElement('button');
  undoBtn.className = 'btn-undo-popup';
  undoBtn.innerHTML = '<i class="fas fa-undo"></i><br>Undo';
  undoBtn.onclick = () => {
    if (!eventoSelezionato) return;
    applyFeedback(undoBtn);
    
    if (isSquadraB) {
        gestisciPuntiAvversari('undo', eventoSelezionato);
    } else {
        const puntiRimossi = undoPuntiGiocatore(info.objOriginale.id, eventoSelezionato);
        if (eventoSelezionato.type === "punto") {
            if (giocatore.punti > 0) giocatore.punti -= puntiRimossi;
        }
    }
    if (!isSquadraB) syncGiocatoreUI(info.objOriginale);
    modifyHistory();
    refreshPopupUI();
    window.updateScoreboard(matchIsLive || window.isReviewMode);
    eventoSelezionato = null;
    window.saveToFirebaseAll();
  };
  
  historyRow.appendChild(undoBtn);
  content.appendChild(historyRow);

  const closeBtn = document.createElement('button');
  closeBtn.className = 'btn-close-popup';
  closeBtn.innerText = 'Chiudi';
  closeBtn.onclick = () => { 
    closePopup();
    window.updateScoreboard(matchIsLive || window.isReviewMode);
};
  content.appendChild(closeBtn);

  overlay.appendChild(content);
  document.body.appendChild(overlay);

  refreshPopupUI();
}

window.setSortMode = setSortMode;
function setSortMode(mode) {
    // Funzione per cambiare la modalità e rinfrescare la lista
    adminSortMode = mode;
    
    // Chiude il menu dopo la scelta
    const menu = document.getElementById("menu");
    if (menu) menu.classList.add("hidden");
    
    // Riesegue il rendering della lista per applicare l'ordinamento
    if (matchIsLive || window.isReviewMode) {
        window.renderPlayerListLive();
    } else {
        renderPlayerList();
    }
}

function setStato(id, stato) {
  const g = window.giocatoriObj.find(x => x.id !== "Squadra_B" && x.id === id);
  if (!g) return;
  g.stato = stato;

  AddPuntiGiocatore(id, stato);

  // salva nello sheet Statistiche. ATTENZIONE: IN futuro si potrà togliere se usiamo solo lo sheet Live contenenti gli eventi
  saveToServerPlayer(g);
}

window.renderPlayerListLive = renderPlayerListLive;
function renderPlayerListLive() {
  const container = document.getElementById("players-grid");
  if (!container) return;

  const isPortrait = window.innerWidth < window.innerHeight;
  const isAdminInPortrait = window.isAdmin && isPortrait;

  const secondiCorrentiVideo = hmsToSeconds(window.orarioVisualizzatoFormattato);
  
  // 1. Rileviamo lo stato attuale del match
  const isTerminata = typeof window.quartoAttuale !== 'undefined' && window.quartoAttuale.toLowerCase().includes("terminata");
  
  // --- GESTIONE SEZIONE AVVERSARI (SQUADRA B) ---
  const opponentSection = document.getElementById('opponent-score-section');
  if (opponentSection) {
    if (window.isAdmin && !isTerminata) {
      opponentSection.classList.add("section-ready");
    } else {
      opponentSection.classList.remove("section-ready");
    }
  }

  // 2. Mappatura e calcolo statistiche
  const visualizzazioneGiocatori = window.giocatoriObj
    .filter(g => g.id !== "Squadra_B")
    .map(g => {
      const eventiGiocatore = window.fullMatchHistory.filter(evento =>
        String(evento.idGiocatore) === String(g.numero) &&
        (isAdminInPortrait === true || evento.secondiReali <= secondiCorrentiVideo)
      );

      let n0 = 0, n1 = 0, n2 = 0, n3 = 0, puntiTotali = 0, nFalli = 0;
      // Calcolo dello stato nel tempo in base agli eventi InOut
      let statoNelTempo = g.stato; 
      
      eventiGiocatore.forEach(e => {
        if (e.timestampReale !== "00:00:00") {
          if (e.eventType === "punto") {
            const p = parseInt(e.puntiRealizzati) || 0;
            if (p === 0) n0++;
            else if (p === 1) n1++;
            else if (p === 2) n2++;
            else if (p === 3) n3++;
            puntiTotali += p;
          }
          else if (e.eventType === "Fallo") {
            nFalli++;
          }
          else if (e.eventType === "InOut") {
            // L'ultimo evento InOut determina lo stato al secondo corrente
            statoNelTempo = e.puntiRealizzati; // "In" o "Out"
          }
        }
      });

      const tentativiTL = n0 + n1;

      return {
        ...g,
        // Se admin, usa lo stato reale del DB, altrimenti quello calcolato dagli eventi video
        statoEffettivo: window.isAdmin ? g.stato : statoNelTempo,
        puntiNelTempo: puntiTotali,
        falliNelTempo: nFalli,
        statsNelTempo: `[TL:${n1}/${tentativiTL}, T2:${n2}, T3:${n3}]`,
        count0: n0, count1: n1, count2: n2, count3: n3
      };
    });

    // --- CALCOLO PUNTEGGI TOTALI ---
    puntiSquadraA_N0 = visualizzazioneGiocatori.reduce((sum, g) => sum + g.count0, 0);
    puntiSquadraA_N1 = visualizzazioneGiocatori.reduce((sum, g) => sum + g.count1, 0);
    puntiSquadraA_N2 = visualizzazioneGiocatori.reduce((sum, g) => sum + g.count2, 0);
    puntiSquadraA_N3 = visualizzazioneGiocatori.reduce((sum, g) => sum + g.count3, 0);

    puntiSquadraA_NelTempo = visualizzazioneGiocatori.reduce((acc, g) => acc + g.puntiNelTempo, 0);

    const eventiSquadraB = window.fullMatchHistory.filter(evento => {
      const isSquadraB = (evento.idGiocatore === "Squadra B" || evento.idGiocatore === "" || evento.idGiocatore === null);
      const timeMatch = (isAdminInPortrait === true || evento.secondiReali <= secondiCorrentiVideo);
      return isSquadraB && timeMatch;
    });

    puntiSquadraB_NelTempo = eventiSquadraB.reduce((acc, e) => acc + (parseInt(e.puntiRealizzati) || 0), 0);

    
    const conteggioIn = visualizzazioneGiocatori.filter(g => g.statoEffettivo === 'In').length;
    const coloreAllerta = (window.isAdmin && conteggioIn !== 5) ? "#FF0000" : "#6CFF6C";

    visualizzazioneGiocatori.sort((a, b) => {
      if (a.statoEffettivo === 'In' && b.statoEffettivo !== 'In') return -1;
      if (a.statoEffettivo !== 'In' && b.statoEffettivo === 'In') return 1;
      if (window.isAdmin && typeof adminSortMode !== 'undefined') {
        if (adminSortMode === 'numero') return parseInt(a.numero) - parseInt(b.numero);
        if (adminSortMode === 'cognome') return a.displayName.localeCompare(b.displayName);
        return b.puntiNelTempo - a.puntiNelTempo;
      }
      return b.puntiNelTempo - a.puntiNelTempo;
  });

  // 4. Rendering Chirurgico
  visualizzazioneGiocatori.forEach((g, index) => {
    let playerDiv = container.querySelector(`[data-player-num="${g.numero}"]`);
    
    const statoPrecedente = playerDiv ? playerDiv.getAttribute("data-stato") : null;
    const terminalitaPrecedente = playerDiv ? playerDiv.getAttribute("data-was-terminated") : null;
    
    const isNew = !playerDiv;
    const statoCambiato = statoPrecedente !== g.statoEffettivo;
    const matchStatusCambiato = terminalitaPrecedente !== String(isTerminata);

    if (isNew || statoCambiato || matchStatusCambiato || window.isEditingMode) {
      if (!playerDiv) {
        playerDiv = document.createElement("div");
        playerDiv.setAttribute("data-player-num", g.numero);
      }
      playerDiv.setAttribute("data-stato", g.statoEffettivo);
      playerDiv.setAttribute("data-was-terminated", String(isTerminata));
      
      if (window.isAdmin && (!isTerminata || window.isEditingMode)) {

        playerDiv.innerHTML = `
          <div class="player-row-wrapper no-select" style="display: flex; justify-content: space-between; align-items: center; width: 100%; white-space: nowrap; gap: 8px;">
            <div class="player-main-info" style="display: flex; align-items: center; gap: 2px; flex-grow: 1; overflow: hidden; cursor: pointer;">
              <span class="player-num" style="flex-shrink: 0; min-width: 28px;">#${g.numero}</span>
              <span class="player-name" style="overflow: hidden; text-overflow: ellipsis; flex-grow: 1;">${g.cognome}</span>
            </div>
            <div class="player-stats-actions" style="display: flex; align-items: center; gap: 2px; flex-shrink: 0; margin-left: 12px;">
              <div class="admin-controls" style="display: flex; gap: 3px;"></div>
              
              <span class="player-fouls-display" style="color: #ff4444; font-weight: bold; min-width: 20px; text-align: center; font-size: 1.4rem;">
                ${g.falliTotaliCorrenti || ''}
              </span>

              <span class="player-points player-points-value">0</span>
            </div>
          </div>`;


        playerDiv.querySelector(".player-main-info").onclick = () => {
          window.vibrate(100);
          const nuovoStato = (g.statoEffettivo === "In") ? "Out" : "In";
          const p = window.giocatoriObj.find(item => item.id !== "Squadra_B" && item.id === g.id);
          if(p) p.stato = nuovoStato;
          setStato(g.id, nuovoStato);
          modifyHistory();

          // salva il cambio di stato In/Out sul DB degli eventi live
          //?? const oraCorrente = new Date().toLocaleTimeString('it-IT');
          //window.saveToServerEventoLive(g.numero, nuovoStato, oraCorrente, window.getTeamName(), "save");

          window.renderPlayerListLive();
          window.saveToFirebaseAll();
        };

        if (g.statoEffettivo === "In") {
          const controls = playerDiv.querySelector(".admin-controls");
          
          const btnDetails = document.createElement("button");
          btnDetails.className = "player-tiro";
          btnDetails.style.backgroundColor = "#007bff";
          btnDetails.textContent = "Details";
          btnDetails.style.marginRight = "1rem";
          btnDetails.onclick = (e) => { 
            e.stopPropagation(); 
            window.vibrate(100); 
            // rileggiamo g da giocatoriObj perch' potrebbe essere cambiato.
            const g2 = window.giocatoriObj.find(p => p.id === g.id); 
            window.ShowPlayerPopup(g2); 
          };
          controls.appendChild(btnDetails);

          const btnPlus2 = document.createElement("button");
          btnPlus2.className = "player-tiro";
          btnPlus2.textContent = "+2";
          btnPlus2.onclick = (e) => {
            e.stopPropagation();
            window.vibrate(100);

            punteggioA = window.giocatoriObj.reduce((sum, g) => {
              // Escludiamo l'elemento Squadra B dal calcolo dei punti della squadra A
              if (g.id === "Squadra_B") return sum;
              
              return sum + (g.punti || 0);
            }, 0) + 2;

            AddPuntiGiocatore(g.id, 2);
            g.punti += 2;
            modifyHistory();
            window.renderPlayerListLive();
            window.updateScoreboard(true);
            window.saveToFirebaseAll();
          };
          controls.appendChild(btnPlus2);
        }
      } else {
        playerDiv.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
            <div>
              <span class="player-num">#${g.numero}</span>
              <span class="player-name">${g.cognome}</span>
            </div>
            <div class="player-stats">
              <span class="stats-text"></span> 
              <span class="player-fouls-display" style="color: #ff4444; font-weight: bold; min-width: 20px; text-align: center; font-size: 1.4rem;">
                ${g.falliNelTempo || ''}
              </span>
              <span class="player-points">0</span>
            </div>
          </div>`;

      }
    }


    playerDiv.className = `player-item ${g.statoEffettivo === 'In' ? 'is-in' : 'is-out'}`;
    
    const numSpan = playerDiv.querySelector(".player-num");

    if (g.statoEffettivo === 'In') {
        playerDiv.style.borderLeft = `4px solid ${coloreAllerta}`;
        if (numSpan) numSpan.style.color = (window.isAdmin) ? coloreAllerta : ""; 
    } else {
        playerDiv.style.borderLeft = ""; 
        if (numSpan) numSpan.style.color = ""; 
    }

    // 1. Gestione Falli
    const foulsSpan = playerDiv.querySelector('.player-fouls-display');
    let falliCambiati = false;
    if (foulsSpan) {
        const fVis = parseInt(foulsSpan.textContent) || 0;
        // Verifichiamo se il valore attuale nel DOM è diverso dal nuovo calcolo
        if (fVis !== (g.falliNelTempo || 0)) {
            foulsSpan.innerText = g.falliNelTempo || "";
            falliCambiati = true;
        }
    }

    // 2. Gestione Punti
    const scoreSpan = playerDiv.querySelector(".player-points") || playerDiv.querySelector(".player-points-value");
    let puntiCambiati = false;
    if (scoreSpan) {
        const pVis = parseInt(scoreSpan.textContent) || 0;
        if (pVis !== g.puntiNelTempo) {
            scoreSpan.textContent = g.puntiNelTempo;
            puntiCambiati = true;
        }
    }

    // 3. Attivazione Flash
    // Se non è il primo caricamento (isNew) e almeno uno dei due è cambiato
    if (!isNew && (puntiCambiati || falliCambiati)) {
        playerDiv.classList.add("row-highlight-flash");
        setTimeout(() => playerDiv.classList.remove("row-highlight-flash"), 2000);
    }

    const statsSpan = playerDiv.querySelector(".stats-text");
    if (statsSpan) statsSpan.textContent = g.statsNelTempo;

    if (container.children[index] !== playerDiv) {
      container.insertBefore(playerDiv, container.children[index]);
    }
  });

  while (container.children.length > visualizzazioneGiocatori.length) {
    container.removeChild(container.lastChild);
  }
}

function mostraControlliSquadraB() {
    const oppSection = document.getElementById('opponent-score-section');
    if (oppSection) {
      oppSection.classList.add("section-ready");
    }
}

window.IncrPuntiSquadraB = IncrPuntiSquadraB;
function IncrPuntiSquadraB(points) {
  // chiamato dall'html
  gestisciPuntiAvversari(points, null);
  modifyHistory();
  window.renderPlayerListLive(); 
  window.updateScoreboard(matchIsLive || window.isReviewMode); 
  window.saveToFirebaseAll();
}

function gestisciPuntiAvversari(azione, evento) {
    if (azione === 'undo') {
        undoPuntiSquadraB(evento);

        undoPuntiGiocatore("Squadra_B", evento);
    } else {
        // 'azione' può essere 1, 2, 3 o "Fallo"
        AddPuntiSquadraB(azione, true); // ATTENZIONE?? dovrebbe essere inutile

        AddPuntiGiocatore("Squadra_B", azione);
    }

    // Animazione flash
    const opponentRow = document.getElementById("opponent-score-section");
    if (opponentRow) {
        opponentRow.classList.remove("row-highlight-flash");
        void opponentRow.offsetWidth; 
        opponentRow.classList.add("row-highlight-flash");
    }

    punteggioB = puntiSquadraB; // Aggiorna la variabile globale
    
    if (window.isAdmin && matchIsLive) { 
      mostraControlliSquadraB();
    }
}

//#region GESTIONE FULLSCREEN
function entraInFullscreen() {
  const container = document.querySelector('.video-container');
  const btn = document.getElementById('btn-ios-fullscreen');

  if (container.requestFullscreen) {
    container.requestFullscreen();
  } else if (container.webkitRequestFullscreen) {
    // Questa è la riga vitale per iPhone
    container.webkitRequestFullscreen();
  }

  // Nascondi il tasto dopo il click per non coprire il video
  if (btn) btn.style.display = 'none';
}

function requestFullscreen() {
  // --- FUNZIONI FULLSCREEN ---
  // Seleziona il contenitore del video o l'intero documento se preferisci
  const el = document.querySelector(".video-container") || document.documentElement;

  if (el.requestFullscreen) {
    el.requestFullscreen();
  } else if (el.webkitRequestFullscreen) {
    el.webkitRequestFullscreen(); // Per Safari e vecchi Chrome
  } else if (el.msRequestFullscreen) {
    el.msRequestFullscreen(); // Per IE/Edge
  }
}

function exitFullscreen() {
  if (document.fullscreenElement || document.webkitFullscreenElement) {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
}

function toggleIOSFullscreen() {
  if (window.orientation === 90 || window.orientation === -90) {
    // Un piccolo timeout aiuta Safari a ricalcolare gli spazi
    setTimeout(() => {
      window.scrollTo(0, 1);
    }, 300);
  }
}

// Ascolta il cambio di orientamento
window.addEventListener("orientationchange", toggleIOSFullscreen);

// Gestisci Fullscreen in landscape
window.screen.orientation.addEventListener("change", function () {
  if (window.screen.orientation.type.startsWith("portrait")) {
    // Se siamo in verticale e il fullscreen è attivo, lo chiudiamo
    if (document.fullscreenElement || document.webkitFullscreenElement) {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    }
  } else if (window.screen.orientation.type.startsWith("landscape")) {
    // Opzionale: attiva fullscreen quando ruoti in orizzontale
    const elem = document.querySelector(".video-container");
    if (elem) {
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if (elem.webkitRequestFullscreen) {
        elem.webkitRequestFullscreen();
      }
    }
  }
  
  // Se l'utente ruota lo schermo mentre il tutorial è attivo, chiudilo subito 
  if (window.innerWidth > window.innerHeight) {
     chiudiTutorialRotazione();
  }

  // quando torno in portrait per admin, ripristina i punteggi e le statistihe della fine partita.
  if (window.isAdmin) renderPlayerList();

}, { passive: true });

// Opzionale: aggiungi un controllo anche al resize per sicurezza su alcuni Android
window.addEventListener("resize", () => {
  // Se la larghezza supera l'altezza, siamo probabilmente in landscape
  if (window.innerWidth > window.innerHeight) {
    requestFullscreen();
  }
}, { passive: true });

//#endregion

function modificaOraInizioDiretta(delta) {
  /**
   * Modifica l'ora di inizio o il timestamp
   * @param {number} incremento - Può essere +1 o -1
   */
  // 2. Converti HH:MM:SS in secondi totali
  if (!window.isAdmin) return;

  if (window.oraInizioDiretta === "") window.oraInizioDiretta = "00:00:00";
  const parti = window.oraInizioDiretta.split(":");
  let secondiTotali = (+parti[0]) * 3600 + (+parti[1]) * 60 + (+parti[2]);

  // 3. Applica la modifica
  secondiTotali += delta;

  // Evita valori negativi
  if (secondiTotali < 0) secondiTotali = 0;

  // 4. Riconverti in formato HH:MM:SS
  const ore = Math.floor((secondiTotali / 3600) % 24).toString().padStart(2, '0');
  const minuti = Math.floor((secondiTotali % 3600) / 60).toString().padStart(2, '0');
  const secondi = (secondiTotali % 60).toString().padStart(2, '0');

  window.oraInizioDiretta = `${ore}:${minuti}:${secondi}`;

  // Salviamo il nuovo valore
  window.setLocalStorage("oraInizioDiretta", window.oraInizioDiretta);
  window.dettagliGara.oraInizioDiretta = window.oraInizioDiretta

  console.log("Nuovo Start Time impostato:", window.oraInizioDiretta);


  // Se sei Admin, potresti voler inviare questo aggiornamento al server/DB
  if (window.isAdmin) {
    window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara); 

    window.saveToServerMatchData(); // La tua funzione esistente per salvare su Google Sheets
  }
}

//#regione GESTIONE SYNC TIME
function sendSyncTime() {
  console.log("SendSyncTime() chiamata");
  window.vibrate(100);

  const oraCorrente = new Date().toLocaleTimeString('it-IT');
  SYNC_TIME = oraCorrente;
}

function showSyncTime(events) {
  if (isSyncPending) return;

  if (SYNC_TIME) {
    isSyncPending = true;
    window.vibrate(100);

    showBasketToast("SYNC: " + SYNC_TIME, 0);
  }
}

function checkSyncTime(events) {
  const basketToast = document.getElementById('basket-toast');
  if (basketToast) {
    basketToast.classList.add("hidden");
  }
  isToastRunning = false;

  if (SYNC_TIME === undefined) {
    isSyncPending = false;
    return;
  }

  // 1. Calcolo l'offset tra realtà e video
  const offsetEvento = - (hmsToSeconds(SYNC_TIME) - hmsToSeconds(window.orarioVisualizzatoFormattato)); 

  // 2. Calcolo la nuova Ora Inizio
  // Sottraendo l'offset: se l'offset è 10s (video in ritardo), 
  // l'ora di inizio reale deve essere 10s prima di quella attuale.
  const oraInizioAttualeSecondi = hmsToSeconds(window.oraInizioDiretta);
  const nuovaOraInizioSecondi = oraInizioAttualeSecondi - offsetEvento;
  const nuovaOraInizioHms = window.secondsToHms(nuovaOraInizioSecondi);

  const messaggio = `SYNC INFO:
Differenza:             ${offsetEvento} secondi
Attuale Inizio:         ${window.oraInizioDiretta}
Nuovo Inizio Suggerito: ${nuovaOraInizioHms}

${offsetEvento < 0 ? "Ritardo video eccessivo (Sposta AVANTI)" : "Video troppo avanti (Sposta INDIETRO)"}

Vuoi applicare la nuova sincronizzazione?`;

  // Resettiamo i flag PRIMA del confirm o del reload per sicurezza
  const tempSync = SYNC_TIME;
  isSyncPending = false;
  SYNC_TIME = null;

  if (confirm(messaggio)) {
    modificaOraInizioDiretta(-offsetEvento);
  }
}
//#endregion

function updateDebugFooter(serverTime = null) {
  const fetchSpan = document.getElementById("fetch-time");
  const sizeSpan = document.getElementById("display-size");
  const dprSpan = document.getElementById("display-dpr");

  // Aggiorna il tempo del server solo se passato
  if (serverTime !== null && fetchSpan) {
    fetchSpan.textContent = serverTime;
    fetchSpan.style.color = "#ff4d4d";
  }

  // Calcola e inserisce W, H e DPR
  if (sizeSpan) {
    sizeSpan.textContent = `${window.innerWidth}x${window.innerHeight}`;
  }
  if (dprSpan) {
    dprSpan.textContent = window.devicePixelRatio.toFixed(2);
  }
}

//#region SALVATAGGIO SU SERVER

function saveToServerPlayer(g) {
  const squadra = window.MY_TEAM;
  const formData = new FormData();
  formData.append('appVersion', window.APP_VERSION)
  formData.append('teamId', window.getTeamId());
  formData.append("matchId", window.matchId);
  formData.append("squadra", squadra);
  formData.append("giocatore", g.displayName);
  formData.append("numero", g.numero);
  formData.append("punti", g.punti);   // 👈 invio punteggio cumulativo
  formData.append("contatori", JSON.stringify(g.contatori)); // 👈 invio contatori cumulativi
  formData.append("stato", g.stato);

  fetch(window.getBackendUrl(), {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => console.log("Salvato cumulativo giocatore:", data))
    .catch(err => console.error("Errore salvataggio giocatore:", err));
}

window.saveToServerMatchData = saveToServerMatchData;
function saveToServerMatchData() {

  if (!window.matchId) {
    console.warn("Nessun matchId trovato, non salvo");
    return;
  }

  const formData = new FormData();
  formData.append('appVersion', window.APP_VERSION)
  formData.append('teamId', window.getTeamId());
  formData.append("matchId", window.matchId);

  if (window.isMyTeam(window.teamA)) {
    formData.append("punteggioA", puntiSquadraA);
    formData.append("punteggioB", puntiSquadraB);
  } else {
    formData.append("punteggioA", puntiSquadraB);
    formData.append("punteggioB", puntiSquadraA);
  }

  // Aggiungi altre variabili
  formData.append("convocazioni", window.convocazioni);
  formData.append("videoURL", window.videoURL);
  formData.append("oraInizioDiretta", window.oraInizioDiretta);
  formData.append("isLive", isLive);
  formData.append("statoPartita", window.statoPartita);
  formData.append("note", window.dettagliGara.note);

  // Invia al tuo Google Apps Script
  fetch(window.getBackendUrl(), {
    method: "POST",
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      console.log("[SERVER RESPONSE] ", data);
    })
    .catch(error => {
      console.error("Errore nel salvataggio:", error);
    });
}

window.salvaStatoLive = salvaStatoLive;
function salvaStatoLive(dati) {
  console.log("Dati inviati a salvaStatoLive:", dati);
  isLive = (dati.goLive === true);

  // Gestione stato partita
  if (dati.terminata === true) {
    window.statoPartita = "Terminata";
  } else {
    window.statoPartita = dati.quarto;
  }
  
  window.setLocalStorage("statoPartita", window.statoPartita);
  window.setLocalStorage("isLive", isLive);

  window.dettagliGara.isLive = isLive;
  window.dettagliGara.statoPartita = window.statoPartita + (window.isEditingMode ? "*" : "");
  window.quartoAttuale = window.statoPartita;
  matchIsLive = isLive;

  // --- LOGICA AGGIORNAMENTO CONFIGURAZIONE CON TUTTI I DETTAGLI ---
  
  // 1. Recuperiamo la configurazione esistente
  let configEsistente = {};
  try {
    configEsistente = (typeof window.dettagliGara.note === 'string') 
      ? JSON.parse(window.dettagliGara.note) 
      : (window.dettagliGara.note || {});
  } catch (e) { configEsistente = {}; }

  // 2. Parse della cronologia tempi che arriva dal popup (oggetto completo {inizio, fine})
  let tempiPopup = {};
  try {
    tempiPopup = dati.noteTempi ? JSON.parse(dati.noteTempi) : {};
  } catch (e) { tempiPopup = {}; }

  // 3. Costruiamo la nuova configurazione
  // Manteniamo i valori preesistenti (HUD, impostazioni) e aggiorniamo le fasi
  const nuovaConfig = {
    ...configEsistente,
    "hud-score": hudPositionIndex,
    "hud-clock": timePositionIndex
  };

  // 4. Salviamo ogni fase ricevuta dal popup (I0, Q1, I1, Q2, I2, Q3, I3, Q4, I4, OT1, I5, OT2)
  // Salviamo l'intero oggetto contenente inizio e fine
  Object.keys(tempiPopup).forEach(fase => {
    if (tempiPopup[fase]) {
      nuovaConfig[fase] = tempiPopup[fase];
    }
  });

  // 5. Trasformiamo in JSON e salviamo
  window.dettagliGara.note = JSON.stringify(nuovaConfig);
  // ------------------------------------------------------------

  window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara); 
  window.saveToServerMatchData();
}

//#endregion

function inizializzaGiocatoriConvocati() {
  const stringaConvocati = window.getLocalStorage("convocazioni");
  
  // 1. Pulizia della stringa dei convocati
  let convocatiIds = [];
  if (stringaConvocati && stringaConvocati.trim() !== "" && stringaConvocati !== "[ALL]") {
    const stringaPulita = stringaConvocati.replace(/[\[\]'" ]/g, "");
    convocatiIds = stringaPulita.split(",");
  }

  // 2. Creiamo la nuova lista basandoci sull'anagrafica totale
  const nuoviGiocatoriObj = giocatoriA.map((nomeCompleto, index) => {
    let numeroMaglia = "";
    let nome = "";
    let cognome = "";
    let isConvocato = false;
    if (nomeCompleto !== "Squadra B") {
      // MODIFICA QUI: Gestione spazi nel nome e cognome

      const parti = nomeCompleto.trim().split(/\s+/); // Divide per uno o più spazi
      nome = parti[0]; // La prima parola è il nome
      cognome = parti.slice(1).join(" "); // Tutto il resto è il cognome
      
      numeroMaglia = String(window.numeriMaglia[index]);

      // Verifica se il giocatore è convocato
      isConvocato = convocatiIds.length === 0 || convocatiIds.includes(numeroMaglia);
    }
    else {
      isConvocato = true;
      nome = "B";
      cognome = "Squadra";
    }
    
    if (!isConvocato) return null;

    // CERCA se il giocatore esisteva già
//    const giocatoreEsistente = window.giocatoriObj.find(g => g.id !== "Squadra_B" && String(g.numero) === numeroMaglia);
    // preserva anche il record della Squadra_B
    const giocatoreEsistente = window.giocatoriObj.find(g => String(g.numero) === numeroMaglia);

    if (giocatoreEsistente) {
      // Se esiste, lo restituiamo così com'è (mantiene history, punteggio, stato, ecc.)
      return giocatoreEsistente;
    } else {
      return {
        id: `${cognome.replace(/\s+/g, '_')}_${nome}`, // ID senza spazi per sicurezza
        numero: numeroMaglia,
        displayName: `${cognome} ${nome}`,
        punti: 0,
        contatori: { 0: 0, 1: 0, 2: 0, 3: 0 },
        history: [], 
        stato: "Out",
        lastPunteggio: 0,
        nome: nome,
        cognome: cognome  
      };
    }
  })
  .filter(g => g !== null) // Rimuove i non convocati
  .sort((a, b) => a.cognome.localeCompare(b.cognome)); // Mantiene l'ordinamento

  // 3. Aggiorna la variabile globale
  window.giocatoriObj = nuoviGiocatoriObj;

  console.log("GiocatoriObj aggiornato:", window.giocatoriObj);
}


// Funzione per aggiornare l'orario
function updateSystemClock() {
    const now = new Date();
    window.systemClockVisualizzato = now.toLocaleTimeString('it-IT', { hour12: false });
    if (window.isAdmin) {
      const clockElement = document.getElementById('systemClock');
      clockElement.textContent = window.systemClockVisualizzato;
    }
}

function mostraTutorialRotazione() {
  const overlay = document.getElementById('rotation-tutorial-overlay');
  
  // Controllo di sicurezza: se siamo già in orizzontale, non mostrare nulla
  if (window.innerWidth > window.innerHeight) {
    return;
  }

  // Aggiunge la classe che fa apparire l'overlay (con transizione CSS)
  overlay.classList.add('show');

  // Nasconde automaticamente l'overlay dopo 4 secondi (4000 millisecondi)
  setTimeout(() => {
    chiudiTutorialRotazione();
  }, 3000); 
}

// Funzione per chiudere il tutorial (usata dal timeout o manualmente)
function chiudiTutorialRotazione() {
  const overlay = document.getElementById('rotation-tutorial-overlay');
  if (overlay)
    overlay.classList.remove('show');
}

window.mostraGraficoPunteggio = mostraGraficoPunteggio;
function mostraGraficoPunteggio() {
    const modal = document.getElementById('modalGraficoEvoluzione');
    if (!modal) return;
    modal.style.display = 'flex';

    setTimeout(() => {
        const canvas = document.getElementById('canvasEvoluzione');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        let datiGrafico = window.fullMatchHistory
            .filter(ev => ev.eventType === "punto")
            .map(ev => ({
                tempo: ev.timestampReale.replace("*", ""), 
                puntiA: ev.punteggioA,
                puntiB: ev.punteggioB
            }));

        const orarioInizioHHMM = window.aggiungiSecondiAOrario(window.oraInizioDiretta, window.matchStartTime).substring(0, 5);
        datiGrafico.unshift({ tempo: orarioInizioHHMM, puntiA: 0, puntiB: 0 });

        const inCasa = window.isMyTeam(window.teamA);

        const ultimoDato = datiGrafico[datiGrafico.length - 1];
//        const labelA = `Poli_smile A (${ultimoDato.puntiA})`;
        const labelA = `${window.MY_TEAM} (${ultimoDato.puntiA})`;
        const labelB = window.isMyTeam(window.teamA) ? `${window.teamB} (${ultimoDato.puntiB})` : `${window.teamA} (${ultimoDato.puntiB})`;        
        const tettoAsseY = Math.ceil(Math.max(ultimoDato.puntiA, ultimoDato.puntiB) / 10) * 10; 

        let tempiQuarti = {};
        try { tempiQuarti = (typeof window.dettagliGara.note === 'string') ? JSON.parse(window.dettagliGara.note) : (window.dettagliGara.note || {}); } catch(e) {}

        const trovaIndice = (t) => {
            if (!t) return null;
            const i = datiGrafico.findIndex(d => d.tempo >= t);
            return i !== -1 ? i : null;
        };

        const iQ2 = trovaIndice(tempiQuarti.Q2?.inizio) || Math.floor(datiGrafico.length * 0.25);
        const iQ3 = trovaIndice(tempiQuarti.Q3?.inizio) || Math.floor(datiGrafico.length * 0.5);
        const iQ4 = trovaIndice(tempiQuarti.Q4?.inizio) || Math.floor(datiGrafico.length * 0.75);
        const iOT1 = trovaIndice(tempiQuarti.OT1?.inizio);
        const iOT2 = trovaIndice(tempiQuarti.OT2?.inizio);
        const iFine = datiGrafico.length - 1;

        // --- CALCOLO VANTAGGIO MASSIMO E MINIMO ---
        let maxVantaggio = 0;
        let minVantaggio = 0;
        let quartoVantaggioMax = "Q1";
        let quartoVantaggioMin = "Q1";
        
        datiGrafico.forEach((d, idx) => {
            const diff = inCasa ? (d.puntiA - d.puntiB) : (d.puntiB - d.puntiA);
            
            const determinaQuarto = (i) => {
                if (i < iQ2) return "Q1";
                if (i < iQ3) return "Q2";
                if (i < iQ4) return "Q3";
                if (!iOT1 || i < iOT1) return "Q4";
                if (!iOT2 || i < iOT2) return "OT1";
                return "OT2";
            };

            if (diff > maxVantaggio) {
                maxVantaggio = diff;
                quartoVantaggioMax = determinaQuarto(idx);
            }
            if (diff < minVantaggio) {
                minVantaggio = diff;
                quartoVantaggioMin = determinaQuarto(idx);
            }
        });

        const calcolaColoreRisultato = (idxFine) => {
            const statoPunteggio = datiGrafico[idxFine] || { puntiA: 0, puntiB: 0 };
            const myTeamAvanti = (statoPunteggio.puntiA > statoPunteggio.puntiB);
            const myTeamSotto =  (statoPunteggio.puntiA < statoPunteggio.puntiB);
            
            if (myTeamAvanti) return "#d4edda"; 
            if (myTeamSotto) return "#f8d7da"; 
            return "#f0f0f0"; 
        };

        let parziali = [
            { q: "1Q", idx: iQ2 - 1 },
            { q: "2Q", idx: iQ3 - 1 },
            { q: "3Q", idx: iQ4 - 1 },
            { q: "4Q", idx: iOT1 ? iOT1 - 1 : iFine }
        ];

        if (iOT1) parziali.push({ q: "OT1", idx: iOT2 ? iOT2 - 1 : iFine });
        if (iOT2) parziali.push({ q: "OT2", idx: iFine });

        let scoreboard = document.getElementById('grafico-scoreboard');
        if (!scoreboard) {
            scoreboard = document.createElement('div');
            scoreboard.id = 'grafico-scoreboard';
            scoreboard.style = "display: flex; justify-content: center; gap: 10px; margin-bottom: 5px; font-family: sans-serif; flex-wrap: wrap;";
            const titolo = document.getElementById('titoloGrafico');
            titolo.parentNode.insertBefore(scoreboard, titolo.nextSibling);
        }

        scoreboard.innerHTML = parziali.map(item => {
            const colore = calcolaColoreRisultato(item.idx);
            const d = datiGrafico[item.idx] || { puntiA: 0, puntiB: 0 };
            const puntiA = inCasa ? d.puntiA : d.puntiB;
            const puntiB = inCasa ? d.puntiB : d.puntiA;
            return `
                <div style="text-align: center; flex: 1; min-width: 60px; max-width: 80px;">
                    <div style="font-size: 1.1rem; color: #777; font-weight: bold;">${item.q}</div>
                    <div style="font-size: 1.4rem; color: #333; font-weight: bold; background: ${colore}; padding: 3px 0; border-radius: 5px; border: 1px solid #ddd;">
                        ${puntiA}-${puntiB}
                    </div>
                </div>
            `;
        }).join('');

        // Aggiunta testo vantaggio massimo e minimo
        let vLabel = document.getElementById('grafico-max-lead');
        if (!vLabel) {
            vLabel = document.createElement('div');
            vLabel.id = 'grafico-max-lead';
            vLabel.style = "text-align: center; font-family: sans-serif; font-size: 1.1rem; color: #555; margin-bottom: 15px; font-weight: bold; line-height: 1.4;";
            scoreboard.parentNode.insertBefore(vLabel, scoreboard.nextSibling);
        }
        vLabel.innerHTML = `Vantaggio massimo: ${maxVantaggio} pts (${quartoVantaggioMax})<br>Vantaggio minimo: ${minVantaggio} pts (${quartoVantaggioMin})`;

        if (window.chartEvoluzione) window.chartEvoluzione.destroy();
        
        const m1 = iQ2 / 2, m2 = iQ2 + (iQ3 - iQ2) / 2, m3 = iQ3 + (iQ4 - iQ3) / 2;
        const m4 = iOT1 ? (iQ4 + (iOT1 - iQ4) / 2) : (iQ4 + (iFine - iQ4) / 2);

        const etichetta = (x, testo) => ({ type: 'line', xMin: x, xMax: x, borderWidth: 0, label: { display: true, content: testo, position: 'center', yValue: tettoAsseY, yAdjust: -70, backgroundColor: 'transparent', color: '#666', font: { size: 10, weight: 'bold' }, z: 100 } });
        const separatore = (x) => ({ type: 'line', xMin: x, xMax: x, borderColor: '#999', borderDash: [6, 4], borderWidth: 2, z: 1 });

        let annotations = { 
            s2: separatore(iQ2), s3: separatore(iQ3), s4: separatore(iQ4), sFine: separatore(iFine),
            l1: etichetta(m1, '1Q'), l2: etichetta(m2, '2Q'), l3: etichetta(m3, '3Q'), l4: etichetta(m4, '4Q')
        };
        if (iOT1) annotations.sOT1 = separatore(iOT1);
        if (iOT2) annotations.sOT2 = separatore(iOT2);

        window.chartEvoluzione = new Chart(ctx, {
            type: 'line',
            data: {
                labels: datiGrafico.map(d => d.tempo),
                datasets: [
                    { label: inCasa ? labelA:labelB, data: datiGrafico.map(d => inCasa ? d.puntiA:d.puntiB), borderColor: inCasa ? '#dc3545' : '#0056b3', borderWidth: 2, fill: false, pointRadius: 1 },
                    { label: inCasa ? labelB:labelA, data: datiGrafico.map(d => inCasa ? d.puntiB:d.puntiA), borderColor: inCasa ? '#0056b3' : '#dc3545', borderWidth: 2, fill: false, pointRadius: 1 }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                layout: { padding: { top: 0, right: 30, left: 20, bottom: 10 } },
                scales: {
                    x: { ticks: { autoSkip: true, maxTicksLimit: 12, callback: function(val) { return this.getLabelForValue(val).substring(0, 5); } } },
                    y: { beginAtZero: true, max: tettoAsseY, ticks: { stepSize: 10 } }
                },
                plugins: { legend: { display: true }, annotation: { annotations } }
            }
        });
    }, 150);
}

window.chiudiGraficoEvoluzione = chiudiGraficoEvoluzione;
function chiudiGraficoEvoluzione() {
    document.getElementById('modalGraficoEvoluzione').style.display = 'none';
}


// ---------------------------------------------------------------------------------
window.ShowFullHistoryPopup = ShowFullHistoryPopup;
function ShowFullHistoryPopup(giocatoriObj) {
    // 1. RIMOZIONE OVERLAY ESISTENTE E BLOCCO SCROLL
    const existing = document.querySelector('.full-history-overlay');
    if (existing) existing.remove();
    document.body.style.overflow = 'hidden';

    let eventoSelezionato = null;

    // 2. CREAZIONE STRUTTURA BASE
    const overlay = document.createElement('div');
    overlay.className = 'full-history-overlay player-popup-overlay'; // Riutilizziamo i tuoi stili base
    
    const content = document.createElement('div');
    content.className = 'player-popup-content dark-theme full-history-content';
    content.style.width = '95%';
    content.style.maxWidth = '500px';
    content.style.display = 'flex';
    content.style.flexDirection = 'column';
    content.style.maxHeight = '90vh';

    // HEADER FISSO
    const header = document.createElement('div');
    header.innerHTML = `<h2 style="margin-bottom:10px; color:var(--primary);">LOG EVENTI PARTITA</h2>
                        <div style="display:grid; grid-template-columns: 50px 60px 1fr 60px; font-size:10px; text-transform:uppercase; color:#888; padding:5px; border-bottom:1px solid #444;">
                            <span>Ora</span><span>Score</span><span>Giocatore</span><span>Evento</span>
                        </div>`;
    content.appendChild(header);

    // CONTENITORE LISTA SCROLLABILE
    const listContainer = document.createElement('div');
    listContainer.className = 'events-scroll-list';
    listContainer.style.flex = "1";
    listContainer.style.overflowY = "auto";
    listContainer.style.margin = "10px 0";
    content.appendChild(listContainer);

    const renderList = () => {
        listContainer.innerHTML = '';
        let allEvents = [];
        
        giocatoriObj.forEach(g => {
            if (g.history) {
                g.history.forEach(ev => {
                    if (ev.type !== "InOut") {
                        allEvents.push({ 
                            ...ev, 
                            playerId: g.id, 
                            cognome: g.id === "Squadra_B" ? "AVVERSARI" : (g.cognome || g.displayName) 
                        });
                    }
                });
            }
        });

        allEvents.sort((a, b) => a.ora.localeCompare(b.ora));

        // HEADER AGGIORNATO (Q = Quarto)
        // Grid: Q(35) | Ora(45) | Prima(60) | Giocatore(1fr) | Ev(45) | Dopo(60)
        header.innerHTML = `
            <h2 style="margin-bottom:10px; color:var(--primary);">LOG EVENTI PARTITA</h2>
            <div style="display:grid; grid-template-columns: 35px 45px 60px 1fr 45px 60px; font-size:9px; text-transform:uppercase; color:#888; padding:5px; border-bottom:1px solid #444; text-align:center;">
                <span>Q</span><span>Ora</span><span>Prima</span><span>Giocatore</span><span>Ev.</span><span>Dopo</span>
            </div>`;

        let punteggioMyTeam = 0;
        let punteggioSquadraB = 0;

        allEvents.forEach((ev) => {
            const isAvversario = ev.playerId === "Squadra_B";
            
            // --- ESTRAZIONE QUARTO DA ev.note ---
            let labelQuarto = "-";
            if (ev.note) {
                try {
                    const objNote = typeof ev.note === 'string' ? JSON.parse(ev.note) : ev.note;
                    labelQuarto = objNote.quarto || "-";
                } catch (e) {
                    console.error("Errore parsing ev.note:", e);
                }
            }

            const scorePrima = window.isMyTeam(window.teamA) ? `${punteggioMyTeam}-${punteggioSquadraB}` : `${punteggioSquadraB}-${punteggioMyTeam}`;

            if (ev.type === "punto") {
                if (isAvversario) punteggioSquadraB += parseInt(ev.punti || 0);
                else punteggioMyTeam += parseInt(ev.punti || 0);
            }

            const scoreDopo = window.isMyTeam(window.teamA) ? `${punteggioMyTeam}-${punteggioSquadraB}` : `${punteggioSquadraB}-${punteggioMyTeam}`;

            const row = document.createElement('div');
            row.className = 'event-list-item';
            row.style.display = 'grid';
            row.style.gridTemplateColumns = '35px 45px 60px 1fr 45px 60px';
            row.style.alignItems = 'center';
            row.style.fontSize = '11px';
            row.style.padding = '10px 2px';
            row.style.textAlign = 'center';
            row.style.borderLeft = isAvversario ? "4px solid #ff4444" : "4px solid var(--primary)";
            row.style.backgroundColor = isAvversario ? "rgba(255, 68, 68, 0.05)" : "rgba(0, 209, 178, 0.05)";
            row.style.marginBottom = "2px";

            if (eventoSelezionato && eventoSelezionato.playerId === ev.playerId && eventoSelezionato.ora === ev.ora) {
              row.classList.add('selected');
              updateActionCard(); 

            }

            let infoPunti = ev.type === "punto" ? `<strong>${ev.punti}pt</strong>` : `<span style="font-size:9px; opacity:0.7">${ev.type}</span>`;
            let colorTestoGiocatore = isAvversario ? "#ff6b6b" : "#ffffff";
            let colorEvento = ev.type === "Fallo" ? "#ff4444" : (ev.punti === 3 ? "#00d1b2" : (isAvversario ? "#ff6b6b" : "#fff"));

            row.innerHTML = `
                <span style="font-weight:bold; color:#888;">${labelQuarto}</span>
                <span style="font-size:10px; color:#aaa;">${ev.ora}</span>
                <span style="font-family:monospace; color:#888;">${scorePrima}</span>
                <span class="edit-player" style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; cursor:pointer; text-align:left; padding-left:5px; color:${colorTestoGiocatore};">${ev.cognome}</span>
                <span class="edit-points" style="color:${colorEvento}; cursor:pointer;">${infoPunti}</span>
                <span style="font-family:monospace; color:var(--primary); font-weight:bold;">${scoreDopo}</span>
            `;

            row.onclick = (e) => {
                // 1. Salviamo l'evento selezionato
                eventoSelezionato = ev;

                // 2. Togliamo il colore blu da tutte le righe del contenitore
                listContainer.querySelectorAll('.event-list-item').forEach(el => {
                    el.classList.remove('selected');
                });

                // 3. Aggiungiamo il colore blu alla riga appena cliccata
                row.classList.add('selected');

                // 4. Mostriamo e aggiorniamo la card con i dettagli in basso
                updateActionCard(); 
            };

            listContainer.appendChild(row);
        });

        setTimeout(() => { listContainer.scrollTop = listContainer.scrollHeight; }, 50);
    };

    // 3.5 CREAZIONE CARD DETTAGLIO (Action Area)
    const actionCard = document.createElement('div');
    actionCard.className = 'selected-event-card';
    actionCard.style.display = 'none'; // Nascosta di default
    actionCard.style.padding = '15px';
    actionCard.style.margin = '10px 0';
    actionCard.style.background = '#2a2a2a';
    actionCard.style.borderRadius = '8px';
    actionCard.style.border = '1px solid #444';
    content.insertBefore(actionCard, listContainer.nextSibling);

    const updateActionCard = () => {
        if (!eventoSelezionato) {
            actionCard.style.display = 'none';
            return;
        }
        
        const isAvversario = eventoSelezionato.playerId === "Squadra_B";
        const isPunto = eventoSelezionato.type === "punto";
        actionCard.style.display = 'block';
        
        actionCard.innerHTML = `
            <div style="font-size: 12px; color: #aaa; margin-bottom: 8px;">DETTAGLIO SELEZIONE</div>
            
            <div style="display: flex; flex-direction: column; gap: 8px; color: white;">
                <div><strong>Ora:</strong> ${eventoSelezionato.ora}</div>
                
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>Giocatore:</strong> ${eventoSelezionato.cognome}</span>
                    ${!isAvversario ? `<button class="btn-small-edit" id="btn-change-player">Cambia</button>` : ''}
                </div>
                
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>Tipo:</strong> ${isPunto ? eventoSelezionato.punti + 'pt' : eventoSelezionato.type}</span>
                    ${isPunto ? `<button class="btn-small-edit" id="btn-change-points">Cambia</button>` : ''}
                </div>
                
                <button class="btn-delete-event" style="margin-top: 10px; background: #ff4444; color: white; border: none; padding: 8px; border-radius: 4px; cursor: pointer; font-size: 12px;">
                    <i class="fas fa-trash"></i> CANCELLA EVENTO
                </button>
            </div>
        `;

        // Listener per i bottoni della Card
        if (!isAvversario) {
            actionCard.querySelector('#btn-change-player').onclick = () => CambiaGiocatoreEvento(eventoSelezionato, giocatoriObj, renderList);
        }
        if (isPunto) {
            actionCard.querySelector('#btn-change-points').onclick = () => CambiaPuntiEvento(eventoSelezionato, renderList);
        }
        
        actionCard.querySelector('.btn-delete-event').onclick = () => {
            if (confirm(`Vuoi davvero eliminare questo evento di ${eventoSelezionato.cognome}?`)) {
                const g = giocatoriObj.find(p => p.id === eventoSelezionato.playerId);
                undoPuntiGiocatore(g.id, eventoSelezionato);
                eventoSelezionato = null;
                updateActionCard(); // Nasconde la card
                renderList();

                modifyHistory();

                if (matchIsLive || window.isReviewMode) {
                    window.renderPlayerListLive();
                } else {
                    renderPlayerList();
                }
                window.updateScoreboard(true);
                window.saveToFirebaseAll();
            }
        };
    };

    // 4. BOTTONI AZIONE (FISSI IN FONDO)
    const footer = document.createElement('div');
    footer.style.paddingTop = "10px";
    footer.style.borderTop = "1px solid #444";

    const closeBtn = document.createElement('button');
    closeBtn.className = 'btn-close-popup';
    closeBtn.style.width = "100%";
    closeBtn.innerText = 'CHIUDI';
    closeBtn.onclick = () => {
        document.body.style.overflow = '';
        overlay.remove();
        window.renderPlayerListLive();
    };

    footer.appendChild(closeBtn);
    content.appendChild(footer);

    overlay.appendChild(content);
    document.body.appendChild(overlay);

    renderList();
}

// --- FUNZIONI DI SUPPORTO PER L'EDITING ---

function CambiaGiocatoreEvento(evento, tuttiGiocatori, callback) {
    const nuovoNumero = prompt("Inserisci il numero del nuovo giocatore:", "");
    if (!nuovoNumero) return;
    
    const nuovoG = tuttiGiocatori.find(g => g.numero == nuovoNumero);
    if (!nuovoG) return alert("Giocatore non trovato!");

    // Rimuoviamo l'evento dal vecchio
    const vecchioG = tuttiGiocatori.find(g => g.id === evento.playerId);
    const vecchioNumero = vecchioG.numero;
    vecchioG.history = vecchioG.history.filter(e => {
        // Restituisci TRUE (tieni l'evento) se:
        // L'ora è diversa OPPURE i punti sono diversi.
        return e.ora !== evento.ora || e.punti !== evento.punti;
    });
    // Ricalcolo contatori vecchio
    if(evento.type === "punto") {
      vecchioG.contatori[evento.punti]--;
      vecchioG.punti -= evento.punti;
    }
    else if(evento.type === "Fallo") {
      vecchioG.falliTotaliCorrenti -= 1;
    }

    let what = "";
    // Aggiungiamo al nuovo
    evento.playerId = nuovoG.id;
    evento.cognome = nuovoG.cognome || nuovoG.displayName;
    nuovoG.history.push(evento);
    if(evento.type === "punto") {
      nuovoG.contatori[evento.punti]++;
      nuovoG.punti += evento.punti;
      what = evento.punti;
    }
    else if(evento.type === "Fallo") {
      nuovoG.falliTotaliCorrenti += 1;
      what = evento.type;
    }
    const team = vecchioNumero == "" ? "Squadra B"  : window.MY_TEAM;

    callback();
    modifyHistory();
    if (matchIsLive || window.isReviewMode) {
        window.renderPlayerListLive();
    } else {
        renderPlayerList();
    }
    window.updateScoreboard(true);

    window.modifyToServerEventoLive("modify", evento.ora, team, vecchioNumero, nuovoNumero, what, what);
    window.saveToFirebaseAll();
}

function CambiaPuntiEvento(evento, callback) {
    const nuoviPti = prompt("Modifica punti (0, 1, 2, 3):", evento.punti);
    if (nuoviPti === null || !["0", "1", "2", "3"].includes(nuoviPti)) return;

    const oldPunti = evento.punti;
    const ptiInt = parseInt(nuoviPti);
    const g = window.giocatoriObj.find(p => p.id === evento.playerId); 
    const team = (g.numero == "") ? "Squadra B"  : window.MY_TEAM;
    
    // Aggiorno contatore e history giocatore
    if(g) {
        g.contatori[evento.punti]--;
        g.contatori[ptiInt]++;

        const h = g.history.find(e => (e.ora === evento.ora) && (e.punti === evento.punti));
        if (h) {
          h.punti = ptiInt;
        }
        g.punti = g.punti - evento.punti + ptiInt;
    }
    
    evento.punti = ptiInt;
    callback();
    modifyHistory();
    if (matchIsLive || window.isReviewMode) {
        window.renderPlayerListLive();
    } else {
        renderPlayerList();
    }
    window.updateScoreboard(true);

    window.modifyToServerEventoLive("modify", evento.ora, team, g.numero, g.numero, oldPunti, ptiInt);
    window.saveToFirebaseAll();
}

function showMatch(currentMatchId) {
  if (currentMatchId) {
    new Promise(resolve => setTimeout(resolve, 500))
    .then(() => {
        return caricaAnagraficaSingolaPartita(currentMatchId);
    })

    .then(() => {
      if (window.isAdmin)
        // serve aggiornare sempre il Roster quando carichiamo una partita?. facciamolo solo per admin
        return window.aggiornaDatiRosterEStats("roster");
      else {
        // non caricare il roster dal server per non perdere tempo, ma dalla cache
        const cacheRoster = window.getLocalStorage("datiRoster");
        let dataResponse = {}
        if (cacheRoster ) {
            try {
                dataResponse.roster = JSON.parse(cacheRoster);
                return dataResponse;
            } catch (e) { return null;}
        }
        return null; 
      }
    })
    
    .then(dati => {
      if (dati && dati.roster) {
        window.popolaGiocatoriA(dati.roster);
        if (window.isAdmin) saveToFirebaseRoster('roster/', dati.roster);
        console.log("Roster e Statistiche aggiornati globalmente.");
      }

      inizializzaGiocatoriConvocati();

      let videoAvailable = window.videoId && window.videoId !== "null" && window.videoId !== "";

      // Gestione Player Video o Placeholder (vecchia implementazione)
      if (!window.NEW_PLAYER_INTERFACE) {
        if (videoAvailable) {
          window.createPlayer(window.videoURL, window.videoId);
        }
      }

      // Gestione Player Video con Copertina e Bottone PLAY manuale
      if (window.NEW_PLAYER_INTERFACE) {
        if (videoAvailable) {
          const videoSpinner = document.getElementById("video-loading");
          const containerVideo = videoSpinner?.parentElement;
          const wrapperPlayer = document.getElementById("ytplayer"); // Il div destinato a YouTube

          if (!window.isAdmin && containerVideo && wrapperPlayer) {

            const btnToggle = document.getElementById('toggle-highlights');
            if (btnToggle) btnToggle.classList.add('hidden');

            // Nascondiamo momentaneamente il div destinato a ospitare YouTube
            wrapperPlayer.style.display = "none";

            // Creiamo la funzione riutilizzabile per generare il Poster Container
            window.mostraPosterCopertina = function() {
                if (document.getElementById("custom-video-poster")) return;

                // Recuperiamo la scoreboard nativa per poterla nascondere
                const scoreboardNativa = document.querySelector(".scoreboard");
                if (scoreboardNativa) {
                    scoreboardNativa.style.setProperty("display", "none", "important");
                }

                wrapperPlayer.style.display = "none";
                
                if (window.timeUpdateInterval) {
                    clearInterval(window.timeUpdateInterval);
                    window.timeUpdateInterval = null;
                }

                // --- LOGICA DI CALCOLO ORIGINALE DERIVATA DA window.giocatoriObj ---
                const stats = {
                    teamA: { tl_segni: 0, tl_sbagliati: 0, t2: 0, t3: 0, punti: 0, falli: 0 },
                    teamB: { tl_segni: 0, tl_sbagliati: 0, t2: 0, t3: 0, punti: 0, falli: 0 }
                };

                // controllo per decidere se ci sono statistiche sui tiri liberi/sbagliati
                const note = JSON.parse(dettagliGara.note) || {};
                let TLstatsNotAvailable = !note.highlights || note.statsNoTL; // se note è undefined, il not restituisce true (che va bene)

                if (window.giocatoriObj && Array.isArray(window.giocatoriObj)) {
                    window.giocatoriObj.forEach(g => {

                        const c = g.contatori; // c[0]=TL sbagliati, c[1]=TL segnati, c[2]=T2, c[3]=T3
                        const f = g.falliTotaliCorrenti || 0; // Recupero dei falli
                        
                        if (g.id === 'Squadra_B') {
                            stats.teamB.tl_sbagliati += (c[0] || 0);
                            stats.teamB.tl_segni += (c[1] || 0);
                            stats.teamB.t2 += (c[2] || 0);
                            stats.teamB.t3 += (c[3] || 0);
                            stats.teamB.punti += (g.punti || 0);
                            stats.teamB.falli += f;
                        } else {
                            stats.teamA.tl_sbagliati += (c[0] || 0);
                            stats.teamA.tl_segni += (c[1] || 0);
                            stats.teamA.t2 += (c[2] || 0);
                            stats.teamA.t3 += (c[3] || 0);
                            stats.teamA.punti += (g.punti || 0);
                            stats.teamA.falli += f;
                        }
                    });
                    if (stats.teamA.falli === 0) stats.teamA.falli = "N/D";
                    if (stats.teamB.falli === 0) stats.teamB.falli = "N/D";
                }
                // se la partita è fuori casa (Poli_smile è la squadra B, inverti i dati)
                if (!window.isMyTeam(window.teamA)) [stats.teamA, stats.teamB] = [stats.teamB, stats.teamA];


                // --- LOGICA COLORE VITTORIA/SCONFITTA ---
                // Controlliamo se la partita è finita
                //const isTerminata = String(window.quartoAlTempoVisualizzato || window.quartoAttuale).toLowerCase().includes("terminata");
                const isTerminata = window.dettagliGara.statoPartita.toLowerCase().includes("terminata");
                
                let stilePuntiA = "color: #ffcc00;"; 
                let stilePuntiB = "color: #ffcc00;";

                if (isTerminata) {
                    // Troviamo i punti di Poli_smile e dell'avversario in base a dove gioca
                    const myTeamPunti = window.isMyTeam(window.teamA) ? stats.teamA.punti : stats.teamB.punti;
                    const avversarioPunti = window.isMyTeam(window.teamA) ? stats.teamB.punti : stats.teamA.punti;
                    const myTeamHaVinto = myTeamPunti > avversarioPunti;

                    // Stili grafici per evidenziare il risultato
                    const stileVittoria = "color: #ffffff; background-color: #1e7e34; padding: 2px 14px; border-radius: 8px; border: 2px solid #28a745; box-shadow: 0 0 10px rgba(40,167,69,0.4);";
                    const stileSconfitta = "color: #ffcccc; background-color: #bd2130; padding: 2px 14px; border-radius: 8px; border: 2px solid #dc3545; box-shadow: 0 0 10px rgba(220,53,69,0.3);";

                    if (window.isMyTeam(window.teamA)) {
                        stilePuntiA = myTeamHaVinto ? stileVittoria : stileSconfitta;
                        stilePuntiB = myTeamHaVinto ? stileSconfitta : stileVittoria;
                    } else {
                        stilePuntiA = myTeamHaVinto ? stileSconfitta : stileVittoria;
                        stilePuntiB = myTeamHaVinto ? stileVittoria : stileSconfitta;
                    }
                }


                // Calcolo percentuali e frazioni
                const calcolaFrazione = (seguiti, sbagliati) => {
                    if (TLstatsNotAvailable) return ""; // restituisce solo i tiri segnati

                    const tentativi = seguiti + sbagliati;
                    const str = (sbagliati === 0 && seguiti === 0) ? `${seguiti}` : `${seguiti}/${tentativi}`
                    return "(" +  str + ")";
                };

                const calcolaPerc = (seguiti, sbagliati) => {
                    if (TLstatsNotAvailable) return "N/D"; // restituisce solo i tiri segnati
                    const tot = seguiti + sbagliati;
                    return tot > 0 ? Math.round((seguiti / tot) * 100) + "%" : "0%";
                };

                const frazioneTLA = calcolaFrazione(stats.teamA.tl_segni, stats.teamA.tl_sbagliati);
                const frazioneTLB = calcolaFrazione(stats.teamB.tl_segni, stats.teamB.tl_sbagliati);
                const percTLA = calcolaPerc(stats.teamA.tl_segni, stats.teamA.tl_sbagliati);
                const percTLB = calcolaPerc(stats.teamB.tl_segni, stats.teamB.tl_sbagliati);

                // Estrattore di data/ora se presenti nei dettagli della gara
                const dataOraPartita = window.dettagliGara?.data && window.dettagliGara?.ora 
                    ? `${window.dettagliGara.data} - ${window.dettagliGara.ora}` 
                    : (window.dettagliGara?.data || window.dettagliGara?.ora || "");

                // --- COSTRUZIONE UI ---
                const posterContainer = document.createElement("div");
                posterContainer.id = "custom-video-poster";
                posterContainer.style.cssText = `
                    position: absolute; top: 0; left: 0; width: 100%; height: 100%;
                    background: linear-gradient(135deg, #1e272c 0%, #0f1416 100%);
                    color: #ffffff; display: flex; flex-direction: column;
                    align-items: center; justify-content: space-between; padding: 5px 10px;
                    box-sizing: border-box; z-index: 9999; font-family: sans-serif;
                `;

                posterContainer.innerHTML = `
                    <div style="position: relative; width: 100%; box-sizing: border-box; display: flex; flex-direction: column; gap: 4px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; width: 100%; font-size: 1rem; color: #ffcc00; font-weight: bold; font-variant-numeric: tabular-nums;">
                            <span>ID: ${currentMatchId}</span>
                            <span>${dataOraPartita}</span>
                        </div>

                        <div style="width: 100%; text-align: center; font-size: 0.85rem; color: #aaa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            📍 ${window.dettagliGara?.luogo || "Palazzetto dello sport"}
                        </div>

                        ${window.dettagliGara?.campionato ? `
                            <div style="width: 100%; text-align: left; font-size: 1.1rem; font-weight: bold; text-transform: uppercase; letter-spacing: 0.3px; color: #eee; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 1px;">
                                ${window.dettagliGara.campionato}
                            </div>
                        ` : ''}
                    </div>

                    <div style="display: flex; align-items: flex-start; justify-content: space-between; width: 100%; max-width: 600px; margin: 2px 0; gap: 8px;">
                        <div style="text-align: center; flex: 1; min-width: 0; display: flex; flex-direction: column; align-items: center;">
                            <div style="font-size: 1.25rem; font-weight: 800; min-height: 3.2rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis; line-height: 1.2; max-height: 2.4rem; text-transform: uppercase; width: 100%; word-break: break-word;">
                                ${window.teamA || "TEAM A"}
                            </div>
                            <div style="font-size: 2rem; font-weight: 900; line-height: 1.1; margin-top: 0px; ${stilePuntiA}">
                                ${stats.teamA.punti}
                            </div>
                        </div>

                        <div style="display: flex; flex-direction: column; align-items: center; flex-shrink: 0; min-width: 70px; margin-top: 5px; gap: 4px;">
                            <div style="font-size: 1.1rem; font-weight: bold; color: #666;">VS</div>
                            <div style="background: #00ebff; color: #000; padding: 2px 8px; border-radius: 15px; font-size: 0.8rem; font-weight: bold; letter-spacing: 0.2px; white-space: nowrap;">
                                ${window.statoPartita || "LIVE"}
                            </div>
                            
                            <button id="custom-poster-play-btn" style="
                                width: 26px;
                                height: 26px;
                                border-radius: 50%;
                                background: #ffcc00;
                                border: none;
                                cursor: pointer;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                box-shadow: 0 3px 8px rgba(0,0,0,0.4);
                                z-index: 10005;
                                transition: transform 0.2s;
                            " onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                                <i class="fas fa-play" style="font-size: 1.1rem; color: #000; margin-left: 2px;"></i>
                            </button>
                        </div>

                        <div style="text-align: center; flex: 1; min-width: 0; display: flex; flex-direction: column; align-items: center;">
                            <div style="font-size: 1.25rem; font-weight: 800; min-height: 3.2rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis; line-height: 1.2; max-height: 2.4rem; text-transform: uppercase; width: 100%; word-break: break-word;">
                                ${window.teamB || "TEAM B"}
                            </div>
                            <div style="font-size: 2rem; font-weight: 900; line-height: 1.1; margin-top: 0px; ${stilePuntiB}">
                                ${stats.teamB.punti}
                            </div>
                        </div>
                    </div>

                    <div style="width: 100%; max-width: 440px; background: rgba(0,0,0,0.45); padding: 2px 2px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); box-sizing: border-box;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; border-bottom: 1px solid rgba(255,255,255,0.1); font-size: 1.05rem;">
                            <span style="font-weight: bold; color: #00ebff; width: 75px; text-align: left;">${percTLA} <small style="color:#777; font-size:0.8rem;">${frazioneTLA}</small></span>
                            <span style="color: #aaa; font-size: 0.75rem; font-weight: bold; letter-spacing: 0.5px;">TIRI LIBERI %</span>
                            <span style="font-weight: bold; color: #00ebff; width: 75px; text-align: right;">${percTLB} <small style="color:#777; font-size:0.8rem;">${frazioneTLB}</small></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; font-size: 1.05rem;">
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamA.tl_segni}</span>
                            <span style="color: #888; font-size: 0.8rem; font-weight: 500;">TIRI DA 1 SEGNATI</span>
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamB.tl_segni}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; font-size: 1.05rem;">
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamA.t2}</span>
                            <span style="color: #888; font-size: 0.8rem; font-weight: 500;">TIRI DA 2 SEGNATI</span>
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamB.t2}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; font-size: 1.05rem;">
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamA.t3}</span>
                            <span style="color: #888; font-size: 0.8rem; font-weight: 500;">TIRI DA 3 SEGNATI</span>
                            <span style="font-weight: 600; width: 40px; text-align: center;">${stats.teamB.t3}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.08); margin-top: 5px; font-size: 1.05rem;">
                            <span style="font-weight: 600; width: 40px; text-align: center; color: #ff4d4d;">${stats.teamA.falli}</span>
                            <span style="color: #aaa; font-size: 0.8rem; font-weight: bold; letter-spacing: 0.3px;">FALLI DI SQUADRA</span>
                            <span style="font-weight: 600; width: 40px; text-align: center; color: #ff4d4d;">${stats.teamB.falli}</span>
                        </div>
                    </div>
                `;

                containerVideo.appendChild(posterContainer);

                const playAction = () => {
mostraTutorialRotazione();
                    posterContainer.remove();
                    wrapperPlayer.style.display = "block";
                    
                    if (scoreboardNativa) {
                        scoreboardNativa.style.display = ""; 
                    }

                    if (window.activePlayerType === 'twitch') {
                        if (typeof forzaPlayTwitchUnificato === 'function') forzaPlayTwitchUnificato();
                    } else {
                        if (window.player?.playVideo) window.player.playVideo();
                        else window.createYTPlayer(window.videoId);
                    }
                    setTimeout(() => toggleHighlights(), 1000);
                };

                document.getElementById("custom-poster-play-btn").onclick = (e) => { 
                    e.stopPropagation(); 
                    playAction(); 
                };
                
                posterContainer.onclick = playAction;
            };

            window.posterInitialized = true;
            // Genera la copertina al primo caricamento della pagina
            window.mostraPosterCopertina();

            // ASSEGNAZIONE EVENTO AL PULSANTE "STOP VIDEO"
            const stopBtn = document.getElementById("stopVideoBtn");
            if (stopBtn) {
              stopBtn.addEventListener("click", () => {
                // 1. Nascondi il pulsante stesso
                stopBtn.classList.add("hidden");
                
                // 2. FERMA IL VIDEO SENZA DISTRUGGERE L'ISTANZA
                // Questo azzera l'audio e lo streaming evitando la duplicazione degli eventi UI
                if (window.player) {
                  // if (typeof window.player.stopVideo === 'function') {
                  //   window.player.stopVideo(); 
                  // } else 
                  if (typeof window.AppPlayer.pause === 'function') {
                    window.AppPlayer.pause();
                  }
                }
                
                // 3. Fai ricomparire la copertina iniziale
                if (typeof window.mostraPosterCopertina === 'function') {
                  window.mostraPosterCopertina();
                }
                setTimeout(() => {
                  toggleHighlights(false);
                  renderPlayerList();
                  window.updateScoreboard(matchIsLive || window.isReviewMode);
                }, 200);

              });
            }        
          } else {
            // Fallback di sicurezza nel caso i contenitori DOM non venissero trovati immediatamente
            window.posterInitialized = false;
            window.createPlayer(window.videoURL, window.videoId);
          }
        }
      }

      if (!videoAvailable)  {        
        document.getElementById("video-loading")?.classList.add("hidden");
        const placeholder = document.getElementById("video-placeholder");
        if (placeholder) placeholder.style.display = "block";
        console.log("Nessun video trovato, avvio tickTimeline.");
        avviaTickSenzaVideo();
      }

      // ATTENZIONE: non sono riuscito a farlo funzionare in maniera soddisfacente.
      // non riesco a caricare tutte le schede all'inizio con i dati dele partite (facendo una clone, le slide hanno i dati della stessa partita)
      // inoltre il bottone "play" dentro il poster copertina non funzione per le slide diverse dalla prima
      //if (!window.isAdmin) initSwiper();

      console.log("Timeline avviata per il match:", currentMatchId);
    })
    
    .catch(err => {
      console.error("Errore durante il caricamento dei dati iniziali:", err);
    });
  }

}
// ---------------------------------------------------------------------------------------------------- //
async function init() {

  // --- PROTEZIONE PER BUNDLING/OFFUSCAMENTO ---
  const pageElement = document.getElementById('player-wrapper'); // o l'ID principale della tua pagina
  if (!pageElement || window.initAlreadyExecuted) return; 
  window.initAlreadyExecuted = true;

    // 1. REGISTRAZIONE E CARICAMENTO DATI DA LOCALSTORAGE
  await window.registerUserId();

  window.isAdmin = window.getLocalStorage("isAdmin") === "true";
  window.teamA = window.getLocalStorage("teamA");
  window.teamB = window.getLocalStorage("teamB");
  squadraAvversaria = window.isMyTeam(window.teamA) ? window.teamB : window.teamA;

  window.convocazioni = window.getLocalStorage("convocazioni");
  window.videoURL = window.getLocalStorage("videoURL");
  window.videoId = window.getLocalStorage("videoId");
  // Leggiamo subito i valori numerici correttamente
  window.matchStartTime = parseInt(window.getLocalStorage("matchStartTime") || "0", 10);
  window.oraInizioDiretta = window.getLocalStorage("oraInizioDiretta");
  isLive = window.getLocalStorage("isLive");
  window.statoPartita = window.getLocalStorage("statoPartita");
  window.googleApiKey = window.getLocalStorage("googleApiKey") || "";

  puntiSquadraA = parseInt(window.getLocalStorage("puntiSquadraA") || 0);
  puntiSquadraB = parseInt(window.getLocalStorage("puntiSquadraB") || 0);

  initTeamNames();

  // 2. GESTIONE CLASSI UI (Admin vs User)
  document.body.classList.toggle("admin-mode", window.isAdmin);
  document.body.classList.toggle("user-mode", !window.isAdmin);

  // 3. CARICAMENTO DATI PARTITA (Firebase / API)
  const urlParams = new URLSearchParams(window.location.search);
  const currentMatchId = urlParams.get("matchId");

  if (!window.isAdmin) {
    // Logica per utenti normali
    registerToFirebaseEvents();
  }
  // abilitiamo lo spinner solo per admin. lo spettatore normale vedrà il poster
  const videoSpinner = document.getElementById("video-loading");
  if (window.isAdmin && videoSpinner) videoSpinner.classList.remove("hidden");


  showMatch(currentMatchId);

  // 4. LOGICA SINCRONIZZAZIONE (SYNCTIME)
  const hudClockElement = document.getElementById('hud-video-time');
  if (window.isAdmin && hudClockElement) {
    hudClockElement.style.pointerEvents = 'auto';
    hudClockElement.style.cursor = 'pointer';
    hudClockElement.addEventListener('click', () => {
      sendSyncTime();
      showSyncTime();
    }, { passive: true });
  }

  const basketToast = document.getElementById('basket-toast');
  if (window.isAdmin && basketToast) {
    basketToast.addEventListener('click', () => {
      if (typeof isSyncPending !== 'undefined' && isSyncPending) {
        checkSyncTime();
      }
    }, { passive: true });
  }

  const hudLiveStatus = document.getElementById("hud-live-status");
  if (hudLiveStatus) {
    hudLiveStatus.addEventListener('click', () => {
      window.syncToLive();
    }, { passive: true });
  }

  // 5. GESTIONE MENU E FUNZIONALITÀ ADMIN
  if (window.isAdmin) {
    // Menu Hamburger
    const hamburgerBtn = document.getElementById("hamburgerBtn");
    const menu = document.getElementById("menu");
    if (hamburgerBtn && menu) {
      hamburgerBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        menu.classList.toggle("hidden");
      });
      document.addEventListener("click", () => menu.classList.add("hidden"), { passive: true });
    }

    const gamePeriodEl = document.getElementById("game-period");
    if (gamePeriodEl) {
      gamePeriodEl.addEventListener("click", () => {
        window.gestisciGoLive();
      }, { passive: true });
    }

    // Bottone Logout
    const adminBtn = document.getElementById("adminBtn");
    if (adminBtn) {
      adminBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
      adminBtn.addEventListener("click", () => {
        if (confirm("Vuoi uscire dalla modalità Admin?")) {
          window.setLocalStorage("isAdmin", "false");
          window.setLocalStorage("AdminPassword", "");
          setTimeout(() => location.reload(), 500);
        }
      }, { passive: true });
    }

    // Contatore utenti online (Firebase Presence)
    const counterDiv = document.getElementById('adminCounter');
    const clockDiv = document.getElementById('systemClock');
    if (counterDiv) counterDiv.style.setProperty('display', 'flex', 'important');
    if (clockDiv) clockDiv.classList.remove('hidden');

    const presenceRef = window.db.ref("presence/online_users");
    presenceRef.on("value", (snap) => {
      let count = snap.exists() ? snap.numChildren() : 0;
      const countSpan = document.getElementById('onlineCount');
      if (countSpan) countSpan.innerText = count;
      window.db.ref("presence/user_count").set(count);
    });

  }

  // 6. UTILITY FINALI (Debug, Context Menu, Resize)
  document.addEventListener('contextmenu', (e) => {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
      e.preventDefault();
    }
  }, false);

  window.addEventListener('resize', () => updateDebugFooter());
  updateDebugFooter();

  // Avvia l'orologio di sistema per Admin verrà visualizzato in alto a destra, per gli altri no.
  setInterval(updateSystemClock, 1000);


  window.initHighlightsInterface();

}

function initSwiper() {
  const partiteFiltrate = window.getLocalStorage('partiteFiltrate');

  if (partiteFiltrate) {
    window.listaPartite = JSON.parse(partiteFiltrate);
    console.log("Dati ricevuti dal calendario:", window.listaPartite);
    
    // 1. Trova l'indice della partita attuale dentro l'array totale
    const currentIndex = window.listaPartite.findIndex(p => p.matchId === window.matchId);
    console.log("Indice del match attuale trovato:", currentIndex);
    
    if (currentIndex !== -1) {
      
      const slideModello = document.querySelector('.swiper-slide');
      const swiperWrapper = document.querySelector('.swiper-wrapper');

      // 2. PULIZIA DEI CLONI PRECEDENTI
      // Se il codice viene eseguito più volte, evita che le slide si accumulino all'infinito
      const slideEsistenti = swiperWrapper.querySelectorAll('.swiper-slide');
      slideEsistenti.forEach((slide, idx) => {
        if (idx > 0) slide.remove(); // Rimuove tutti i cloni vecchi lasciando solo la prima
      });

      // 3. GENERAZIONE DI TUTTE LE SLIDE
      // Cicliamo su tutto l'array originale senza limitazioni
      window.listaPartite.forEach((partita, index) => {
        if (index === 0) {
          // La prima slide del gruppo usa quella già presente fisicamente nell'HTML
          slideModello.setAttribute('data-match-id', partita.matchId);
        } else {
          // Tutte le altre partite vengono clonate e appese al wrapper dello Swiper
          const slideClonata = slideModello.cloneNode(true); 
          slideClonata.setAttribute('data-match-id', partita.matchId);
          swiperWrapper.appendChild(slideClonata);
        }
      });

      // 4. L'indice di partenza è esattamente la posizione del match corrente
      const initialSlideIdx = currentIndex;

      // 5. DISTRUZIONE DEL VECCHIO SWIPER (Se già esistente)
      if (window.matchSwiper) {
        window.matchSwiper.destroy(true, true);
      }

      // 6. INIZIALIZZAZIONE DI SWIPER
      // Assegnato a window.matchSwiper in modo che il blocco destroy funzioni nei ricaricamenti dinamici
      window.matchSwiper = new Swiper('.swiper', {
        initialSlide: initialSlideIdx, 
        direction: 'horizontal',
        loop: false, 
        touchStartPreventDefault: false 
      });

      // Intercetta lo swipe laterale per cambiare la partita (matchId)
      window.setLocalStorage("SWIPED_SLIDE", "false");

      window.matchSwiper.on('slideChange', () => {
        // Avendo caricato tutte le slide, activeIdx è DIRETTAMENTE l'indice corretto nell'array
        const activeIdx = window.matchSwiper.activeIndex;

        // Sincronizza il contatore globale e salvalo nel localStorage
        window.currentMatch = activeIdx;
        window.setLocalStorage("currentMatch", window.currentMatch);

        // Recupera i dati della partita corrispondente all'indice attivo
        const p = window.listaPartite[activeIdx];
        
        if (!p) return; // Sicurezza nel caso l'indice non sia valido

        // LOGICA DI CAMBIO PARTITA (Inalterata, salvataggio dati sul localStorage)
        window.setLocalStorage("matchId", p.matchId);
        window.setLocalStorage("teamA", p.squadraA);
        window.setLocalStorage("teamB", p.squadraB);
        window.setLocalStorage("puntiSquadraA", p.punteggioA || 0);
        window.setLocalStorage("puntiSquadraB", p.punteggioB || 0);
        window.setLocalStorage("convocazioni", p.convocazioni || "");
        window.setLocalStorage("videoURL", p.videoURL || "");
        window.setLocalStorage("videoId", window.extractVideoId(p.videoURL));
        window.setLocalStorage("matchStartTime", window.extractYoutubeTime(p.videoURL));
        window.setLocalStorage("oraInizioDiretta", p.oraInizioDiretta || "");
        window.setLocalStorage("isLive", p.isLive || false);
        window.setLocalStorage("statoPartita", p.statoPartita || "");

        window.setLocalStorage("USE_MATCH_HTML", false);
        window.setLocalStorage("SWIPED_SLIDE", "true");

        console.log("Swipe rilevato! Indice della partita corrente:", activeIdx);

        // Genera il nuovo URL e ricarica la pagina con il replace della cronologia
        const url = new URL(window.location.href);
        url.searchParams.set('matchId', p.matchId);
        window.location.replace(url.href);
      });

    } else {
      console.warn("Impossibile generare lo slider: il matchId attuale non è stato trovato nell'array delle partite.");
    }
  }
}

init();
