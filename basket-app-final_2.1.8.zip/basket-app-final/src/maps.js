window.datiLocali = [];
window.markerGroup = undefined;
window.isIOS;
window.map = null;

// Palette colori condivisa tra marker e legenda
// Palette colori: 1° campionato -> Azzurro (#007bff), 2° campionato -> Arancione (#ff6600)
const PALETTE_COLORI = ["#007bff", "#ff6600", "#28a745", "#dc3545", "#6f42c1"];

// Funzione helper per ricavare il colore in base al campionato
function getColoreCampionato(nomeCampionato) {
    const campionati = window.MY_TEAM_CAMPIONATO || [];
    const index = campionati.findIndex(c => String(nomeCampionato || "").includes(c));
    return index !== -1 ? PALETTE_COLORI[index % PALETTE_COLORI.length] : "#6c757d"; // Colore grigio di fallback
}

window.copiaIndirizzo = copiaIndirizzo;

function copiaIndirizzo(testo) {
    const btn = document.querySelector('.copy-btn');
    const originalHTML = btn.innerHTML;

    // Funzione per aggiornare l'interfaccia
    const showSuccess = () => {
        btn.innerHTML = '<i class="fas fa-check" style="color: #27ae60;"></i> Copiato!';
        setTimeout(() => { btn.innerHTML = originalHTML; }, 2000);
    };

    // 1. Prova con l'API moderna (Clipboard API)
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(testo)
            .then(showSuccess)
            .catch(err => console.error('Errore Clipboard API:', err));
    } 
    // 2. Fallback per contesti non sicuri (HTTP / Mobile locale)
    else {
        const textArea = document.createElement("textarea");
        textArea.value = testo;
        // Impedisce lo scroll della pagina mentre aggiungiamo l'elemento
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            const successful = document.execCommand('copy');
            if (successful) showSuccess();
        } catch (err) {
            console.error('Fallback copia fallito:', err);
        }

        document.body.removeChild(textArea);
    }
}

window.forzaAggiornamento = forzaAggiornamento;
function forzaAggiornamento() {
    const icon = document.getElementById('refresh-icon');
    icon.classList.add('rotating');
    LoadAddress();
}

function formattaData(dataStr, tipo = 'completa') {
    if (!dataStr) return "N.D.";
    let d;
    if (typeof dataStr === 'string' && dataStr.includes('/')) {
        const parti = dataStr.split('/');
        const anno = parti[2].length === 2 ? "20" + parti[2] : parti[2];
        d = new Date(anno, parti[1] - 1, parti[0]);
    } else {
        d = new Date(dataStr);
    }
    if (!d || isNaN(d.getTime())) return "N.D.";
    if (tipo === 'corta') return d.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit' });
    return d.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

window.applicaFiltro = applicaFiltro;
function applicaFiltro() {
    const radioSelezionato = document.querySelector('input[name="filtroPartite"]:checked');
    const filtro = radioSelezionato ? radioSelezionato.value : 'tutte';
    const oggi = new Date();
    oggi.setHours(0, 0, 0, 0);

    if (filtro === 'tutte') {
        renderizzaMappa(window.datiLocali);
    } else if (filtro === 'prossima') {
        // --- LOGICA FILTRO PROSSIMA PARTITA ---
        let prossimaPartita = null;
        let minDiff = Infinity;

        window.datiLocali.forEach(poi => {
            let dObj;
            if (typeof poi.dataPartita === 'string' && poi.dataPartita.includes('/')) {
                const parti = poi.dataPartita.split('/');
                dObj = new Date(parti[2], parti[1] - 1, parti[0]);
            } else {
                dObj = new Date(poi.dataPartita);
            }

            const diff = dObj.getTime() - oggi.getTime();
            // Cerchiamo la partita più vicina che sia oggi o nel futuro
            if (diff >= 0 && diff < minDiff) {
                minDiff = diff;
                prossimaPartita = poi;
            }
        });

        // Se l'abbiamo trovata, passiamo un array con un solo elemento
        renderizzaMappa(prossimaPartita ? [prossimaPartita] : []);
        
    } else {
        const filtrati = window.datiLocali.filter(poi => {
            let dObj;
            if (typeof poi.dataPartita === 'string' && poi.dataPartita.includes('/')) {
                const parti = poi.dataPartita.split('/');
                dObj = new Date(parti[2], parti[1] - 1, parti[0]);
            } else {
                dObj = new Date(poi.dataPartita);
            }
            if (isNaN(dObj.getTime())) return true;
            return filtro === 'future' ? dObj >= oggi : dObj < oggi;
        });
        renderizzaMappa(filtrati);
    }
}

function LoadAddress() {
    const params = new URLSearchParams({
        appVersion: window.APP_VERSION,
        teamId: window.getTeamId(),
        sheet: "Partite",
        userId: window.userId,
        action: "Get Map",
        details: JSON.stringify(window.getDeviceData)
    });

    fetch(`${window.getBackendUrl()}?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            const partite = Array.isArray(data) ? data : data.data;
            salvaDatiMappa(partite);
            window.datiLocali = JSON.parse(window.getLocalStorage("mappaLuoghi"));
            applicaFiltro();
            setTimeout(() => { document.getElementById('refresh-icon').classList.remove('rotating'); }, 1000);
        })
        .catch(err => {
            document.getElementById('refresh-icon').classList.remove('rotating');
            alert("Errore caricamento dati.");
        });
}

function renderizzaMappa(luoghiData) {
    window.markerGroup.clearLayers();
    const oggi = new Date();
    oggi.setHours(0, 0, 0, 0);

    // --- NUOVA LOGICA: TROVA LA PROSSIMA PARTITA ---
    let prossimaPartitaId = null;
    let minDiff = Infinity;

    luoghiData.forEach((poi, index) => {
        let dObj;
        if (typeof poi.dataPartita === 'string' && poi.dataPartita.includes('/')) {
            const parti = poi.dataPartita.split('/');
            dObj = new Date(parti[2], parti[1] - 1, parti[0]);
        } else {
            dObj = new Date(poi.dataPartita);
        }

        const diff = dObj.getTime() - oggi.getTime();
        // Se la partita è oggi o nel futuro e la differenza è la minore trovata finora
        if (diff >= 0 && diff < minDiff) {
            minDiff = diff;
            prossimaPartitaId = poi.coordinate; // Usiamo le coordinate come ID unico
        }
    });
    // ----------------------------------------------

    luoghiData.forEach(poi => {
        const coords = poi.coordinate.split(',').map(c => parseFloat(c.trim()));
        if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
            
            let dataPartitaObj;
            if (typeof poi.dataPartita === 'string' && poi.dataPartita.includes('/')) {
                const parti = poi.dataPartita.split('/');
                dataPartitaObj = new Date(parti[2], parti[1] - 1, parti[0]);
            } else {
                dataPartitaObj = new Date(poi.dataPartita);
            }

            const èPassata = dataPartitaObj < oggi;
            const classeEtichetta = èPassata ? 'map-label label-passata' : 'map-label label-futura';
            
            // ⚙️ Ottiene il colore dinamico da MY_TEAM_CAMPIONATO
            const color = getColoreCampionato(poi.campionato);

            // Determiniamo se questo marker deve pulsare
            const devePulsare = poi.coordinate === prossimaPartitaId;

            const marker = L.circleMarker([coords[0], coords[1]], {
                radius: 12, // Raggio fisso, non cambia mai
                fillColor: color,
                color: devePulsare ? "#fff" : "#fff", // Colore del bordo
                weight: devePulsare ? 3 : 2,
                opacity: 1,
                fillOpacity: 0.8,
                interactive: true,
                className: devePulsare ? 'prossima-partita-pulse' : '' 
            });

            marker.bindTooltip(formattaData(poi.dataPartita, 'corta'), {
                permanent: true, 
                direction: 'top',
                offset: [0, -12],
                className: classeEtichetta
            });

            // Logica Navigatori
            const coordsStr = `${coords[0]},${coords[1]}`;
            const labelEncoded = encodeURIComponent(poi.luogo);
            const indirizzoPerCopia = poi.luogo.replace(/'/g, "\\'");
            const urlGoogle = `https://www.google.com/maps/search/?api=1&query=${coordsStr}`;
            const urlApple  = `maps://?q=${labelEncoded}&ll=${coordsStr}`;
            const urlWaze   = `https://waze.com/ul?ll=${coordsStr}&navigate=yes`;

            // Utilizza il protocollo geo: che permette al sistema di chiedere con quale app aprire
            const urlNavigatoreGenerico = `geo:${coordsStr}?q=${coordsStr}(${labelEncoded})`;

            let appleBtn = window.isIOS ? `<a href="${urlApple}" class="map-choice-btn"><i class="fab fa-apple btn-apple"></i> Mappe (iOS)</a>` : "";

            // Funzione rapida per ottenere il giorno della settimana abbreviato
            const dataObj = new Date(poi.dataPartita.split('/').reverse().join('-')); // Converte DD/MM/YYYY in YYYY-MM-DD
            const giorni = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
            const giornoSettimana = !isNaN(dataObj.getTime()) ? giorni[dataObj.getDay()] : "";

            const popupContent = `
                <div style="font-size: 1.1em; min-width: 210px; padding: 5px;">
                    <strong style="color: ${color}; font-size: 1.2em;">${poi.campionato}</strong>
                    ${devePulsare ? ' <span style="font-size:0.7em; background:red; color:white; padding:2px 5px; border-radius:4px; vertical-align:middle;">PROSSIMA</span>' : ''}<br>
                    
                    <div style="color: #666; font-size: 0.9em; margin-bottom: 2px;">${poi.avversario}</div>
                    
                    <div style="color: #333; font-size: 0.9em; margin-bottom: 2px;">
                        <i class="far fa-calendar-alt" style="color: #0056b3;"></i> 
                        <span style="font-weight: bold;">${giornoSettimana}</span> ${poi.dataPartita} 
                        <i class="far fa-clock" style="color: #0056b3; margin-left: 8px;"></i> ${poi.orario}
                    </div>
                    
                    <div style="font-weight: bold; font-size: 0.9em;">${poi.luogo}</div>
                    
                    <button class="copy-btn" onclick="window.copiaIndirizzo('${indirizzoPerCopia}')">
                        <i class="fas fa-copy"></i> Copia indirizzo
                    </button>
                    
                    <hr style="margin: 12px 0; border: 0; border-top: 1px solid #eee;">
                    
                    <div class="map-choice-container">
                        <div style="font-size: 0.75rem; font-weight: bold; color: #999; text-transform: uppercase; margin-bottom: 4px;">Naviga con:</div>
                        <a href="${urlGoogle}" target="_blank" class="map-choice-btn"><i class="fab fa-google btn-google"></i> Google Maps</a>
                        ${appleBtn}
                        <a href="${urlWaze}" target="_blank" class="map-choice-btn"><i class="fab fa-waze btn-waze"></i> Waze</a>
                        <a href="${urlNavigatoreGenerico}" class="map-choice-btn"><i class="fas fa-location-arrow btn-tomtom"></i> Altri Navigatori</a>
                    </div>
                </div>
            `;                    
            marker.bindPopup(popupContent);
            marker.on('click', function() { this.openPopup(); });
            window.markerGroup.addLayer(marker);
        }
    });
    window.map.addLayer(window.markerGroup);
    if (luoghiData.length > 0) window.map.fitBounds(window.markerGroup.getBounds(), { padding: [50, 50] });

    // Se c'è un solo punto (o lo zoom è diventato troppo stretto)
    // limitiamo lo zoom massimo a 13 (puoi cambiare questo valore)
    if (window.map.getZoom() > 13) {
        window.map.setZoom(13);
    }
}

function init()
{

    // 1. Controllo: siamo nella pagina mappa?
    const mapContainer = document.getElementById('map');
    if (!mapContainer) return;

    // 2. Controllo: Leaflet è caricato?
    if (typeof L === 'undefined') {
        console.warn("Leaflet non ancora caricato, riprovo tra 100ms...");
        setTimeout(initMappa, 100);
        return;
    }

    // Check dispositivo iOS
    window.isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

    // Layer 1: OpenStreetMap Classica (Stradale)
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');

    // Layer 2: Google Satellite (Solo foto)
    const satellitePuro = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
    });

    // Layer 3: Google Hybrid (Satellite + Strade/Nomi)
    const hybrid = L.tileLayer('http://{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
    });        
    const baseMaps = {
        "Stradale": osm,
        "Satellitare": hybrid
    };

    // 1. Inizializza la mappa senza il controllo zoom automatico
    window.map = L.map('map', {
        tap: false,
        tapTolerance: 15,
        zoomControl: false, // <--- Disabilita il posizionamento automatico in alto a sinistra
        layers: [osm] // Carica OSM come predefinito
    }).setView([45.2, 7.8], 8);

    // 2. Aggiungi il controllo zoom in basso a sinistra (o bottomright se preferisci)
    L.control.zoom({
        position: 'topright'
    }).addTo(window.map);

    // Aggiungiamo il controllo alla mappa
    L.control.layers(baseMaps, null, {
        position: 'bottomleft' // Puoi metterlo dove preferisci
    }).addTo(window.map);        

    // Aggiungi questo subito sotto per alzare i tasti zoom di qualche pixel
    const zoomControl = document.querySelector('.leaflet-bottom.leaflet-left');
    zoomControl.style.marginBottom = "25px";
    zoomControl.style.marginLeft = "10px";

    // Fai lo stesso per la legenda se serve
    const legendControl = document.querySelector('.leaflet-bottom.leaflet-right');
    if (legendControl) {
        legendControl.style.marginBottom = "25px";
        legendControl.style.marginRight = "10px";
    }

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(window.map);

    window.markerGroup = new L.featureGroup();

    const cacheMappa = window.getLocalStorage("mappaLuoghi");
    if (cacheMappa) {
        try {
            window.datiLocali = JSON.parse(cacheMappa);
            applicaFiltro(); 
        } catch (e) {
            LoadAddress();
        }
    } else {
        window.forzaAggiornamento();
    }

    window.registerUserId().then((data) => {});

    // --- LEGENDA DINAMICA CAMPIONATO ---
    const legend = L.control({position: 'bottomright'});
    legend.onAdd = function (map) {
        const div = L.DomUtil.create('div', 'legend');
        const campionatiConfig = window.MY_TEAM_CAMPIONATO;
        
        let htmlContent = '<b>Campionato</b><br>';
        
        if (Array.isArray(campionatiConfig) && campionatiConfig.length > 0) {
            campionatiConfig.forEach((camp, idx) => {
                const color = PALETTE_COLORI[idx % PALETTE_COLORI.length];
                htmlContent += `<i style="background: ${color}"></i> ${camp}<br>`;
            });
        } else {
            // Fallback se la variabile non è definita o non è un array
            htmlContent += '<i style="background: #6c757d"></i> N.D.';
        }
        
        div.innerHTML = htmlContent;
        return div;
    };
    legend.addTo(window.map);

}

init();