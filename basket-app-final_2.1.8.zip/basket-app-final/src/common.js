//----------------------------------------------------------------
// Carica Eruda su locale O sul repository di test (bsk-tst-2026)
// NON si attiva sul repository di produzione (basket-app)
//----------------------------------------------------------------
const hostname = window.location.hostname;
const pathname = window.location.pathname;

const isLocal = hostname === "localhost" || hostname === "127.0.0.1" || hostname.includes("192.168");
// Rendi il controllo più flessibile (case insensitive e senza slash vincolanti)
const isTestRepo = pathname.toLowerCase().includes("bsk-tst-2026");

if (isLocal || isTestRepo) {
    const script = document.createElement('script');
    script.src = "//cdn.jsdelivr.net/npm/eruda"; // Protocollo relativo
    document.head.appendChild(script);
    script.onload = function () {
        eruda.init();
        console.log("Eruda inizializzato con successo");
    };
}
//  else {
//     alert("Eruda NON caricato. Path attuale: " + pathname + " hostname: " + hostname);
// }
//------------------------------------------

window.isAdmin = false;
window.giocatoriA = [];
window.numeriMaglia = [];
window.USE_FIREBASE = true;
window.userId = undefined;
window.getDeviceData = undefined;


//------------------------------------------------------------------------------------------------------------------
// 1. Configurazione (copiala dalla console di Firebase: Impostazioni Progetto)
const firebaseConfig = {
  databaseURL: "https://locch65-basketapp-default-rtdb.europe-west1.firebasedatabase.app/",
};

// 1. Inizializzazione
firebase.initializeApp(firebaseConfig);
window.db = firebase.database();

// 1. Riferimenti
const connectedRef = window.db.ref(".info/connected");
const presenceRef = window.db.ref("presence/online_users"); // Nodo che conterrà gli utenti
const userRef = presenceRef.push(); // Crea un ID univoco per questa sessione
const countDisplayRef = window.db.ref("presence/user_count"); // Dove salveremo il numero finale

// 2. Gestione Connessione/Disconnessione
connectedRef.on("value", (snap) => {
  if (snap.val() === true) {
    // Quando mi disconnetto, rimuovi il mio ID univoco
    userRef.onDisconnect().remove();
    
    // Segnala che sono online
    userRef.set(true);
    
    console.log("Connesso al server!");
  }
});

//------------------------------------------------------------------------------------------------------------------
window.saveToFirebaseAll = saveToFirebaseAll;
function saveToFirebaseAll() {
  if (window.isAdmin) {
    window.saveToFirebaseHistory('partite/' + window.matchId, window.dettagliGara); 
    window.saveToFirebaseHistory('statistiche/' + window.matchId, window.giocatoriObj);
    window.saveToFirebaseHistory('events/' + window.matchId, window.fullMatchHistory);
    window.saveToFirebaseHistory('livePIPs/' + window.matchId, window.livePipData);
  }
}

// ---------------------------------------------------------------------------------------------
window.saveToFirebaseHistory = saveToFirebaseHistory;
function saveToFirebaseHistory(path, data) {
// ---------------------------------------------------------------------------------------------
  // Scrittura su Firebase
  const newPath = window.APP_VERSION.startsWith("1.") ? path : window.getTeamId() + "/" + path;
  window.db.ref(newPath).set(data)
    .then(() => {
      console.log("Firebase aggiornato:  " + newPath);
    })
    .catch((error) => {
      console.error("Errore Firebase: ", error);
    });
}

// ---------------------------------------------------------------------------------------------
window.saveToFirebaseRoster = saveToFirebaseRoster;
function saveToFirebaseRoster(path, data) {
// ---------------------------------------------------------------------------------------------
  // Scrittura su Firebase
  const newPath = window.APP_VERSION.startsWith("1.") ? path : window.getTeamId() + "/" + path;
  window.db.ref(newPath).set(data)
    .then(() => {
      console.log("Firebase aggiornato: " + newPath);
    })
    .catch((error) => {
      console.error("Errore Firebase: ", error);
    });
}

// ---------------------------------------------------------------------------------------------
window.readFromFirebaseHistory = readFromFirebaseHistory;
async function readFromFirebaseHistory(path) {
// ---------------------------------------------------------------------------------------------
  try {

    const newPath = window.APP_VERSION.startsWith("1.") ? path : window.getTeamId() + "/" + path;
    // Utilizziamo .once('value') per una lettura singola dei dati
    const snapshot = await window.db.ref(newPath).once('value');
    
    // Verifichiamo se il dato esiste effettivamente nel database
    if (snapshot.exists()) {
      return snapshot.val(); // Restituisce la struttura con i dati della tabella
    } else {
      console.warn("Nessun dato trovato al percorso specificato: " + newPath);
      return null;
    }
  } catch (error) {
    // Gestione errori di connessione o permessi
    console.error("Errore di connessione o accesso a Firebase: ", error);
    return null;
  }
}

window.getTeamName = getTeamName;
function getTeamName(numero) {
  if (numero === "") {
    return "Squadra B";
  }
  else {
    return window.isMyTeam(window.teamA) ? window.teamA : window.teamB;
  }
}

// Aggiungi 'async' qui
window.registerUserId = registerUserId;
async function registerUserId() {
  // 1. Inizializzazione base (opzionale se sovrascritta dopo)
  window.getDeviceData = {
    os: navigator.platform,
    userAgent: navigator.userAgent,
    isMobile: /Mobi|Android/i.test(navigator.userAgent),
    screenResolution: `${window.screen.width}x${window.screen.height}`,
    language: navigator.language
  };

  // --- POLYFILL randomUUID (Necessario per test su IP locale/Hotspot non HTTPS) ---
  if (!window.crypto.randomUUID) {
    window.crypto.randomUUID = function() {
      return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
      );
    };
    console.warn("randomUUID: Polyfill applicato (ambiente non sicuro).");
  }

  // 2. Gestione User ID
  window.userId = window.getLocalStorage('webapp_user_id');

  if (!window.userId) {
    window.userId = crypto.randomUUID();
    window.setLocalStorage('webapp_user_id', window.userId);
  }

  console.log("User ID corrente:", window.userId);


  // 3. ASPETTA il completamento delle statistiche
  // Usiamo await per bloccare l'esecuzione finché collectDeviceStats non ha finito
  const stats = await collectDeviceStats(); 
  
  // Ora getDeviceData conterrà i dati reali ritornati dalla funzione
  window.getDeviceData = stats;

  console.log("Registrazione completata per l'utente:", window.userId);
  console.log("Dati dispositivo:", getDeviceData);
  
  return { userId: window.userId, getDeviceData: window.getDeviceData };
}

async function collectDeviceStats() {
    let info = {
        os: "Unknown",
        model: "Unknown",
        screenSize: `${window.screen.width}x${window.screen.height}`,
        isTouch: ('ontouchstart' in window || navigator.maxTouchPoints > 0),
        browser: navigator.userAgent
    };

    // 1. TENTATIVO CON API MODERNE (Client Hints)
    if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
        try {
            const highEntropy = await navigator.userAgentData.getHighEntropyValues(['model', 'platform', 'platformVersion']);
            info.model = highEntropy.model || "Unknown";
            info.os = `${highEntropy.platform} ${highEntropy.platformVersion}`;
        } catch (e) { 
            // Fallback al parsing manuale
        }
    }

    // 2. ANALISI STRINGA USER AGENT (Fallback o Raffinamento)
    const ua = navigator.userAgent;

    if (info.model === "Unknown" || info.model === "") {
        // --- ANDROID ---
        if (/android/i.test(ua)) {
            info.os = "Android";
            // Regex migliorata: cerca il testo dopo la versione di Android, fermandosi al primo punto e virgola o alla fine della parentesi
            // Esempio: "Mozilla/5.0 (Linux; Android 13; Pixel 6) ..." -> Pixel 6
            const androidMatch = ua.match(/Android\s+[^;]+;\s+([^;)]+)/);
            if (androidMatch) {
                info.model = androidMatch[1].split('Build/')[0].trim();
            } else {
                info.model = "Android Device";
            }
        } 
        // --- iOS (iPhone/iPad) ---
        else if (/iPhone|iPad|iPod/i.test(ua)) {
            info.os = "iOS";
            // Apple nasconde il modello esatto (es. iPhone 15) per privacy.
            // Possiamo però distinguere tra iPhone e iPad.
            if (/iPad/.test(ua)) {
                info.model = "iPad";
            } else if (/iPhone/.test(ua)) {
                info.model = "iPhone";
            }
            // Aggiungiamo la risoluzione per aiutare l'identificazione manuale
            info.model += ` (${info.screenSize})`;
        }
        // --- DESKTOP ---
        else if (/Windows/i.test(ua)) {
            info.os = "Windows";
            info.model = "PC Desktop";
        }
        else if (/Macintosh/i.test(ua)) {
            info.os = "MacOS";
            info.model = "Mac";
        }
    }

    return info;
}

window.popolaGiocatoriA = popolaGiocatoriA;
function popolaGiocatoriA(datiRoster) {
  if (!datiRoster || !Array.isArray(datiRoster)) return;

  // Ordiniamo il roster per numero di maglia (opzionale, ma consigliato per consistenza)
  const rosterOrdinato = [...datiRoster].sort((a, b) => 
    parseInt(a["Numero Maglia"]) - parseInt(b["Numero Maglia"])
  );

  // Mappiamo i nomi nel formato "I. Cognome"
  window.giocatoriA = rosterOrdinato.map(p => {
    const iniziale = p.Nome ? p.Nome.charAt(0).toUpperCase() + ". " : "";
    return iniziale + p.Cognome;
  });

// Aggiungiamo "Squadra B" come ultimo elemento 
  window.giocatoriA.push("Squadra B");

  // Mappiamo i numeri (come stringhe)
  window.numeriMaglia = rosterOrdinato.map(p => String(p["Numero Maglia"]));

  window.numeriMaglia.push(""); // Opzionale: mantiene la corrispondenza con l'indice di giocatoriA

  console.log("Roster mappato con successo:", window.giocatoriA.length, "giocatori.");
}

function isQuintettoCompleto() {
    return window.giocatoriObj.filter(g => g.id !== "Squadra_B" && g.stato === "In").length === 5;
}

window.GetCognome = GetCognome;
function GetCognome(idGiocatore) {

  if (idGiocatore === "") return window.isMyTeam(window.teamA) ? window.teamB : window.teamA;
  
  // 1. Troviamo l'indice del giocatore cercando l'ID (convertito in stringa) 
  // nell'array window.numeriMaglia
  const index = window.numeriMaglia.findIndex(n => String(n) === String(idGiocatore));

  // 2. Se l'ID non viene trovato, restituiamo il nome della squadra avversaria
  if (index === -1) return (window.isMyTeam(window.teamA) ? window.teamB : window.teamA);

  // 3. Recuperiamo la stringa completa (es: "N. Cognome") dall'array giocatoriA
  const nomeCompleto = window.giocatoriA[index];

  // 4. Dividiamo la stringa: il primo elemento è l'iniziale del nome, 
  // il resto (gestendo cognomi composti) è il cognome
  const parti = nomeCompleto.split(" ");

  // Rimuoviamo il primo elemento (iniziale del nome) e riuniamo il resto
  const cognome = parti.slice(1).join(" ");

  return cognome;
}

function isMobile() { return /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent); }

window.vibrate = vibrate;
function vibrate(milliseconds) {
  if (isMobile()) {
      if (navigator.vibrate) navigator.vibrate(milliseconds); // Funziona solo su Android/Chrome
  }
}

window.parseItalianDate = parseItalianDate;
function parseItalianDate(dateStr, timeStr) {
    const [giorno, mese, anno] = dateStr.split("/").map(Number);
    const [ore, minuti] = timeStr.split(":").map(Number);
    return new Date(anno, mese - 1, giorno, ore, minuti);
}


window.isInTheFuture = isInTheFuture;
function isInTheFuture(newDate) {
    const today = new Date();
    today.setHours(0, 0, 0, 0); 
    let tempDate;
    if (typeof newDate === 'string' && newDate.includes('/')) {
        const parti = newDate.split('/');
        tempDate = new Date(parti[2], parti[1] - 1, parti[0]);
    } else {
        tempDate = new Date(newDate);
    }
    return tempDate > today;
}

window.hmsToSeconds  = hmsToSeconds;
function hmsToSeconds(hms) {
  if (!hms || typeof hms !== 'string') return 0;
  
  const parts = hms.split(':').map(Number);
  
  // Se parts ha 3 elementi: h, m, s
  // Se parts ha 2 elementi: h, m
  if (parts.length === 3) {
    const [h, m, s] = parts;
    return (h * 3600) + (m * 60) + s;
  } else if (parts.length === 2) {
    const [h, m] = parts;
    return (h * 3600) + (m * 60);
  }
  
  return 0; // Caso di stringa non valida o formato diverso
}

window.secondsToHms = secondsToHms;
function secondsToHms(d) {
  d = Number(d);
  
  // 1. Definiamo i secondi totali in un giorno
  const SECONDI_IN_24H = 86400;

  // 2. Applichiamo il modulo matematico per restare nel range 0 - 86399
  // Questa formula gestisce correttamente anche i numeri negativi
  var secondiNormalizzati = ((d % SECONDI_IN_24H) + SECONDI_IN_24H) % SECONDI_IN_24H;

  // 3. Calcoliamo ore, minuti e secondi sui secondi normalizzati
  var h = Math.floor(secondiNormalizzati / 3600);
  var m = Math.floor((secondiNormalizzati % 3600) / 60);
  var s = Math.floor(secondiNormalizzati % 60);

  // 4. Formattazione con zero iniziale (pad)
  return (h < 10 ? "0" + h : h) + ":" + 
         (m < 10 ? "0" + m : m) + ":" + 
         (s < 10 ? "0" + s : s);
}

window.aggiungiSecondiAOrario = aggiungiSecondiAOrario;
function aggiungiSecondiAOrario(orarioStr, secondiDaAggiungere) {
  if (!orarioStr) return "00:00:00";
  let totalSeconds = hmsToSeconds(orarioStr) + parseInt(secondiDaAggiungere || 0);

  // Riconversione in HH:MM:SS
  let h = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
  let m = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
  let s = (totalSeconds % 60).toString().padStart(2, '0');
  return `${h}:${m}:${s}`;
}

/**
 * Restituisce l'ID del video attualmente in live streaming sul canale @ItIsPolitime.
 * @param {string} apiKey - La tua YouTube Data API Key.
 * @returns {Promise<string>} - L'ID del video live o un messaggio di errore.
 *
 * Esempio di utilizzo:
 * getCurrentLiveIdByChannel("LA_TUA_API_KEY")
 *   .then(id => console.log("ID del video live attuale: " + id))
 *   .catch(err => console.log(err.message));
*/
window.getCurrentLiveIdByChannel = getCurrentLiveIdByChannel;
function getCurrentLiveIdByChannel(apiKey) {

//  var channelId = "UCQfwfsi5VrQ8yKZ-UWmAEFg";   // L'ID del canale per France 24 English è UCQfwfsi5VrQ8yKZ-UWmAEFg
  var channelId = "UCZFhQQaIv8Uv59c_4WnlBPA";   // L'ID del canale per @ItIsPolitime è UCZFhQQaIv8Uv59c_4WnlBPA
  
  // Endpoint search filtrato per tipo 'video' ed eventType 'live'
  var apiUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=" + 
               channelId + "&type=video&eventType=live&key=" + apiKey;

  return fetch(apiUrl)
    .then(function (response) {
      if (!response.ok) throw new Error("Errore API YouTube: " + response.status);
      return response.json();
    })
    .then(function (data) {
      if (data.items && data.items.length > 0) {
        // Restituisce l'ID del primo (e solitamente unico) video in diretta
        return data.items[0].id.videoId;
      } else {
        throw new Error("Il canale non è attualmente in live streaming.");
      }
    })
    .catch(function (error) {
      console.error("Errore:", error.message);
      throw error;
    });
}

function getLiveStartTimeById(youtubeUrl, apiKey) {
  // 
  // Accetta l'URL di un video YouTube e restituisce l'ora di inizio reale.
  // @param {string} youtubeUrl - L'indirizzo completo del video.
  // @param {string} apiKey - La tua YouTube Data API Key.
  // @returns {Promise<string>} - Una stringa con la data/ora o l'errore.
  // 

  //// 1. Estrazione ID Video
  //var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  //var match = youtubeUrl.match(regExp);
  //var videoId = (match && match[2].length === 11) ? match[2] : null;
  //
  //if (!videoId) {
  //    return Promise.reject("URL YouTube non valido");
  //}

  var apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=liveStreamingDetails&id=" + window.videoId + "&key=" + apiKey;

  // Usiamo fetch con le Promises (.then) invece di await
  return fetch(apiUrl)
    .then(function (response) {
      if (!response.ok) throw new Error("Errore API: " + response.status);
      return response.json();
    })
    .then(function (data) {
      if (!data.items || data.items.length === 0) {
        throw new Error("Video non trovato");
      }

      var live = data.items[0].liveStreamingDetails;
      if (!live) {
        throw new Error("Questo non è un video live");
      }

      // Restituiamo l'ora reale di inizio (o quella programmata se non è ancora partito)
      return live.actualStartTime || live.scheduledStartTime || "Data non disponibile";
    });
}

function formattaOrarioRoma(isoString) {
  try {
    const data = new Date(isoString);
    if (isNaN(data.getTime())) return "00:00:00";

    // Converte e formatta per il fuso orario di Roma (gestisce ora legale/solare)
    return data.toLocaleTimeString('it-IT', {
      timeZone: 'Europe/Rome',
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  } catch (e) {
    return "00:00:00";
  }
}

window.CheckYoutubeAndASave = CheckYoutubeAndASave;
function CheckYoutubeAndASave(videoId, myApiKey) {
   // Controlla l'orario di inizio, lo salva localmente in formato HH:MM:SS (Roma)
   // usando la chiave yt_start_. In caso di errore restituisce "00:00:00".

  if (!videoId) {
    return Promise.resolve("00:00:00");
  }

  // 1. Controllo LocalStorage con la chiave richiesta
  var datoSalvato = window.getLocalStorage("yt_start_" + videoId);

  if (datoSalvato) {
    // Se il dato è già un orario HH:MM:SS lo restituisce, 
    // se fosse ancora in formato ISO lo formatta al volo
    if (datoSalvato.includes("T") || datoSalvato.includes("Z")) {
      return Promise.resolve(formattaOrarioRoma(datoSalvato));
    }
    console.log("Dato recuperato dalla memoria locale (yt_start_):", datoSalvato);
    return Promise.resolve(datoSalvato);
  }

  // 2. Se non c'è, procediamo con la chiamata API YouTube
  return getLiveStartTimeById(videoId, myApiKey)
    .then(function (startTimeISO) {
      // Trasformiamo l'ora ISO ricevuta da YouTube in ora di Roma
      const oraRoma = formattaOrarioRoma(startTimeISO);

      // Salviamo l'ora di Roma nel localStorage con la chiave yt_start_
      window.setLocalStorage("yt_start_" + videoId, oraRoma);

      console.log("Successo! Ora salvata in yt_start_:", oraRoma);
      return oraRoma;
    })
    .catch(function (errore) {
      throw new Error("Errore durante il recupero da YouTube: " + errore);
      //alert("Errore durante il recupero da YouTube:", errore);
      //return "00:00:00";
    });
}

window.extractVideoId = extractVideoId;
function extractVideoId(input) {
  if (!input) return "";
  if (input.includes("you"))
    return window.extractYouTubeId(input)
  else if (input.includes("twitch"))
    return window.extractTwitchId(input);
}


/**
 * Estrae l'ID o il nome del canale da un input/URL di Twitch.
 * Gestisce: Live, VODs (/videos/ID) e Clips (/clip/ID o clips.twitch.tv/ID)
 * @param {string} input - URL di Twitch o ID diretto
 * @returns {string} ID del video, della clip o il nome del canale (stringa vuota se non valido)
 */
window.extractTwitchId = extractTwitchId;
function extractTwitchId(input) {
  try {
    input = input.trim();
    if (!input) return "";

    // 1. Se l'input è già solo un ID numerico (VOD) o un codice alfanumerico tipico di una clip
    // (Le clip di Twitch usano parole mistiche tipo "CoyElegantOcelotVoteYea")
    if (/^\d+$/.test(input) || /^[a-zA-Z0-9_-]+$/.test(input) && !input.includes(".")) {
      return input;
    }

    const urlObj = new URL(input);
    const hostname = urlObj.hostname.toLowerCase();
    const pathname = urlObj.pathname;

    // 2. GESTIONE DOMINIO CLIP (clips.twitch.tv/NomeClip)
    if (hostname === "clips.twitch.tv") {
      return pathname.slice(1).split(/[?&]/)[0];
    }

    // 3. GESTIONE DOMINIO PRINCIPALE (twitch.tv)
    if (hostname.includes("twitch.tv")) {
      const partiPath = pathname.split("/").filter(p => p.length > 0);

      if (partiPath.length > 0) {
        // Caso VOD: twitch.tv/videos/123456789
        if (partiPath[0] === "videos" && partiPath[1]) {
          return partiPath[1].split(/[?&]/)[0];
        }
        
        // Caso Clip standard: twitch.tv/nomecanale/clip/NomeClip
        if (partiPath[1] === "clip" && partiPath[2]) {
          return partiPath[2].split(/[?&]/)[0];
        }

        // Caso Live standard: twitch.tv/nomecanale
        // Restituisce il nome del canale (utile per incorporare lo stream live)
        return partiPath[0].split(/[?&]/)[0];
      }
    }

    return "";
  } catch (e) {
    return "";
  }
}

window.extractYouTubeId = extractYouTubeId;
function extractYouTubeId(input) {
  try {
    if (/^[a-zA-Z0-9_-]{11}$/.test(input)) return input;
    const urlObj = new URL(input);
    if (urlObj.searchParams.has("v")) return urlObj.searchParams.get("v");
    if (urlObj.hostname.includes("youtu.be")) return urlObj.pathname.slice(1);
    if (urlObj.pathname.includes("/embed/")) return urlObj.pathname.split("/embed/")[1].split(/[?&]/)[0];
    if (urlObj.pathname.includes("/live/")) return urlObj.pathname.split("/live/")[1].split(/[?&]/)[0];
    return "";
  } catch (e) {
    return "";
  }
}

window.extractYoutubeTime = extractYoutubeTime;
function extractYoutubeTime(input) {
  try {
    if (input === "") return 0;
    const urlObj = new URL(input);
    if (urlObj.searchParams.has("t")) {
      const t = urlObj.searchParams.get("t");
      const match = t.match(/(?:(\d+)m)?(?:(\d+)s)?$/);
      if (match) {
        const minutes = parseInt(match[1] || "0", 10);
        const seconds = parseInt(match[2] || "0", 10);
        return minutes * 60 + seconds;
      }
      return parseInt(t, 10);
    }
    return 1; // PEZZA altrimenti non funzionano gli highlights. Prima era 0
  } catch (e) {
    console.error("Input non valido:", e);
    return 1; // PEZZA altrimenti non funzionano gli highlights. Prima era 0
  }
}

function createAdminPopup() {
  // 1. Verifica se esiste già
  let popup = document.getElementById("adminPopup");

  if (popup) {
    popup.style.display = "flex";
    const inputPass = document.getElementById("adminPassword");
    setTimeout(() => inputPass.focus(), 50);
    return;
  }

  // 2. Iniezione degli STILI INLINE (CSS-in-JS)
  const style = document.createElement('style');
  style.textContent = `
    #adminPopup {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background-color: rgba(0, 0, 0, 0.85); /* Fallback per var(--overlay) */
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 2000;
    }
    #adminPopup .popup-content {
      background-color: #1e1e1e; /* Fallback per var(--card-color) */
      border: 2px solid var(--admin-color); /* definito in index.html */
      border-radius: 20px;
      padding: 3rem;
      width: 85%;
      max-width: 32rem;
      text-align: center;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
    }
    #adminPopup h3 {
      margin: 0 0 1.5rem 0;
      color: #ffcc00;
      font-size: 2.2rem;
      font-family: sans-serif;
    }
    #adminPassword {
      width: 100%;
      padding: 1.2rem;
      margin-bottom: 2rem;
      border-radius: 10px;
      border: 1px solid #444;
      background: #2a2a2a;
      color: white;
      font-size: 1.8rem;
      text-align: center;
      box-sizing: border-box;
    }
    .popup-buttons {
      display: flex;
      gap: 1rem;
    }
    #confirmAdmin, #closeAdmin {
      flex: 1;
      padding: 1.2rem;
      border-radius: 10px;
      border: none;
      font-weight: bold;
      font-size: 1.4rem;
      cursor: pointer;
      text-transform: uppercase;
    }
    #confirmAdmin { background-color: #ffcc00; color: black; }
    #closeAdmin { background-color: #444; color: white; }
    .hidden { display: none !important; }
  `;
  document.head.appendChild(style);

  // 3. Creazione dell'elemento POPUP
  popup = document.createElement("div");
  popup.id = "adminPopup";
  popup.innerHTML = `
    <div class="popup-content">
      <h3>Accesso Admin</h3>
      <input type="password" id="adminPassword" placeholder="Password" />
      <div class="popup-buttons">
        <button id="confirmAdmin">Conferma</button>
        <button id="closeAdmin">Annulla</button>
      </div>
    </div>
  `;
  document.body.appendChild(popup);

  const inputPass = document.getElementById("adminPassword");
  setTimeout(() => inputPass.focus(), 50);

  // --- LOGICA FUNZIONALE ---

  const closePopup = () => {
    popup.style.display = "none";
    inputPass.value = ""; // Pulisce la pass alla chiusura
  };

  const handleLogin = () => {
    const pass = inputPass.value;
    if (pass === "007") {
      window.isAdmin = true;
      window.setLocalStorage("isAdmin", "true");
      window.setLocalStorage("AdminPassword", pass);
      window.updateTheme();

      const adminBtn = document.getElementById("adminBtn");
      if (adminBtn) {
        adminBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
      }
      closePopup();
      window.createAI_Interface();
    } else {
      alert("Password errata!");
    }
  };

  // Event Listeners
  document.getElementById("closeAdmin").onclick = closePopup;
  document.getElementById("confirmAdmin").onclick = handleLogin;

  inputPass.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleLogin();
    }
  });

  popup.addEventListener("click", (e) => {
    if (e.target === popup) closePopup();
  });
}

window.Login = Login;
function Login() {
    // 1. Se l'utente è già Admin, gestiamo il Logout
    const isAdmin = window.getLocalStorage("isAdmin") === "true";

    if (isAdmin) {
        if (confirm("Vuoi uscire dalla modalità Admin?")) {
            window.setLocalStorage("isAdmin", "false");
            window.setLocalStorage("AdminPassword", "");
            window.updateTheme();
            location.reload();
        }
        return;
    }

    // 2. Se non è admin, mostriamo il popup di login
    if (typeof createAdminPopup === "function") {
        createAdminPopup();
        // Assicuriamoci che sia visibile
        const p = document.getElementById("adminPopup");
        p.classList.remove("hidden");
        p.style.display = "flex";
    }
}

window.aggiornaDatiRosterEStats = aggiornaDatiRosterEStats;
async function aggiornaDatiRosterEStats(what = "all") {
    /**
     * Carica Roster e/o Statistiche in base al parametro 'what' e li salva nel localStorage.
     * @param {string} what - "all", "roster", "stats" o null.
     * @returns {Promise<object|null>} I dati caricati o null in caso di errore.
     */
    const loadingEl = document.getElementById("loading");
    
    try {
        const promises = [];
        const types = [];

        // Definiamo cosa caricare
        const caricaRoster = (what === "all" || what === "roster" || what === null);
        const caricaStats = (what === "all" || what === "stats" || what === null);

        // Prepariamo la fetch per il Roster
        if (caricaRoster) {
            const paramsRoster = new URLSearchParams({
                appVersion: window.APP_VERSION,
                teamId: window.getTeamId(),
                sheet: "Roster",
                userId: window.userId,
                action: "Get Roster",
                details: JSON.stringify(getDeviceData)
            });
            promises.push(fetch(`${window.getBackendUrl()}?${paramsRoster.toString()}`).then(res => res.json()));
            types.push("roster");
        }

        // Prepariamo la fetch per le Statistiche
        if (caricaStats) {
            const paramsStats = new URLSearchParams({
                appVersion: window.APP_VERSION,
                teamId: window.getTeamId(),
                getAllStats: "1",
                userId: window.userId,
                action: "Get All Stats",
                details: JSON.stringify(getDeviceData)
            });
            promises.push(fetch(`${window.getBackendUrl()}?${paramsStats.toString()}`).then(res => res.json()));
            types.push("stats");
        }

        // Esecuzione delle fetch (parallele se più di una)
        const risultati = await Promise.all(promises);
        const dataResponse = {};

        risultati.forEach((data, index) => {
            const type = types[index];
            if (type === "roster") {
                window.setLocalStorage("datiRoster", JSON.stringify(data));
                dataResponse.roster = data;
            } else if (type === "stats") {
                window.setLocalStorage("datiTutteLeStats", JSON.stringify(data));
                dataResponse.stats = data;
            }
        });

        return dataResponse;

    } catch (e) {
        console.error("Errore fetch:", e);
        if (loadingEl) {
            loadingEl.innerText = "Errore nel caricamento dati dal server.";
        }
        return null;
    }
}

window.salvaDatiMappa = salvaDatiMappa;
function salvaDatiMappa(partite) {
    /**
     * Elabora l'elenco delle partite e salva i luoghi univoci nel localStorage.
    *  @param {Array} partite - Array di oggetti partita.
    */
    if (!partite || !Array.isArray(partite)) return;

    const datiLocali = [];
    const setLuoghiUnici = new Set();

    partite.forEach(p => {
        // Verifica che esistano luogo e coordinate validi
        const haLuogo = p.luogo && p.luogo.trim() !== "";
        const haCoordinate = p.coordinate && p.coordinate.trim() !== "";

        if (haLuogo && haCoordinate) {
            // Gestione logica Avversario
            let avversario = "";
            const sA = p.squadraA ? p.squadraA.trim() : "";
            const sB = p.squadraB ? p.squadraB.trim() : "";

            if (window.isMyTeam(sA)) {
                avversario = sB;
            } else if (window.isMyTeam(sB)) {
                avversario = sA;
            } else {
                avversario = `${sA} vs ${sB}`;
            }

            // Identificazione Campionato (U14 se matchId contiene "14", altrimenti U15)
            const campionatoMatch = p.matchId?.toString().includes("14") ? "U14" : "U15";
            
            // Chiave per evitare duplicati nello stesso luogo e data
            const chiaveUnica = (p.luogo.trim() + String(p.data).replace("*", "")).toLowerCase();

            if (!setLuoghiUnici.has(chiaveUnica)) {
                setLuoghiUnici.add(chiaveUnica);
                
                datiLocali.push({
                    campionato: campionatoMatch,
                    dataPartita: String(p.data).replace("*", ""),
                    orario: p.orario,
                    luogo: p.luogo.trim(),
                    coordinate: p.coordinate.trim(),
                    avversario: avversario
                });
            }
        }
    });

    // Salvataggio finale
    window.setLocalStorage("mappaLuoghi", JSON.stringify(datiLocali));
}

window.saveToServerPIP = saveToServerPIP;
function saveToServerPIP(matchId, isInitialized, config) {
    if (!matchId) {
      console.error("Errore: matchId non trovato.");
      return;
    }

    const details = JSON.stringify(config);
    
    const formData = new FormData();
    formData.append('appVersion', window.APP_VERSION);
    formData.append('teamId', window.getTeamId());
    formData.append('pipConfig', 'true'); // Attiva il blocco nel backend
    formData.append('matchId', matchId);
    formData.append('initialized', isInitialized);
    formData.append('details', details);
    formData.append('timestamp', window.sualizzatoFormattato);

    fetch(window.getBackendUrl(), {
      method: "POST",
      body: formData
    })
    .then(response => {
      if (!response.ok) throw new Error('Errore di rete');
      return response.json();
    })
    .then(data => {
      console.log(`[SERVER RESPONSE] Status: ${data.status}, Message: ${data.message}`);
    })
    .catch(error => {
      console.error("Errore nell'invio o nella lettura della risposta:", error);
    });
}

window.saveToServerEventoLive = saveToServerEventoLive;
function saveToServerEventoLive(idGiocatore, puntiRealizzati, timestampReale, team, action) {
  if (!window.matchId) {
    console.error("Errore: matchId non trovato.");
    return;
  }

  // Controllo validità quintetto per i cambi
  if ((action !== "undo") && (puntiRealizzati === "In" || puntiRealizzati === "Out") && !isQuintettoCompleto()) return;

  // --- COSTRUZIONE DEL JSON PER IL CAMPO NOTE ---
  const noteObj = {
    quintetto: window.getNumeriGiocatoriIn(), // I numeri dei giocatori attualmente in campo
    quarto: quartoAttuale        
  };
  
  // Trasformiamo l'oggetto in una stringa JSON
  const noteJSON = JSON.stringify(noteObj);
  // ----------------------------------------------

  const formData = new FormData();

  formData.append('appVersion', window.APP_VERSION)
  formData.append('teamId', window.getTeamId());
  formData.append("live", "1");
  formData.append("matchId", window.matchId);
  formData.append("idGiocatore", idGiocatore);
  formData.append("puntiRealizzati", puntiRealizzati);
  formData.append("action", action);
  formData.append("squadra", team);

  let AoB = "";
  if (window.isMyTeam(window.teamA)) {
    AoB = (team === window.teamA) ? "A" : "B";
  } else {
    AoB = (team === window.teamB) ? "B" : "A";
  }
  formData.append("AoB", AoB);
  formData.append("timestampReale", timestampReale);

  // Inseriamo la stringa JSON nel campo note
  formData.append("note", noteJSON);

  fetch(window.getBackendUrl(), {
    method: "POST",
    body: formData
  })
  .then(response => {
    if (!response.ok) throw new Error('Errore di rete');
    return response.json();
  })
  .then(data => {
    console.log(`[SERVER RESPONSE] Status: ${data.status}, Message: ${data.message}`);
    console.log(`[LIVE] Elaborato: ${idGiocatore} -> ${puntiRealizzati}`);
  })
  .catch(error => {
    console.error("Errore nell'invio o nella lettura della risposta:", error);
  });
}

window.modifyToServerEventoLive = modifyToServerEventoLive;
function modifyToServerEventoLive(action, timestampReale, team, oldIdGiocatore, newIdGiocatore, oldPunti, newPunti ) {
  if (!window.matchId) {
    console.error("Errore: matchId non trovato.");
    return;
  }
  let AoB = "";
  if (window.isMyTeam(window.teamA)) {
    AoB = (team === window.teamA) ? "A" : "B";
  } else {
    AoB = (team === window.teamB) ? "B" : "A";
  }

  const formData = new FormData();

  formData.append('appVersion', window.APP_VERSION)
  formData.append('teamId', window.getTeamId());
  formData.append("live", "1");
  formData.append("matchId", window.matchId);
  formData.append("action", action);
  formData.append("timestampReale", timestampReale);
  formData.append("oldIdGiocatore", oldIdGiocatore);
  formData.append("newIdGiocatore", newIdGiocatore);
  formData.append("squadra", team);
  formData.append("AoB", AoB);
  formData.append("oldPunti", oldPunti);
  formData.append("newPunti", newPunti);

  fetch(window.getBackendUrl(), {
    method: "POST",
    body: formData
  })
  .then(response => {
    if (!response.ok) throw new Error('Errore di rete');
    return response.json();
  })
  .then(data => {
    console.log(`[SERVER RESPONSE] Status: ${data.status}, Message: ${data.message}`);
  })
  .catch(error => {
    console.error("Errore nell'invio o nella lettura della risposta:", error);
  });
}

window.modifyToServerTimeStampEventoLive = modifyToServerTimeStampEventoLive;
function modifyToServerTimeStampEventoLive(action, timestampReale, idGiocatore, punti, newTimestampReale ) {
  if (!window.matchId) {
    console.error("Errore: matchId non trovato.");
    return;
  }
  const formData = new FormData();

  formData.append('appVersion', window.APP_VERSION)
  formData.append('teamId', window.getTeamId());
  formData.append("live", "1");
  formData.append("matchId", window.matchId);
  formData.append("action", action);
  formData.append("timestampReale", timestampReale);
  formData.append("newTimestampReale", newTimestampReale);
  formData.append("idGiocatore", idGiocatore);
  formData.append("punti", punti);
  
  fetch(window.getBackendUrl(), {
    method: "POST",
    body: formData
  })
  .then(response => {
    if (!response.ok) throw new Error('Errore di rete');
    return response.json();
  })
  .then(data => {
    console.log(`[SERVER RESPONSE] Status: ${data.status}, Message: ${data.message}`);
  })
  .catch(error => {
    console.error("Errore nell'invio o nella lettura della risposta:", error);
  });
}

// Funzione che crea l'HTML del popup al caricamento della pagina
window.injectUniversalPopup = injectUniversalPopup;
function injectUniversalPopup() {
    const popupHTML = `
    <div id="universalPopup" class="hidden" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.85); z-index: 9999; display: none; justify-content: center; align-items: center; padding: 10px;">
        <div class="popup-content" style="background: #1e1e1e; border: 2px solid #27ae60; border-radius: 15px; padding: 2rem; width: 90%; max-width: 280px; text-align: center; box-sizing: border-box; box-shadow: 0 10px 25px rgba(0,0,0,0.5);">
            <i id="uPopupIcon" class="fas fa-info-circle" style="font-size: 4rem; color: #27ae60; margin-bottom: 1rem;"></i>
            <div id="uPopupMessage" style="font-size: 1.6rem; margin: 1.5rem 0; color: white; line-height: 1.4; word-wrap: break-word; max-height: 60vh; overflow-y: auto;"></div>
            <button class="popup-btn" onclick="window.closeUniversalPopup()" style="background: #27ae60; color: white; border: none; padding: 1rem 3rem; border-radius: 8px; font-weight: bold; cursor: pointer; text-transform: uppercase; width: 100%; max-width: 150px;">OK</button>
        </div>
    </div>`;
    
    document.body.insertAdjacentHTML('beforeend', popupHTML);
}

// Funzione per mostrare il popup
window.alertCustom = alertCustom;
function alertCustom(messaggio, icona = 'fa-info-circle') {
    const popup = document.getElementById('universalPopup');
    if (!popup) return; // Sicurezza se non ancora iniettato
    
    document.getElementById('uPopupMessage').innerText = messaggio;
    document.getElementById('uPopupIcon').className = 'fas ' + icona;
    
    popup.style.display = 'flex';
    popup.classList.remove('hidden');
}

// Funzione per chiudere
window.closeUniversalPopup = closeUniversalPopup;
function closeUniversalPopup() {
    const popup = document.getElementById('universalPopup');
    if (popup) popup.style.display = 'none';
}

window.getNumeriGiocatoriIn = getNumeriGiocatoriIn;
function getNumeriGiocatoriIn() {
  // Filtra i giocatori con stato "In" e prende solo il valore del numero
  const numeriIn = window.giocatoriObj
    .filter(g => g.id !== "Squadra_B" && g.stato === "In")
    .map(g => g.numero); // Prende il valore così com'è (es. 11 o "11")

  // 2. Ordina l'array in modo numerico crescente
  numeriIn.sort((a, b) => parseInt(a) - parseInt(b));

  // Crea la stringa finale unendo i valori con la virgola
  return `[${numeriIn.join(",")}]`;
}

window.trasformaLinkDriveInThumbnail = trasformaLinkDriveInThumbnail;
function trasformaLinkDriveInThumbnail(urlDrive, larghezza = 192) {

    // Se il link contiene già "thumbnail", non fare nulla e restituiscilo così com'è
    if (urlDrive && urlDrive.includes("thumbnail")) {
        return urlDrive;
    }

    // Espressione regolare per catturare l'ID del file tra /d/ e /view
    const regex = /\/d\/([a-zA-Z0-9_-]+)/;
    const match = urlDrive.match(regex);

    if (match && match[1]) {
        const idFile = match[1];
        return `https://drive.google.com/thumbnail?id=${idFile}&sz=w${larghezza}`;
    }

    // Se il link non è valido o non corrisponde al formato, restituisce l'URL originale o null
    console.error("Formato URL di Google Drive non valido.");
    return urlDrive;
}

window.setLocalStorage = setLocalStorage;
function setLocalStorage(key, value) {
  localStorage.setItem(key, value);
}

window.getLocalStorage = getLocalStorage;
function getLocalStorage(key) {
  return localStorage.getItem(key);
}

window.removeLocalStorage = removeLocalStorage;
function removeLocalStorage(key) {
//showLocalStorage();
//deleteLocalStorage();

  localStorage.removeItem(key);
}

function showLocalStorage() {
    console.log(`--- CONTENUTO LOCALSTORAGE (${localStorage.length} elementi) ---`);
    
    if (localStorage.length === 0) {
        console.log("Il localStorage è vuoto.");
        return;
    }

    // Cicla attraverso tutte le chiavi usando un normale ciclo for
    for (let i = 0; i < localStorage.length; i++) {
        const chiave = localStorage.key(i);
        const valore = localStorage.getItem(chiave);

//        console.log(`Chiave: "${chiave}" ➡️ Valore: "${valore}"`);
        console.log(`Chiave: ${chiave} `);
    }
    
    console.log("-------------------------------------------------");
}

window.deleteLocalStorage = deleteLocalStorage;
function deleteLocalStorage() {

  // --- ESEMPIO DI UTILIZZO ---
  // Definisci le uniche chiavi che la tua app deve conservare
  const whiteList = [
    "userLoggedData",
    "theme",
    "userCustomTheme",

    "eruda-console",
    "eruda-dev-tools", 
    "eruda-elements",
    "eruda-entry-button",
    "eruda-resources",
    "eruda-sources",
//    "firebase:host:locch65-basketapp-default-rtdb.europe-west1.firebasedatabase.app",
    "googleApiKey"
  ];

  // Array temporaneo per salvare le chiavi da rimuovere (evita problemi di indice durante il ciclo)
    const keysToBeDeleted = [];

    // 1. Individua tutte le chiavi che non appartengono alla lista predefinita
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        
        // Se la chiave attuale non è inclusa nella whitelist, la segnamo per l'eliminazione
        if (!whiteList.includes(key)) {
            keysToBeDeleted.push(key);
        }
    }

    // 2. Rimuovi effettivamente le chiavi identificate
    keysToBeDeleted.forEach(chiave => {
        localStorage.removeItem(chiave);
//        console.log(`🗑️ Rimossa chiave non autorizzata: "${chiave}"`);
    });

    console.log("LocalStorage ripulito");
}


