import { defineConfig } from 'vite';
import { resolve } from 'path';
import fs from 'fs'; // Importiamo il modulo File System di Node
import obfuscator from 'vite-plugin-javascript-obfuscator';

export default defineConfig(({ mode }) => {
  const target = process.env.APP_TARGET || 'test';
  const isProduction = mode === 'production';
  const isFinal = target === 'final';

  return {
    base: isFinal ? '/basket-app/' : '/bsk-tst-2026/',
    plugins: [
      isProduction ? obfuscator({
		options: {
		          compact: true,
		          controlFlowFlattening: true,
		          controlFlowFlatteningThreshold: 1,
		          numbersToExpressions: true,
		          simplify: true,
		          stringArray: true,
		          stringArrayCallsTransform: true,
		          stringArrayThreshold: 1,
		          splitStrings: true,
		          splitStringsChunkLength: 5,
		          unicodeEscapeSequence: true, // Questo trasformerà le stringhe in \x61\x62...
			},
		}) : null,
      {
        name: 'rename-manifest',
        closeBundle() {
          const distPath = resolve(__dirname, 'dist');
          const manifestSource = isFinal ? 'manifest-final.json' : 'manifest-test.json';
          
          // 1. Rinomina il manifest scelto in quello standard
          if (fs.existsSync(`${distPath}/${manifestSource}`)) {
            fs.renameSync(`${distPath}/${manifestSource}`, `${distPath}/manifest.json`);
          }
          
          // 2. Opzionale: Rimuovi l'altro manifest che è rimasto in dist
          const otherManifest = isFinal ? 'manifest-test.json' : 'manifest-final.json';
          if (fs.existsSync(`${distPath}/${otherManifest}`)) {
            fs.unlinkSync(`${distPath}/${otherManifest}`);
          }

          console.log(`✅ Manifest configurato per: ${target.toUpperCase()}`);
        }
      }
    ],
    build: {
      sourcemap: !isProduction,
      minify: 'terser',
      rollupOptions: {
        input: {
          main: resolve(__dirname, 'index.html'),
          anagrafica: resolve(__dirname, 'anagrafica.html'),
          roster: resolve(__dirname, 'roster.html'),
          calendario: resolve(__dirname, 'calendario.html'),
          classifica: resolve(__dirname, 'classifica.html'),
          direttavideo: resolve(__dirname, 'direttavideo.html'),
          maps: resolve(__dirname, 'maps.html'),
          ai_interface: resolve(__dirname, 'AI_interface.html'),
          u14_fn: resolve(__dirname, 'U14_FN.html'),
          voicerecognition: resolve(__dirname, 'voicerecognition.html'),
        }
      }
	}
  };
});