@echo off
setlocal enabledelayedexpansion

:menu
cls
echo ======================================================
echo           GESTIONE COMANDI BASKET APP
echo ======================================================
echo.
echo 1) Esegui in LOCALE (npm run dev)
echo 2) Esegui con HOST  (Debug da cellulare/WiFi)
echo 3) Build TEST       (per bsk-tst-2026 - No .map)
echo 4) Build FINAL      (per basket-app   - No .map)
echo 5) Esci
echo.
echo ======================================================
set /p scelta="Seleziona un'opzione (1-5): "

if "%scelta%"=="1" goto dev
if "%scelta%"=="2" goto host
if "%scelta%"=="3" goto build_test
if "%scelta%"=="4" goto build_final
if "%scelta%"=="5" exit
goto menu

:dev
echo.
echo [INFO] Avvio ambiente di sviluppo locale...
powershell -ExecutionPolicy Bypass npm run dev
pause
goto menu

:host
echo.
echo [INFO] Avvio con esposizione host (Vite)...
powershell -ExecutionPolicy Bypass npx vite dev --host
pause
goto menu

:build_test
echo.
echo [INFO] Generazione build offuscata per TEST...
powershell -ExecutionPolicy Bypass npm run build:test
echo [PULIZIA] Rimozione file .map in corso...
del /s /q dist\*.map >nul 2>&1
echo [OK] Build completata in \dist (mappe rimosse).
pause
goto menu

:build_final
echo.
echo [INFO] Generazione build offuscata FINAL...
powershell -ExecutionPolicy Bypass npm run build:final
echo [PULIZIA] Rimozione file .map in corso...
del /s /q dist\*.map >nul 2>&1
echo [OK] Build completata in \dist (mappe rimosse).
pause
goto menu